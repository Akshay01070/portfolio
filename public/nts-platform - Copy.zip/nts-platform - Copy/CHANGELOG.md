# NTS Platform — Changelog

All notable changes to this project are documented here.
Entries are grouped by milestone and ordered newest-first within each milestone.

---

## M9 + M10 — Frontend Dashboard + Reporting + Environment Support

**Date:** 2026-09-13
**Status:** ✅ Complete

### What was built

M9 and M10 deliver the `frontend-dashboard` — a React + Vite SPA giving QA engineers a
complete GUI to manage tests, trigger runs with environment selection, monitor live
execution, and review full run reports with step results, artifacts, and event logs.

### New package

`frontend-dashboard/` — React 18 + Vite + react-router-dom. No UI component libraries.

### New files

| File | Purpose |
|------|---------|
| `frontend-dashboard/src/api/client.js` | Pure HTTP client — `api.get/post/put/patch/delete`; no React dependency |
| `frontend-dashboard/src/api/tests.js` | TestCase API: listTests, getTest, createTest, updateTest, deleteTest, runTest |
| `frontend-dashboard/src/api/runs.js` | Run API: listRuns, getRun, getRunEvents, getRunArtifacts |
| `frontend-dashboard/src/api/reports.js` | Report API: getReport |
| `frontend-dashboard/src/api/environments.js` | Environment API: list, create, patch, delete |
| `frontend-dashboard/src/hooks/usePoll.js` | Polls fetchFn every N ms; stops on terminal states or unmount |
| `frontend-dashboard/src/components/Sidebar.jsx` | Fixed left nav with NavLink active state |
| `frontend-dashboard/src/components/StatusBadge.jsx` | Colour-coded pill badge per status |
| `frontend-dashboard/src/components/StepBuilder.jsx` | Ordered step list — add/remove/move |
| `frontend-dashboard/src/components/Modal.jsx` | Backdrop overlay modal |
| `frontend-dashboard/src/pages/Dashboard.jsx` | 4 stat tiles: tests, runs, pass rate (7d), active envs |
| `frontend-dashboard/src/pages/TestList.jsx` | Test table + environment-select Run modal |
| `frontend-dashboard/src/pages/TestForm.jsx` | Create/edit test with StepBuilder |
| `frontend-dashboard/src/pages/RunDetail.jsx` | Live polling → report + step results + events + artifacts |
| `frontend-dashboard/src/pages/RunHistory.jsx` | Filterable run history table |
| `frontend-dashboard/src/pages/Environments.jsx` | Environment cards + create modal + set-default + delete |
| `frontend-dashboard/src/App.jsx` | Route declarations + sidebar layout |
| `frontend-dashboard/src/index.css` | Complete design system: CSS vars, dark theme, badges, tables, forms |

### Modified files

| File | Change |
|------|--------|
| `backend-server/src/routes/runs.js` | Added `GET /api/runs/:id/events` and `GET /api/runs/:id/artifacts` (run-centric read routes) |
| `nts-platform/README.md` | Marked M9 and M10 complete |

### Key design decisions

- **`api/client.js` is React-free:** API infrastructure is a plain JS module. Pages and
  hooks call it directly. No mixed React-state + fetch abstraction.
- **`usePoll` uses `setTimeout`, not `setInterval`:** Each tick waits for the previous
  fetch to complete before scheduling the next. Prevents tick overlap if the network is slow.
- **Polling stops on terminal states:** `isTerminal(run)` returns true for
  PASSED / FAILED / STOPPED / TIMEOUT. The interval is cleared and the component
  transitions to report view without any extra state machine.
- **`Promise.allSettled` for report + events + artifacts:** Each can fail independently
  (report may arrive a second after the run ends). `allSettled` shows whatever is
  available rather than failing the whole view on one 404.
- **Environment selection on Run:** The Run modal pre-selects the default environment.
  The environmentId is sent in the POST body; backend falls back to default if omitted.
- **Single-default enforcement is backend-owned:** `enforceUniqueDefault()` in
  `environments.js` already handles this. Frontend just calls `PATCH { isDefault: true }`.
- **`VITE_API_URL` env var:** Vite proxy forwards `/api` → backend in dev, so the
  frontend never issues cross-origin requests during development.

---

## M5–M8 — Reliability, WaitEngine, AssertionEngine + Complete Execution Flow

**Date:** 2026-09-13  
**Status:** ✅ Complete

### What was built

M5–M8 complete the full end-to-end execution pipeline. After these milestones,
a test run dispatched from the backend travels all the way through Chrome and
back, with a Report document auto-generated on completion.

### New files

| File | Purpose |
|------|---------|
| `automation-sdk/src/runner/WaitEngine.js` | Polling-based waits — `waitForSelector`, `waitForUrl`, `waitForText`, `waitForTimeout` |
| `automation-sdk/src/runner/Locator.js` | Resolves selectors to nodeIds with built-in WaitEngine retry |
| `backend-server/src/services/reportService.js` | Auto-generates Report after terminal state — aggregates ExecutionEvents into step results |
| `backend-server/src/routes/reports.js` | Read routes: `GET /api/reports/:runId`, `/events`, `/artifacts` |

### Modified files

| File | Change |
|------|--------|
| `automation-sdk/src/browser/CDPAdapter.js` | Fixed `navigate()` — clean single-race timeout pattern + CDP `errorText` detection for net errors |
| `automation-sdk/src/browser/BrowserSession.js` | Fixed tab-connection: 250ms settle delay + `_connectWithRetry(3)` after `createTarget` |
| `automation-sdk/src/runner/steps/click.js` | Uses `Locator.resolveWithCenter()` — waits for element before clicking |
| `automation-sdk/src/runner/steps/fill.js` | Uses `Locator.resolveWithCenter()` — waits before focus + clearAndType |
| `automation-sdk/src/runner/steps/assertVisible.js` | Uses `Locator.resolve()` + box model check |
| `automation-sdk/src/runner/steps/assertText.js` | Uses `WaitEngine.waitForText()` — polls until text appears |
| `automation-sdk/src/runner/steps/assertUrl.js` | Uses `WaitEngine.waitForUrl()` — handles SPAs + redirects |
| `backend-server/src/services/runService.js` | `transition()` fires `generateReport()` via `setImmediate` on terminal states |
| `backend-server/src/app.js` | Mounts `/api/reports` |

### Key design decisions

- **WaitEngine polling at 100ms:** Matches Playwright's default poll interval. Fast enough for interactive feedback, slow enough to not spam CPU.
- **Locator.resolveWithCenter() for click/fill:** Eliminates the most common flake cause — clicking before the element exists or has painted. One method = wait + locate + center in one step.
- **assertText/assertUrl use wait-based assertions:** Assertions that check dynamic state (text after API call, URL after redirect) must poll. Static assertions would produce false failures on async pages.
- **reportService is fire-and-forget via setImmediate:** Report generation is kicked off after `run.save()` returns, so the state transition response is never delayed. If report fails, the run state is unaffected.
- **CDPAdapter.navigate() errorText check:** Chrome returns `errorText: "net::ERR_NAME_NOT_RESOLVED"` even when `Page.navigate()` resolves without throwing. Without this check, a failed navigation silently "passes" the goto step.

### Complete API surface (M1–M8)

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/health` | Backend health check |
| GET | `/api/tests` | List test cases |
| POST | `/api/tests` | Create test case |
| GET/PUT/PATCH/DELETE | `/api/tests/:id` | Manage one test case |
| POST | `/api/tests/:id/run` | Trigger a TestRun |
| GET | `/api/environments` | List environments |
| POST | `/api/environments` | Create environment |
| GET/PUT/PATCH/DELETE | `/api/environments/:id` | Manage one environment |
| GET | `/api/runs` | List runs (filterable) |
| GET | `/api/runs/:id` | Get one run (populated) |
| POST | `/api/sdk/runs/:runId/events` | SDK → backend: stream event |
| POST | `/api/sdk/runs/:runId/complete` | SDK → backend: signal completion |
| POST | `/api/sdk/runs/:runId/artifacts` | SDK → backend: register artifact |
| POST | `/api/sdk/heartbeat` | SDK → backend: alive signal |
| GET | `/api/reports/:runId` | Get aggregated run report |
| GET | `/api/reports/:runId/events` | List raw execution events |
| GET | `/api/reports/:runId/artifacts` | List run artifacts |

---

## M4 — BrowserManager + BrowserSession + CDPAdapter

**Date:** 2026-09-13  
**Status:** ✅ Complete

### What was built

M4 delivers the full browser execution stack inside the `automation-sdk`.
After M4, a `POST /execute` call to the SDK will:
1. Lazy-launch headless Chrome via `ChromeLauncher`
2. Open a dedicated tab (`BrowserSession`)
3. Connect to it via the CDP (`CDPAdapter`)
4. Execute all steps using typed CDP methods
5. Report every event back to the backend via `ExecutionReporter`

### New files

| File | Purpose |
|------|---------|
| `automation-sdk/src/config/env.js` | SDK env config — validates + exports all env vars |
| `automation-sdk/src/browser/ChromeLauncher.js` | Spawns headless Chrome, polls `/json/version` until CDP is ready |
| `automation-sdk/src/browser/CDPAdapter.js` | Typed wrapper over `chrome-remote-interface` — navigate, evaluate, querySelector, click, typeText, etc. |
| `automation-sdk/src/browser/BrowserSession.js` | Single-tab lifecycle — open tab → connect → enable domains → close |
| `automation-sdk/src/browser/BrowserManager.js` | Process-level singleton — owns Chrome process + session pool, enforces MAX_SESSIONS=1 |
| `automation-sdk/src/reporter/ExecutionReporter.js` | POSTs events, completion, artifacts, heartbeats to backend `/api/sdk/*` |
| `automation-sdk/src/runner/Runner.js` | Core execution loop — drives steps, handles abort/timeout, reports results |
| `automation-sdk/src/runner/steps/goto.js` | `goto` step — CDPAdapter.navigate() |
| `automation-sdk/src/runner/steps/click.js` | `click` step — querySelector + getElementCenter + click |
| `automation-sdk/src/runner/steps/fill.js` | `fill` step — click to focus + clearAndType |
| `automation-sdk/src/runner/steps/type.js` | `type` step — typeText (appends, no clear) |
| `automation-sdk/src/runner/steps/assertVisible.js` | `assertVisible` step — querySelector + getBoxModel |
| `automation-sdk/src/runner/steps/assertText.js` | `assertText` step — Runtime.evaluate(innerText) + substring assert |
| `automation-sdk/src/runner/steps/assertUrl.js` | `assertUrl` step — getCurrentUrl + substring assert |
| `automation-sdk/src/runner/steps/screenshot.js` | `screenshot` step — Page.captureScreenshot + disk write + artifact report |

### Modified files

| File | Change |
|------|--------|
| `automation-sdk/src/server/routes.js` | Replaced M1 stubs with full `POST /execute` + `POST /stop` + `GET /status` |
| `automation-sdk/index.js` | Imports BrowserManager, calls `shutdown()` on SIGTERM/SIGINT |
| `automation-sdk/.env.example` | Added `CHROME_LAUNCH_TIMEOUT_MS`, `MAX_SESSIONS` |
| `nts-platform/README.md` | Marked M4 complete |

### Key design decisions

- **Singleton BrowserManager:** One Chrome process per SDK instance. The SDK is deployed one-per-machine anyway, so a singleton is correct. It avoids port conflicts and simplifies session tracking.
- **Lazy Chrome launch:** Chrome is only started when the first `POST /execute` arrives — not at SDK startup. This keeps the SDK lightweight when idle.
- **4-step session open sequence:** `connect (default) → createTarget → disconnect → connect (specific tab) → enableDomains`. This is required because CRI needs to be connected to create a target, but then must reconnect specifically to that target so all subsequent commands are scoped correctly.
- **All steps implemented now (not stubs):** Even though M5-M7 are the "official" milestones for each step type, the implementations are real and functional from M4. This avoids a broken intermediate state.
- **Runner is fire-and-forget:** `POST /execute` responds 202 immediately; execution happens fully async. Results arrive at the backend via `ExecutionReporter` callbacks.

### Chrome flags (headless mode)

| Flag | Reason |
|------|--------|
| `--headless=new` | New headless mode (GPU compositing — more realistic than legacy) |
| `--no-sandbox` | Required in Docker/CI |
| `--disable-gpu` | Headless mode stability |
| `--disable-dev-shm-usage` | Prevents OOM in Docker with small `/dev/shm` |

---

## M3 — Execution Queue + Backend→SDK Dispatch

**Date:** 2026-09-13  
**Status:** ✅ Complete

### What was built

M3 closes the dispatch loop: when a QA engineer triggers `POST /api/tests/:id/run`,
the backend now automatically queues the run and dispatches it to the automation-sdk
over HTTP. The SDK receives the test payload, executes the browser steps, and POSTs
events + final status back to the backend via new `/api/sdk` callback routes.

### New files

| File | Purpose |
|------|---------|
| `backend-server/src/queue/queue.js` | In-process FIFO execution queue (Array-backed, swap-friendly interface) |
| `backend-server/src/queue/dispatcher.js` | Polls the queue, sends runs to the SDK's `/execute` endpoint, handles failures |
| `backend-server/src/routes/sdk.js` | SDK → Backend callback routes (`/api/sdk/runs/:id/events`, `/complete`, `/artifacts`, `/heartbeat`) |

### Modified files

| File | Change |
|------|--------|
| `backend-server/src/services/runService.js` | `createRun()` now calls `queue.enqueue()` after transitioning to QUEUED |
| `backend-server/src/server.js` | Starts `dispatcher.start()` after DB connects; calls `dispatcher.stop()` on shutdown |
| `backend-server/src/app.js` | Mounts `/api/sdk` routes |
| `backend-server/.env.example` | Added `BACKEND_URL` and `DISPATCH_INTERVAL_MS` variables |
| `nts-platform/README.md` | Marked M3 complete in milestones list |

### Key design decisions

- **In-process queue (no Redis):** Keeps V1 zero-dependency. The `queue.js` interface is intentionally minimal so it can be swapped for BullMQ/Redis in a later milestone without touching callers.
- **Crash recovery:** `dispatcher.reconcileQueuedRuns()` re-enqueues any runs stuck in `QUEUED` state when the server restarts.
- **Dispatcher error handling:** If the SDK HTTP call fails, the run transitions to `FAILED` immediately (not stuck in `QUEUED`).
- **SDK callback routes at `/api/sdk`:** Separated from public API routes to make it clear these are internal SDK↔backend calls, not user-facing endpoints.

---

## M2 — Test Case + Environment Models + APIs + Test Run Lifecycle

**Date:** 2026-09-13  
**Status:** ✅ Complete

### What was built

M2 delivers the full data model and REST API layer: TestCase CRUD, Environment CRUD,
TestRun state machine, and three new deferred-use models (ExecutionEvent, Report, Artifact)
for use in M7–M10.

### New files

| File | Purpose |
|------|---------|
| `backend-server/src/models/TestCase.js` | Mongoose model — test definition (name, targetUrl, steps[], tags[]) |
| `backend-server/src/models/TestRun.js` | Mongoose model — execution instance (FSM: CREATED→QUEUED→RUNNING→PASSED/FAILED/STOPPED/TIMEOUT) |
| `backend-server/src/models/Environment.js` | Mongoose model — SDK host descriptor (sdkUrl, browser, os, isDefault) |
| `backend-server/src/models/ExecutionEvent.js` | Mongoose model — real-time step-level events from the SDK (append-only) |
| `backend-server/src/models/Report.js` | Mongoose model — aggregated summary after a run completes (1-to-1 with TestRun) |
| `backend-server/src/models/Artifact.js` | Mongoose model — files produced by the SDK (screenshots, video, HAR, logs) |
| `backend-server/src/services/runService.js` | Owns the TestRun FSM — `createRun()` and `transition()` are the only permitted state mutators |
| `backend-server/src/routes/tests.js` | CRUD + `POST /api/tests/:id/run` (triggers a TestRun) |
| `backend-server/src/routes/environments.js` | CRUD with single-default enforcement |
| `backend-server/src/routes/runs.js` | Read-only: `GET /api/runs`, `GET /api/runs/:id` |
| `backend-server/src/utils/asyncHandler.js` | Express async error wrapper — eliminates try/catch boilerplate in routes |

### Modified files

| File | Change |
|------|--------|
| `backend-server/src/app.js` | Mounted `/api/tests`, `/api/environments`, `/api/runs` routes |

### API surface (M2)

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/tests` | List test cases (filterable by `?tags=`) |
| POST | `/api/tests` | Create a test case |
| GET | `/api/tests/:id` | Get one test case |
| PUT | `/api/tests/:id` | Full replace |
| PATCH | `/api/tests/:id` | Partial update |
| DELETE | `/api/tests/:id` | Delete |
| POST | `/api/tests/:id/run` | Trigger a TestRun (body: `{ environmentId? }`) |
| GET | `/api/environments` | List environments |
| POST | `/api/environments` | Create an environment |
| GET | `/api/environments/:id` | Get one environment |
| PUT | `/api/environments/:id` | Full replace |
| PATCH | `/api/environments/:id` | Partial update |
| DELETE | `/api/environments/:id` | Delete |
| GET | `/api/runs` | List runs (filterable by `?testCaseId=`, `?status=`) |
| GET | `/api/runs/:id` | Get one run (populated) |

### TestRun FSM

```
CREATED → QUEUED → RUNNING → PASSED
                           ↘ FAILED
                           ↘ STOPPED
                           ↘ TIMEOUT
```

---

## M1 — Foundation

**Date:** 2026-09-13  
**Status:** ✅ Complete

### What was built

M1 scaffolds both services and verifies health endpoints.

### New files

| File | Purpose |
|------|---------|
| `nts-platform/README.md` | Root project README (architecture, components, quick-start) |
| `backend-server/package.json` | Node.js project manifest |
| `backend-server/.env` | Local environment variables (not committed) |
| `backend-server/.env.example` | Environment variable template |
| `backend-server/README.md` | Backend-specific README |
| `backend-server/src/config/env.js` | Validates + exports all env vars; fast-fail on missing required vars |
| `backend-server/src/config/db.js` | Mongoose connection with Atlas primary + in-memory fallback |
| `backend-server/src/middleware/errorHandler.js` | Global Express error handler |
| `backend-server/src/middleware/requestLogger.js` | HTTP request logger (method, path, status, duration) |
| `backend-server/src/app.js` | Express app factory (testable, does not bind port) |
| `backend-server/src/server.js` | HTTP server entry point — connects DB, starts listening |
| `automation-sdk/package.json` | Node.js project manifest |
| `automation-sdk/.env` | Local environment variables |
| `automation-sdk/.env.example` | Environment variable template |
| `automation-sdk/README.md` | SDK-specific README |
| `automation-sdk/index.js` | SDK entry point |
| `automation-sdk/src/server/app.js` | Express app for SDK |
| `automation-sdk/src/server/routes.js` | SDK routes (`GET /health`) |

### Health endpoints verified

| Endpoint | Expected response |
|----------|------------------|
| `GET /api/health` (backend) | `{ "status": "ok", "service": "backend-server" }` |
| `GET /health` (SDK) | `{ "status": "ok", "service": "automation-sdk" }` |

---

## Upcoming Milestones

| Milestone | Description | Status |
|-----------|-------------|--------|
| M4 | BrowserManager + BrowserSession + CDPAdapter | ⏳ Next |
| M5 | `Page.goto()` implementation | ⏳ Planned |
| M6 | Locator + WaitEngine + click/fill/type | ⏳ Planned |
| M7 | AssertionEngine + Screenshots | ⏳ Planned |
| M8 | Complete Backend ↔ SDK Execution Flow | ⏳ Planned |
| M9 | Frontend Dashboard | ⏳ Planned |
| M10 | Execution History + Reporting + Environment Support | ⏳ Planned |
