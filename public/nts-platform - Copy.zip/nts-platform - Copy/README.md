# NTS Test Automation Platform

A real, end-to-end test automation platform where QA Engineers can define, run, and monitor
browser-based test cases against real Chrome via Chrome DevTools Protocol (CDP).

## Architecture

```
frontend-dashboard  →  backend-server  →  MongoDB
                              ↓
                       automation-sdk  →  Chrome (CDP)
                              ↓
                      Website Under Test
```

## Components

| Component | Description | Port |
|---|---|---|
| `frontend-dashboard/` | React + Vite dashboard UI | 5173 |
| `backend-server/` | Node.js + Express + MongoDB REST API | 3000 |
| `automation-sdk/` | Node.js SDK — CDP browser control + runner | 8080 |

## Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)
- Google Chrome installed

### 1. Backend Server
```bash
cd backend-server
cp .env.example .env     # then edit .env
npm install
npm run dev
```

### 2. Automation SDK
```bash
cd automation-sdk
cp .env.example .env     # then edit .env
npm install
npm run dev
```

### 3. Frontend Dashboard
```bash
cd frontend-dashboard
cp .env.example .env     # then edit .env
npm install
npm run dev
```

## Communication Flow

```
QA Engineer → Dashboard → Backend → Execution Queue → SDK → BrowserManager →
BrowserSession → CDPAdapter → Chrome → Website → Execute Steps →
SDK reports events → Backend → MongoDB → Dashboard → PASSED/FAILED
```

## V1 Milestones

- [x] M1 — Foundation: Both servers start, health checks pass
- [x] M2 — Test Case + Environment Models + APIs + Test Run lifecycle
- [x] M3 — Execution Queue + Backend→SDK Dispatch
- [x] M4 — BrowserManager + BrowserSession + CDPAdapter
- [x] M5 — Page.goto()
- [x] M6 — Locator + WaitEngine + click/fill/type
- [x] M7 — AssertionEngine + Screenshots
- [x] M8 — Complete Backend ↔ SDK Execution Flow
- [x] M9 — Frontend Dashboard
- [x] M10 — Execution History + Reporting + Environment Support
