# Automation SDK

NTS Platform browser automation component — Node.js + Chrome DevTools Protocol.

## Responsibilities
- Expose an HTTP server to receive run dispatch from Backend
- Launch and control Chrome via CDP (`chrome-remote-interface`)
- Execute test steps (goto, click, fill, type, assertVisible, assertText, screenshot)
- POST execution events back to Backend as steps run
- POST /api/runs/:runId/complete when all steps finish

## Architecture

```
Runner
   │
   ▼
BrowserManager
   │
   ▼
BrowserSession
   │
   ▼
Page
   │
   ├──► Locator
   ├──► ActionEngine (uses WaitEngine internally)
   └──► AssertionEngine
          │
          ▼
       CDPAdapter  ←── ONLY module that speaks raw CDP
          │
          ▼
        Chrome
```

## Setup

```bash
cp .env.example .env   # configure CHROME_PATH, BACKEND_URL
npm install
npm run dev            # starts on PORT 8080 (default)
```

## Health Check

```bash
curl http://localhost:8080/health
# → { "status": "ok", "timestamp": "..." }
```

## Directory Structure

```
src/
├── server/
│   ├── app.js        # Express app
│   └── routes.js     # /run, /stop, /status, /health
├── runner/           # Runner (M4+)
├── browser/          # BrowserManager + BrowserSession (M4+)
├── page/             # Page API (M5+)
├── locator/          # Locator (M6+)
├── actions/          # ActionEngine (M6+)
├── waits/            # WaitEngine (M6+)
├── assertions/       # AssertionEngine (M7+)
├── cdp/              # CDPAdapter (M4+)
├── reporter/         # Reporter — POSTs events to Backend (M5+)
├── client/           # BackendClient — Axios HTTP client (M5+)
└── utils/            # Shared helpers
index.js              # Entry point
```
