'use strict';

require('dotenv').config();

const http = require('http');
const app = require('./src/server/app');
const env = require('./src/config/env');
const browserManager = require('./src/browser/BrowserManager');

/**
 * index.js — Automation SDK entry point.
 *
 * Responsibilities:
 *  1. Load env
 *  2. Start the HTTP server
 *  3. Handle graceful shutdown — closes browser sessions + kills Chrome
 */

const server = http.createServer(app);

function start() {
  server.listen(env.PORT, () => {
    console.log(`[sdk] Automation SDK running on http://localhost:${env.PORT}`);
    console.log(`[sdk] Environment: ${env.NODE_ENV}`);
    console.log(`[sdk] HEADLESS: ${env.HEADLESS}`);
    console.log(`[sdk] Health:      http://localhost:${env.PORT}/health`);
    console.log(`[sdk] Status:      http://localhost:${env.PORT}/status`);
    console.log(`[sdk] Execute:     POST http://localhost:${env.PORT}/execute`);
  });

  server.on('error', (err) => {
    console.error('[sdk] Server error:', err.message);
    process.exit(1);
  });
}

// ── Graceful shutdown ─────────────────────────────────────────────────────────
async function shutdown(signal) {
  console.log(`\n[sdk] Received ${signal}. Shutting down gracefully…`);

  // 1. Stop accepting new HTTP requests
  server.close(() => {
    console.log('[sdk] HTTP server closed');
  });

  // 2. Close browser sessions and kill Chrome
  await browserManager.shutdown().catch((err) => {
    console.error('[sdk] BrowserManager shutdown error:', err.message);
  });

  // 3. Exit
  process.exit(0);
}

// Force exit if graceful shutdown takes too long
function forceExit() {
  setTimeout(() => {
    console.error('[sdk] Forced exit after timeout');
    process.exit(1);
  }, 10_000).unref();
}

process.on('SIGTERM', () => { forceExit(); shutdown('SIGTERM'); });
process.on('SIGINT',  () => { forceExit(); shutdown('SIGINT');  });

process.on('unhandledRejection', (reason) => {
  console.error('[sdk] Unhandled rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('[sdk] Uncaught exception:', err.message);
  process.exit(1);
});

start();
