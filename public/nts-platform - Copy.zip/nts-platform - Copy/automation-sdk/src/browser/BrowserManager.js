'use strict';

const ChromeLauncher = require('./ChromeLauncher');
const BrowserSession = require('./BrowserSession');
const env = require('../config/env');

/**
 * BrowserManager.js — Top-level browser lifecycle manager.
 *
 * ── Position in the architecture ─────────────────────────────────────────────
 *
 *   Runner ──uses──► BrowserManager
 *                         │
 *                    ChromeLauncher   (spawns/kills the Chrome process)
 *                         │
 *                    BrowserSession[] (one per active test run)
 *                         │
 *                    CDPAdapter       (raw CDP commands)
 *
 * ── Responsibilities ─────────────────────────────────────────────────────────
 *
 *  1. Maintain exactly ONE Chrome process (lazy-launched on first session).
 *  2. Create BrowserSession instances for incoming test runs.
 *  3. Enforce the MAX_SESSIONS concurrency limit (V1 = 1).
 *  4. Destroy sessions when runs complete or on error.
 *  5. Shut down Chrome cleanly when the SDK process stops.
 *
 * ── Concurrency Model (V1) ───────────────────────────────────────────────────
 *
 *   MAX_SESSIONS = 1 — only one test may run at a time.
 *   Attempting to open a second session while one is active throws a 409 error
 *   that the backend dispatcher can re-queue.
 *
 *   Future milestones may increase MAX_SESSIONS (parallel tab support) or
 *   switch to per-session Chrome instances (isolated profiles).
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   openSession(runId)        → BrowserSession (ready to use)
 *   closeSession(runId)       → void
 *   getSession(runId)         → BrowserSession | null
 *   hasActiveSession()        → boolean
 *   shutdown()                → closes all sessions + kills Chrome
 *   status()                  → { state, sessions, chromeAlive }
 */

class BrowserManager {
  constructor() {
    this._launcher = new ChromeLauncher();
    /** @type {Map<string, BrowserSession>} */
    this._sessions = new Map();
    this._chromeStarted = false;
    this._shuttingDown = false;
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  /**
   * Open a new BrowserSession for the given TestRun.
   *
   * Launches Chrome if it is not already running.
   * Enforces the MAX_SESSIONS limit.
   *
   * @param {string} runId — TestRun ObjectId string
   * @returns {Promise<BrowserSession>}
   * @throws 409 if a session for this runId already exists
   * @throws 503 if MAX_SESSIONS is already reached
   */
  async openSession(runId) {
    if (this._shuttingDown) {
      const err = new Error('[BrowserManager] SDK is shutting down — cannot open new sessions');
      err.status = 503;
      throw err;
    }

    if (this._sessions.has(runId)) {
      const err = new Error(`[BrowserManager] Session already exists for run ${runId}`);
      err.status = 409;
      throw err;
    }

    if (this._sessions.size >= env.MAX_SESSIONS) {
      const err = new Error(
        `[BrowserManager] MAX_SESSIONS (${env.MAX_SESSIONS}) reached — try again later`
      );
      err.status = 503;
      throw err;
    }

    // ── Ensure Chrome is running ─────────────────────────────────────────────
    await this._ensureChrome();

    // ── Create and open the session ──────────────────────────────────────────
    const session = new BrowserSession();
    this._sessions.set(runId, session);

    try {
      await session.open(runId);
    } catch (err) {
      // Clean up the map entry so the slot is freed
      this._sessions.delete(runId);
      throw err;
    }

    console.log(`[BrowserManager] Session opened — runId=${runId} active=${this._sessions.size}`);
    return session;
  }

  /**
   * Close and remove the session associated with a TestRun.
   * Safe to call even if the session does not exist.
   *
   * @param {string} runId
   */
  async closeSession(runId) {
    const session = this._sessions.get(runId);
    if (!session) {
      console.warn(`[BrowserManager] closeSession: no session found for run ${runId}`);
      return;
    }

    await session.close().catch((err) => {
      console.error(`[BrowserManager] Error closing session for run ${runId}:`, err.message);
    });

    this._sessions.delete(runId);
    console.log(`[BrowserManager] Session closed — runId=${runId} active=${this._sessions.size}`);
  }

  /**
   * Get the active session for a TestRun.
   *
   * @param {string} runId
   * @returns {BrowserSession | null}
   */
  getSession(runId) {
    return this._sessions.get(runId) || null;
  }

  /**
   * True if at least one session is currently open.
   */
  hasActiveSession() {
    return this._sessions.size > 0;
  }

  /**
   * Shut down cleanly: close all sessions then kill Chrome.
   * Called by the SDK process on SIGTERM / SIGINT.
   */
  async shutdown() {
    if (this._shuttingDown) return;
    this._shuttingDown = true;

    console.log('[BrowserManager] Shutting down…');

    // Close all active sessions
    const closePromises = [...this._sessions.keys()].map((runId) =>
      this.closeSession(runId)
    );
    await Promise.allSettled(closePromises);

    // Kill Chrome
    if (this._chromeStarted) {
      this._launcher.kill();
      this._chromeStarted = false;
    }

    console.log('[BrowserManager] Shutdown complete');
  }

  /**
   * Return a status summary (used by GET /status route).
   */
  status() {
    const sessions = [...this._sessions.entries()].map(([runId, session]) => ({
      runId,
      state: session.state,
      createdAt: session.createdAt,
    }));

    return {
      chromeAlive: this._launcher.isAlive(),
      sessionCount: this._sessions.size,
      maxSessions: env.MAX_SESSIONS,
      sessions,
    };
  }

  // ── Private ────────────────────────────────────────────────────────────────

  /**
   * Ensure the Chrome process is running.
   * Idempotent — safe to call multiple times.
   */
  async _ensureChrome() {
    if (this._chromeStarted && this._launcher.isAlive()) return;

    if (this._chromeStarted && !this._launcher.isAlive()) {
      console.warn('[BrowserManager] Chrome exited unexpectedly — relaunching…');
      this._chromeStarted = false;
    }

    await this._launcher.launch();
    this._chromeStarted = true;
  }
}

// ── Singleton export ──────────────────────────────────────────────────────────
// BrowserManager is a process-level singleton — there is only one Chrome
// instance and one session pool per SDK process.
module.exports = new BrowserManager();
