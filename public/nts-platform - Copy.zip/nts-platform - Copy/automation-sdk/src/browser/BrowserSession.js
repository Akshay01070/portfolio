'use strict';

const CDPAdapter = require('./CDPAdapter');

/**
 * BrowserSession.js — Represents a single test execution tab in Chrome.
 *
 * ── Responsibilities ─────────────────────────────────────────────────────────
 *
 *  A BrowserSession owns exactly ONE browser tab (CDP Target).  It:
 *    1. Opens a new tab via CDPAdapter.createTarget()
 *    2. Connects a dedicated CDPAdapter instance to that specific tab
 *    3. Enables all required CDP domains on the tab
 *    4. Exposes the adapter for the Runner to use during step execution
 *    5. Cleans up (closes the tab, disconnects CDP) when done
 *
 * ── Why a separate class from CDPAdapter? ────────────────────────────────────
 *
 *  CDPAdapter is a pure CDP abstraction — it knows nothing about sessions or
 *  tabs.  BrowserSession is the lifecycle wrapper:
 *    - It manages the tab (open → use → close)
 *    - It holds session-level metadata (runId, createdAt, state)
 *    - It calls CDPAdapter in the correct sequence (connect → enableDomains)
 *
 * ── Session States ────────────────────────────────────────────────────────────
 *
 *   idle       → session created, not yet open
 *   opening    → tab is being created and CDP is connecting
 *   ready      → tab is open, CDP connected, domains enabled
 *   closing    → close() has been called
 *   closed     → tab closed and CDP disconnected
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   open(runId)     → opens tab, connects CDP, enables domains
 *   close()         → closes tab, disconnects CDP
 *   adapter         → exposes the underlying CDPAdapter (for Runner use)
 *   runId           → the associated TestRun ObjectId string
 *   state           → current session state
 *   createdAt       → Date when the session was opened
 */

class BrowserSession {
  constructor() {
    this._adapter = new CDPAdapter();
    this._targetId = null;
    this._runId = null;
    this._state = 'idle';
    this._createdAt = null;
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  /**
   * Open a new tab and prepare it for test execution.
   *
   * @param {string} runId — TestRun ObjectId string (for logging)
   */
  async open(runId) {
    if (this._state !== 'idle') {
      throw new Error(`[BrowserSession] Cannot open session in state "${this._state}"`);
    }

    this._runId = runId;
    this._state = 'opening';
    this._createdAt = new Date();

    try {
      // Step 1: Connect the adapter to Chrome (to any available tab).
      //         We need a live CRI client to call Target.createTarget.
      await this._adapter.connect();

      // Step 2: Open a fresh blank tab for this test run.
      this._targetId = await this._adapter.createTarget('about:blank');
      console.log(`[BrowserSession] Opened tab ${this._targetId} for run ${runId}`);

      // Step 3: Disconnect from the "default" target.
      await this._adapter.disconnect();

      // Step 4: Give Chrome a moment to register the new tab in /json/list.
      //         Without this delay, CRI may 404 when trying to connect to the
      //         new targetId because it hasn't been published yet.
      await new Promise((r) => setTimeout(r, 250));

      // Step 5: Reconnect scoped to our new tab.
      //         CRI resolves the targetId by matching it against /json/list.
      await this._connectWithRetry(this._targetId);

      // Step 6: Enable all domains required for test execution.
      await this._adapter.enableDomains();

      this._state = 'ready';
      console.log(`[BrowserSession] Session ready for run ${runId}`);
    } catch (err) {
      this._state = 'closed';
      throw new Error(`[BrowserSession] Failed to open session for run ${runId}: ${err.message}`);
    }
  }

  /**
   * Connect the adapter to a specific targetId with up to 3 retries.
   * Retries handle the race where Chrome's /json/list is stale for a moment
   * after Target.createTarget returns.
   *
   * @param {string} targetId
   */
  async _connectWithRetry(targetId, attempts = 3) {
    for (let i = 1; i <= attempts; i++) {
      try {
        await this._adapter.connect(targetId);
        return;
      } catch (err) {
        if (i === attempts) throw err;
        console.warn(`[BrowserSession] Connect attempt ${i} failed — retrying in 300 ms…`);
        await new Promise((r) => setTimeout(r, 300));
      }
    }
  }

  /**
   * Close the tab and disconnect CDP.
   * Safe to call in any state — will not throw.
   */
  async close() {
    if (this._state === 'closed' || this._state === 'closing') return;

    this._state = 'closing';
    console.log(`[BrowserSession] Closing session for run ${this._runId}`);

    try {
      if (this._targetId) {
        // Best-effort tab close; ignore errors (e.g. if Chrome already exited)
        await this._adapter.closeTarget(this._targetId).catch(() => {});
      }
    } finally {
      await this._adapter.disconnect().catch(() => {});
      this._state = 'closed';
      console.log(`[BrowserSession] Session closed for run ${this._runId}`);
    }
  }

  // ── Accessors ──────────────────────────────────────────────────────────────

  /** The underlying CDPAdapter.  Only valid when state === 'ready'. */
  get adapter() {
    return this._adapter;
  }

  /** The TestRun ObjectId string associated with this session. */
  get runId() {
    return this._runId;
  }

  /** Current session state: idle | opening | ready | closing | closed */
  get state() {
    return this._state;
  }

  /** When the session was opened (null if not yet open). */
  get createdAt() {
    return this._createdAt;
  }

  /** True if the session can accept work. */
  get isReady() {
    return this._state === 'ready';
  }
}

module.exports = BrowserSession;
