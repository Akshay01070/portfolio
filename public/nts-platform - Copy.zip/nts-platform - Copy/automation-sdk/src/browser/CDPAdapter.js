'use strict';

const CDP = require('chrome-remote-interface');
const env = require('../config/env');

/**
 * CDPAdapter.js — Thin, typed wrapper over chrome-remote-interface.
 *
 * ── Purpose ───────────────────────────────────────────────────────────────────
 *
 * chrome-remote-interface (CRI) gives us raw CDP domain access. CDPAdapter
 * adds:
 *   - A consistent async/await API (all CRI callbacks become Promises)
 *   - Named, documented methods so callers never touch raw CDP commands
 *   - Per-method error wrapping with descriptive messages
 *   - Lifecycle management (connect / disconnect)
 *
 * ── CDP Domains used in M4 ───────────────────────────────────────────────────
 *
 *   Page     — navigation (Page.navigate, Page.loadEventFired)
 *   Runtime  — JS evaluation (Runtime.evaluate)
 *   DOM      — DOM querying (DOM.querySelector, DOM.getDocument)
 *   Input    — synthetic events (Input.dispatchMouseEvent, Input.dispatchKeyEvent)
 *   Network  — request/response events (enabled for future HAR support)
 *   Target   — tab management (Target.createTarget, Target.attachToTarget)
 *
 * Additional domains (Emulation, Fetch, Security) are added in later milestones.
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   connect(targetId?)  → connects to a specific tab or the first available one
 *   disconnect()        → closes the CDP WebSocket
 *   enableDomains()     → enables Page, Runtime, DOM, Input, Network
 *
 *   Page:
 *     navigate(url, timeout?)         → navigates and waits for load
 *     waitForLoad(timeout?)           → resolves on Page.loadEventFired
 *
 *   Runtime:
 *     evaluate(expression, opts?)     → executes JS and returns result
 *
 *   DOM:
 *     getDocumentNode()               → returns root DOM node
 *     querySelector(nodeId, selector) → returns child nodeId
 *     getBoxModel(nodeId)             → returns element bounding box
 *
 *   Input:
 *     click(x, y)                     → synthetic left-click at (x, y)
 *     typeText(text)                  → types a string character by character
 *
 *   Target:
 *     createTarget(url?)              → opens a new tab, returns targetId
 *     closeTarget(targetId)           → closes a tab
 *
 *   Page (additional):
 *     captureScreenshot(format?, quality?) → base64-encoded image data
 */

const DEFAULT_NAVIGATE_TIMEOUT_MS = 30_000;

class CDPAdapter {
  constructor() {
    this._client = null;
    this._port = env.CHROME_DEBUGGING_PORT;
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  /**
   * Connect to Chrome via CDP.
   *
   * @param {string} [targetId] — connect to a specific Target; defaults to first tab
   */
  async connect(targetId) {
    const options = { port: this._port };
    if (targetId) options.target = targetId;

    try {
      this._client = await CDP(options);
      console.log('[CDPAdapter] Connected to Chrome CDP');
    } catch (err) {
      throw new Error(`[CDPAdapter] Failed to connect to CDP on port ${this._port}: ${err.message}`);
    }
  }

  /**
   * Disconnect from Chrome CDP.
   */
  async disconnect() {
    if (!this._client) return;
    try {
      await this._client.close();
      console.log('[CDPAdapter] Disconnected from CDP');
    } catch (err) {
      console.warn('[CDPAdapter] Error closing CDP connection:', err.message);
    } finally {
      this._client = null;
    }
  }

  /**
   * Enable all required CDP domains for a test session.
   * Must be called after connect() before any other methods.
   */
  async enableDomains() {
    this._assertConnected();
    const { Page, Runtime, DOM, Network } = this._client;
    await Promise.all([
      Page.enable(),
      Runtime.enable(),
      DOM.enable(),
      Network.enable(),
    ]);
    console.log('[CDPAdapter] Domains enabled: Page, Runtime, DOM, Network');
  }

  // ── Page ───────────────────────────────────────────────────────────────────

  /**
   * Navigate to a URL, wait for the page load event, and validate the HTTP
   * status of the main-document response.
   *
   * ── Why two layers of error detection ────────────────────────────────────
   *
   *  Layer 1 — CDP/network-level (existing):
   *    Page.navigate() returns errorText for low-level failures such as
   *    ERR_NAME_NOT_RESOLVED or ERR_CONNECTION_REFUSED.  These never produce
   *    an HTTP response at all.
   *
   *  Layer 2 — HTTP status (new):
   *    When a server responds with 4xx or 5xx, Chrome still successfully
   *    "navigates" to the error page and fires Page.loadEventFired.
   *    navResult.errorText is NOT set.  We must inspect the HTTP status
   *    from Network.responseReceived to catch these.
   *
   * ── Response correlation ──────────────────────────────────────────────────
   *
   *  Network.responseReceived fires for every resource (HTML, JS, CSS, images).
   *  We identify the MAIN DOCUMENT response by requiring BOTH:
   *    • params.loaderId  === navResult.loaderId   (ties this request to our navigation)
   *    • params.frameId   === navResult.frameId    (scopes to the top-level frame)
   *    • params.type      === 'Document'           (excludes sub-resources)
   *
   *  We keep updating the stored response on each match so the LAST stored
   *  value is the final response after any redirect chain.
   *
   * ── Redirect handling ─────────────────────────────────────────────────────
   *
   *  Chrome follows redirects automatically.  Each hop fires its own
   *  responseReceived event (e.g. 302, then 200).  Because we always
   *  overwrite with the latest match, the stored response after loadEventFired
   *  is always the final, post-redirect HTTP status.
   *
   * ── Listener lifecycle ────────────────────────────────────────────────────
   *
   *  CRI returns an unsubscribe function from every event subscription.
   *  We call it in a `finally` block so the listener is always removed,
   *  even on timeout, CDP error, or HTTP error.  This prevents listener leaks
   *  across repeated navigate() calls.
   *
   * @param {string} url
   * @param {number} [timeoutMs]
   * @returns {Promise<object>} CDP navigation result ({ frameId, loaderId, ... })
   */
  async navigate(url, timeoutMs = DEFAULT_NAVIGATE_TIMEOUT_MS) {
    this._assertConnected();
    const { Page, Network } = this._client;

    let loadResolve;
    let loadReject;
    let loadTimer;

    // ── Step 1: Register Network.responseReceived BEFORE Page.navigate ──────
    //
    // Attaching early guarantees we do not miss fast responses (e.g. a server
    // that replies before Page.navigate()'s Promise even resolves).
    //
    // mainDocResponse holds the most-recently-seen Document response that
    // matches our loaderId + frameId.  It starts as null; if it is still null
    // after loadEventFired we treat that as an error.
    let mainDocResponse = null;

    const responseHandler = Network.responseReceived((params) => {
      // Only capture main-document responses for our specific navigation.
      // We defer the loaderId/frameId filter until after Page.navigate()
      // returns those values, so we collect ALL Document responses and filter
      // retroactively via the navLoaderId / navFrameId closure variables set
      // below.  This is safe because the closure variables are set before any
      // awaited microtask that would process collected events.
      if (params.type === 'Document') {
        pendingResponses.push(params);
      }
    });

    // Staging array: Document responses captured before we have navResult.
    const pendingResponses = [];

    // ── Step 2: Load event promise ───────────────────────────────────────────
    const loadPromise = new Promise((resolve, reject) => {
      loadResolve = resolve;
      loadReject  = reject;
    });

    const loadHandler = Page.loadEventFired(() => {
      clearTimeout(loadTimer);
      loadResolve();
    });

    loadTimer = setTimeout(() => {
      if (typeof loadHandler    === 'function') loadHandler();    // unsubscribe
      loadReject(
        new Error(`[CDPAdapter] Navigation to "${url}" timed out after ${timeoutMs} ms`)
      );
    }, timeoutMs);

    // ── Step 3: Navigate + validate ──────────────────────────────────────────
    try {
      // Trigger the navigation; capture loaderId and frameId for correlation.
      const navResult = await Page.navigate({ url });

      // ── Layer 1: CDP/network-level error (existing check — must be kept) ──
      if (navResult.errorText) {
        clearTimeout(loadTimer);
        throw new Error(
          `[CDPAdapter] Navigation to "${url}" failed — Chrome error: ${navResult.errorText}`
        );
      }

      const navLoaderId = navResult.loaderId;
      const navFrameId  = navResult.frameId;

      // ── Real-time response filter ─────────────────────────────────────────
      //
      // Now that we have navLoaderId + navFrameId, retroactively scan any
      // Document responses that arrived before Page.navigate() resolved,
      // then continue to match new events via the live handler below.
      //
      // We replace the generic responseHandler with a targeted one.
      // First, drain pending responses captured so far:
      for (const p of pendingResponses) {
        if (p.loaderId === navLoaderId && p.frameId === navFrameId) {
          mainDocResponse = p.response; // keep updating for redirect chain
        }
      }

      // Replace the broad listener with a targeted one that filters in real-time.
      // We unsubscribe the original and re-subscribe with exact correlation.
      if (typeof responseHandler === 'function') responseHandler();

      const targetedHandler = Network.responseReceived((params) => {
        if (
          params.type     === 'Document'   &&
          params.loaderId === navLoaderId  &&
          params.frameId  === navFrameId
        ) {
          // Always overwrite — last response wins (handles redirect chain).
          mainDocResponse = params.response;
        }
      });

      // Wait for the page to fully load (or timeout).
      try {
        await loadPromise;
      } finally {
        // ── Step 4: Always remove the targeted Network listener ─────────────
        if (typeof targetedHandler === 'function') targetedHandler();
      }

      // ── Layer 2: HTTP status validation ───────────────────────────────────
      //
      // After the load event we inspect the final main-document HTTP status.
      // If no matching response was captured we surface a clear error rather
      // than silently passing (this covers unusual cases such as browser
      // serving from cache with no network event, or a bug in correlation).
      if (!mainDocResponse) {
        throw new Error(
          `[CDPAdapter] Navigation to "${url}" failed: ` +
          `main document HTTP response was not captured. ` +
          `Ensure Network domain is enabled before navigation.`
        );
      }

      const { status, statusText } = mainDocResponse;

      if (status >= 400) {
        throw new Error(
          `[CDPAdapter] Navigation to "${url}" failed:\nHTTP ${status} ${statusText}`
        );
      }

      return navResult;

    } catch (err) {
      clearTimeout(loadTimer);
      // Ensure the broad listener is always cleaned up on early exit
      // (before targetedHandler was installed).
      if (typeof responseHandler === 'function') {
        try { responseHandler(); } catch (_) { /* already unsubscribed */ }
      }
      throw err;
    }
  }

  /**
   * Wait for the Page.loadEventFired CDP event.
   *
   * Used by tests that navigate without using the full navigate() method
   * (e.g. clicking a link that triggers navigation).
   *
   * @param {number} [timeoutMs]
   * @returns {Promise<void>}
   */
  waitForLoad(timeoutMs = DEFAULT_NAVIGATE_TIMEOUT_MS) {
    this._assertConnected();
    const { Page } = this._client;

    return new Promise((resolve, reject) => {
      let timer;
      const handler = Page.loadEventFired(() => {
        clearTimeout(timer);
        resolve();
      });

      timer = setTimeout(() => {
        if (typeof handler === 'function') handler(); // unsubscribe
        reject(new Error(`[CDPAdapter] waitForLoad timed out after ${timeoutMs} ms`));
      }, timeoutMs);
    });
  }

  /**
   * Get the current page URL via Runtime.evaluate.
   *
   * @returns {Promise<string>}
   */
  async getCurrentUrl() {
    const result = await this.evaluate('window.location.href');
    return result.value;
  }

  // ── Runtime ────────────────────────────────────────────────────────────────

  /**
   * Evaluate a JavaScript expression in the page context.
   *
   * @param {string} expression
   * @param {object} [opts]  — extra Runtime.evaluate params (e.g. returnByValue)
   * @returns {Promise<{type, value, description}>} result.result from CDP
   */
  async evaluate(expression, opts = {}) {
    this._assertConnected();
    const { Runtime } = this._client;

    const { result, exceptionDetails } = await Runtime.evaluate({
      expression,
      returnByValue: true,
      awaitPromise: true,
      ...opts,
    });

    if (exceptionDetails) {
      const msg = exceptionDetails.text ||
        exceptionDetails.exception?.description ||
        'Unknown JS error';
      throw new Error(`[CDPAdapter] JS evaluation error: ${msg}`);
    }

    return result;
  }

  // ── DOM ────────────────────────────────────────────────────────────────────

  /**
   * Get the root document node.
   *
   * @returns {Promise<object>} DOM.Node
   */
  async getDocumentNode() {
    this._assertConnected();
    const { DOM } = this._client;
    const { root } = await DOM.getDocument({ depth: 0 });
    return root;
  }

  /**
   * Query for a single element matching a CSS selector.
   *
   * @param {string} selector
   * @param {number} [contextNodeId] — default: root document
   * @returns {Promise<number>} nodeId (0 if not found)
   */
  async querySelector(selector, contextNodeId) {
    this._assertConnected();
    const { DOM } = this._client;

    let rootNodeId = contextNodeId;
    if (!rootNodeId) {
      const root = await this.getDocumentNode();
      rootNodeId = root.nodeId;
    }

    const { nodeId } = await DOM.querySelector({ nodeId: rootNodeId, selector });
    return nodeId; // 0 means not found
  }

  /**
   * Get the bounding box of an element.
   *
   * @param {number} nodeId
   * @returns {Promise<object>} { content, padding, border, margin, width, height }
   */
  async getBoxModel(nodeId) {
    this._assertConnected();
    const { DOM } = this._client;
    const { model } = await DOM.getBoxModel({ nodeId });
    return model;
  }

  /**
   * Get the center point (x, y) of an element — used for click targeting.
   *
   * @param {number} nodeId
   * @returns {Promise<{x: number, y: number}>}
   */
  async getElementCenter(nodeId) {
    const box = await this.getBoxModel(nodeId);
    // content is [x1,y1, x2,y2, x3,y3, x4,y4] (quad)
    const [x1, y1, x2, , , y3] = box.content;
    return {
      x: Math.round((x1 + x2) / 2),
      y: Math.round((y1 + y3) / 2),
    };
  }

  // ── Input ──────────────────────────────────────────────────────────────────

  /**
   * Dispatch a synthetic left-click at viewport coordinates (x, y).
   *
   * @param {number} x
   * @param {number} y
   */
  async click(x, y) {
    this._assertConnected();
    const { Input } = this._client;

    await Input.dispatchMouseEvent({ type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
    await Input.dispatchMouseEvent({ type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
  }

  /**
   * Type a string into the focused element, character by character.
   *
   * @param {string} text
   */
  async typeText(text) {
    this._assertConnected();
    const { Input } = this._client;

    for (const char of text) {
      await Input.dispatchKeyEvent({ type: 'keyDown',  text: char });
      await Input.dispatchKeyEvent({ type: 'keyUp',    text: char });
    }
  }

  /**
   * Clear an input field and type new text.
   * Uses Ctrl+A → Delete to clear, then types the new value.
   *
   * @param {string} text
   */
  async clearAndType(text) {
    this._assertConnected();
    const { Input } = this._client;

    // Select all
    await Input.dispatchKeyEvent({ type: 'keyDown', key: 'a', modifiers: 2 /* Ctrl */ });
    await Input.dispatchKeyEvent({ type: 'keyUp',   key: 'a', modifiers: 2 });

    // Delete selection
    await Input.dispatchKeyEvent({ type: 'keyDown', key: 'Delete' });
    await Input.dispatchKeyEvent({ type: 'keyUp',   key: 'Delete' });

    // Type new value
    await this.typeText(text);
  }

  // ── Target (tab management) ───────────────────────────────────────────────

  /**
   * Create a new browser tab.
   *
   * @param {string} [url='about:blank']
   * @returns {Promise<string>} targetId of the new tab
   */
  async createTarget(url = 'about:blank') {
    this._assertConnected();
    const { Target } = this._client;
    const { targetId } = await Target.createTarget({ url });
    return targetId;
  }

  /**
   * Close a browser tab by targetId.
   *
   * @param {string} targetId
   */
  async closeTarget(targetId) {
    this._assertConnected();
    const { Target } = this._client;
    await Target.closeTarget({ targetId });
  }

  // ── Page (additional) ────────────────────────────────────────────────────

  /**
   * Capture a screenshot of the current viewport.
   *
   * This is the ONLY place in the codebase that may call
   * Page.captureScreenshot directly; all other modules must use this method.
   *
   * @param {'png'|'jpeg'|'webp'} [format='png']
   * @param {number} [quality=90]  — 0-100, only used for jpeg/webp
   * @returns {Promise<string>} base64-encoded image data
   */
  async captureScreenshot(format = 'png', quality = 90) {
    this._assertConnected();
    const { Page } = this._client;
    const { data } = await Page.captureScreenshot({ format, quality });
    return data;
  }

  /**
   * Returns the underlying chrome-remote-interface client.
   * Raw access is intentionally narrow — prefer the typed methods above.
   * Do NOT call CDP domain commands (e.g. Page.captureScreenshot) outside
   * this class; add a typed wrapper method here instead.
   */
  get rawClient() {
    return this._client;
  }

  // ── Internal ───────────────────────────────────────────────────────────────

  _assertConnected() {
    if (!this._client) {
      throw new Error('[CDPAdapter] Not connected — call connect() first');
    }
  }
}

module.exports = CDPAdapter;
