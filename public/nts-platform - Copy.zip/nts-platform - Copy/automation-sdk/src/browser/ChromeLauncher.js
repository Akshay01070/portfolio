'use strict';

const { spawn } = require('child_process');
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');
const env = require('../config/env');

/**
 * ChromeLauncher.js — Spawns and manages the Chrome process.
 *
 * ── What it does ─────────────────────────────────────────────────────────────
 *
 *  1. Spawns Chrome with `--remote-debugging-port` so it exposes the CDP WebSocket.
 *  2. Polls the /json/version HTTP endpoint until Chrome is ready (or timeout).
 *  3. Exposes `kill()` to terminate the Chrome process cleanly.
 *
 * ── Chrome flags used ────────────────────────────────────────────────────────
 *
 *  --remote-debugging-port=N   Enable CDP on port N
 *  --headless=new              Run without a display (GPU-composited headless mode)
 *  --no-sandbox                Required in Docker/CI where there is no user namespace
 *  --disable-gpu               Disable GPU acceleration in headless mode
 *  --disable-dev-shm-usage     Prevent /dev/shm OOM in Docker
 *  --no-first-run              Skip Chrome's first-run wizard
 *  --no-default-browser-check  Skip "make Chrome default browser?" prompt
 *  --disable-extensions        No extensions in automated sessions
 *  --user-data-dir=...         Isolated profile per session (temp dir)
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   launch()   → Promise<void>  — starts Chrome, waits until CDP is ready
 *   kill()     → void           — terminates the Chrome process
 *   isAlive()  → boolean        — true if the process is running
 */

const CDP_POLL_INTERVAL_MS = 250;

class ChromeLauncher {
  constructor() {
    this._process = null;
    this._port = env.CHROME_DEBUGGING_PORT;
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  /**
   * Launch Chrome and wait until the CDP endpoint is responsive.
   *
   * @throws {Error} if Chrome does not start within CHROME_LAUNCH_TIMEOUT_MS
   */
  async launch() {
    if (this._process) {
      console.warn('[ChromeLauncher] Chrome is already running');
      return;
    }

    if (await this._isPortInUse(this._port)) {
      throw new Error(`CDP port ${this._port} is already in use.`);
    }

    const args = this._buildChromeArgs();

    console.log(`[ChromeLauncher] Spawning Chrome: ${env.CHROME_PATH}`);
    console.log(`[ChromeLauncher] Headless: ${env.HEADLESS}`);
    console.log(`[ChromeLauncher] CDP port: ${this._port}`);
    console.log(`[ChromeLauncher] Chrome arguments: ${JSON.stringify(args)}`);

    await this._spawnAndWaitForCDP(args);
    console.log('[ChromeLauncher] Chrome is ready');
  }

  /**
   * Kill the Chrome process.
   */
  kill() {
    if (!this._process) return;
    console.log('[ChromeLauncher] Killing Chrome…');
    this._process.kill('SIGTERM');
    // Force-kill after 3 s if still alive
    setTimeout(() => {
      if (this._process) {
        this._process.kill('SIGKILL');
      }
    }, 3000).unref();
  }

  /**
   * Returns true if the Chrome process is currently running.
   */
  isAlive() {
    return this._process !== null && !this._process.killed;
  }

  // ── Private helpers ────────────────────────────────────────────────────────

  /**
   * Build Chrome CLI arguments. HEADLESS=true adds --headless=new; HEADLESS=false
   * uses a dedicated temporary user-data-dir instead.
   *
   * @returns {string[]}
   */
  _buildChromeArgs() {
    const args = [
      `--remote-debugging-port=${this._port}`,
      '--no-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-extensions',
      '--disable-background-networking',
      '--disable-client-side-phishing-detection',
      '--disable-default-apps',
      '--disable-hang-monitor',
      '--disable-popup-blocking',
      '--disable-prompt-on-repost',
      '--disable-sync',
      '--metrics-recording-only',
      '--safebrowsing-disable-auto-update',
    ];

    if (env.HEADLESS) {
      args.push('--headless=new');
    } else {
      const userDataDir = path.join(os.tmpdir(), `automation-sdk-chrome-${this._port}`);
      fs.mkdirSync(userDataDir, { recursive: true });
      args.push(`--user-data-dir=${userDataDir}`);
    }

    return args;
  }

  /**
   * Returns true when something is already listening on the CDP port.
   *
   * @param {number} port
   * @returns {Promise<boolean>}
   */
  _isPortInUse(port) {
    return new Promise((resolve) => {
      const server = net.createServer();
      server.once('error', (err) => {
        resolve(err.code === 'EADDRINUSE');
      });
      server.once('listening', () => {
        server.close(() => resolve(false));
      });
      server.listen(port, '127.0.0.1');
    });
  }

  /**
   * Spawn Chrome and poll GET http://localhost:{port}/json/version until ready.
   * Rejects immediately on spawn error or if Chrome exits before CDP is available.
   *
   * @param {string[]} args
   * @returns {Promise<void>}
   */
  _spawnAndWaitForCDP(args) {
    const http = require('http');
    const deadline = Date.now() + env.CHROME_LAUNCH_TIMEOUT_MS;
    const stderrChunks = [];
    let pollTimer = null;
    let settled = false;

    const cleanupPoll = () => {
      if (pollTimer !== null) {
        clearTimeout(pollTimer);
        pollTimer = null;
      }
    };

    const getStderr = () => Buffer.concat(stderrChunks).toString('utf8').trim();

    const appendStderr = (message) => {
      const stderr = getStderr();
      return stderr ? `${message}\n${stderr}` : message;
    };

    return new Promise((resolve, reject) => {
      const succeed = () => {
        if (settled) return;
        settled = true;
        cleanupPoll();
        resolve();
      };

      const fail = (message) => {
        if (settled) return;
        settled = true;
        cleanupPoll();
        reject(new Error(message));
      };

      this._process = spawn(env.CHROME_PATH, args, {
        stdio: 'pipe',
      });

      this._process.stdout.on('data', (data) => {
        const line = data.toString().trim();
        if (line) console.log(`[Chrome:stdout] ${line}`);
      });

      this._process.stderr.on('data', (data) => {
        stderrChunks.push(data);
        const line = data.toString().trim();
        if (line) console.log(`[Chrome:stderr] ${line}`);
      });

      this._process.on('error', (err) => {
        console.error(`[ChromeLauncher] Failed to spawn Chrome: ${err.message}`);
        this._process = null;
        fail(`[ChromeLauncher] Failed to spawn Chrome: ${err.message}`);
      });

      this._process.on('exit', (code, signal) => {
        console.log(`[ChromeLauncher] Chrome exited — code=${code} signal=${signal}`);
        this._process = null;
        if (!settled) {
          fail(
            appendStderr(
              `[ChromeLauncher] Chrome exited before CDP was ready — code=${code} signal=${signal}`
            )
          );
        }
      });

      const poll = () => {
        if (settled) return;

        if (Date.now() > deadline) {
          fail(
            appendStderr(
              `[ChromeLauncher] Chrome did not start within ${env.CHROME_LAUNCH_TIMEOUT_MS} ms`
            )
          );
          this.kill();
          return;
        }

        const req = http.get(
          `http://localhost:${this._port}/json/version`,
          (res) => {
            if (res.statusCode === 200) {
              succeed();
              return;
            }
            pollTimer = setTimeout(poll, CDP_POLL_INTERVAL_MS);
          }
        );

        req.on('error', () => {
          pollTimer = setTimeout(poll, CDP_POLL_INTERVAL_MS);
        });

        req.end();
      };

      pollTimer = setTimeout(poll, 500);
    });
  }
}

module.exports = ChromeLauncher;
