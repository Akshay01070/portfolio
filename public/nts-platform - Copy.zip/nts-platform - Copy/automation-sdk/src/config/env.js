'use strict';

require('dotenv').config();

/**
 * src/config/env.js — Validates and exports all SDK environment variables.
 *
 * All modules must import from here — never read process.env directly.
 * This gives a fast, clear failure at startup for missing required config.
 */

function required(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`[env] Missing required environment variable: ${name}`);
  }
  return value;
}

function optional(name, defaultValue) {
  return process.env[name] || defaultValue;
}

function parseBoolean(name, defaultValue) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') {
    return defaultValue;
  }
  const normalized = raw.trim().toLowerCase();
  if (normalized === 'true' || normalized === '1') return true;
  if (normalized === 'false' || normalized === '0') return false;
  throw new Error(`[env] Invalid boolean for ${name}: "${raw}". Use true or false.`);
}

const env = {
  // SDK HTTP server
  PORT:     parseInt(optional('PORT', '8080'), 10),
  NODE_ENV: optional('NODE_ENV', 'development'),

  // Backend base URL (for posting events, artifacts, completion)
  BACKEND_URL: optional('BACKEND_URL', 'http://localhost:3000'),

  // Chrome binary path — required so we fail fast if not configured
  CHROME_PATH: optional(
    'CHROME_PATH',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
  ),

  // The CDP remote-debugging port Chrome listens on
  CHROME_DEBUGGING_PORT: parseInt(optional('CHROME_DEBUGGING_PORT', '9222'), 10),

  // How long (ms) to wait for Chrome to start before giving up
  CHROME_LAUNCH_TIMEOUT_MS: parseInt(optional('CHROME_LAUNCH_TIMEOUT_MS', '15000'), 10),

  // Maximum concurrent browser sessions (V1 = 1; expanded in later milestones)
  MAX_SESSIONS: parseInt(optional('MAX_SESSIONS', '1'), 10),

  // Run Chrome headless (true) or with a visible window for debugging (false)
  HEADLESS: parseBoolean('HEADLESS', true),
};

module.exports = env;
