'use strict';

const axios = require('axios');
const env = require('../config/env');

/**
 * ExecutionReporter.js — Posts execution events and results back to the backend.
 *
 * ── Purpose ───────────────────────────────────────────────────────────────────
 *
 * During and after a test run, the SDK must report progress to the backend so
 * that the dashboard and database stay in sync.  ExecutionReporter is the
 * single module responsible for all outbound HTTP calls to the backend.
 *
 * All methods are fire-and-forget safe:
 *   - Network errors are logged but NOT re-thrown so a reporting failure
 *     never crashes the runner itself.
 *
 * ── Backend Endpoints (from M3 src/routes/sdk.js) ────────────────────────────
 *
 *   POST /api/sdk/runs/:runId/events      — one ExecutionEvent
 *   POST /api/sdk/runs/:runId/complete    — terminal state (PASSED/FAILED/etc.)
 *   POST /api/sdk/runs/:runId/artifacts   — a saved file
 *   POST /api/sdk/heartbeat               — periodic alive signal
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   event(runId, type, payload?)         → post one event (fire-and-forget)
 *   stepStarted(runId, index)            → shortcut for STEP_STARTED
 *   stepPassed(runId, index, durationMs) → shortcut for STEP_PASSED
 *   stepFailed(runId, index, error)      → shortcut for STEP_FAILED
 *   runStarted(runId)                    → shortcut for RUN_STARTED
 *   complete(runId, status, error?)      → POST /complete (awaited)
 *   artifact(runId, meta)               → POST /artifacts (fire-and-forget)
 */

class ExecutionReporter {
  constructor() {
    this._backendUrl = env.BACKEND_URL;

    // Axios instance with base URL + short timeout so a slow backend
    // does not block the runner.
    this._http = axios.create({
      baseURL: this._backendUrl,
      timeout: 8_000,
    });
  }

  // ── Event shortcuts ────────────────────────────────────────────────────────

  /** POST RUN_STARTED event */
  runStarted(runId) {
    return this._postEvent(runId, 'RUN_STARTED', {});
  }

  /** POST STEP_STARTED event */
  stepStarted(runId, stepIndex) {
    return this._postEvent(runId, 'STEP_STARTED', {}, stepIndex);
  }

  /** POST STEP_PASSED event */
  stepPassed(runId, stepIndex, durationMs) {
    return this._postEvent(runId, 'STEP_PASSED', {}, stepIndex, durationMs);
  }

  /** POST STEP_FAILED event */
  stepFailed(runId, stepIndex, error, durationMs) {
    return this._postEvent(
      runId,
      'STEP_FAILED',
      { error: error instanceof Error ? error.message : String(error) },
      stepIndex,
      durationMs
    );
  }

  /** POST SCREENSHOT event */
  screenshot(runId, stepIndex, data) {
    return this._postEvent(runId, 'SCREENSHOT', data, stepIndex);
  }

  /** POST LOG event */
  log(runId, level, message, stepIndex = null) {
    return this._postEvent(runId, 'LOG', { level, message }, stepIndex);
  }

  /** POST ERROR event */
  error(runId, message, stack) {
    return this._postEvent(runId, 'ERROR', { message, stack });
  }

  // ── Completion ─────────────────────────────────────────────────────────────

  /**
   * POST /api/sdk/runs/:runId/complete
   *
   * This IS awaited — completing the run is the last thing the runner does,
   * and we want to know if it failed.
   *
   * @param {string} runId
   * @param {'PASSED'|'FAILED'|'STOPPED'|'TIMEOUT'} status
   * @param {string|null} [errorMessage]
   */
  async complete(runId, status, errorMessage = null) {
    const body = { status };
    if (errorMessage) body.error = errorMessage;

    try {
      await this._http.post(`/api/sdk/runs/${runId}/complete`, body);
      console.log(`[ExecutionReporter] Run ${runId} → ${status}`);
    } catch (err) {
      console.error(
        `[ExecutionReporter] Failed to report completion for run ${runId}:`,
        err.message
      );
      // Don't re-throw — the run has still finished on the SDK side.
    }
  }

  // ── Artifacts ──────────────────────────────────────────────────────────────

  /**
   * POST /api/sdk/runs/:runId/artifacts
   *
   * @param {string} runId
   * @param {{ type, filename, storagePath, mimeType?, sizeBytes?, stepIndex? }} meta
   */
  artifact(runId, meta) {
    this._http
      .post(`/api/sdk/runs/${runId}/artifacts`, meta)
      .then(() => {
        console.log(`[ExecutionReporter] Artifact registered: ${meta.filename}`);
      })
      .catch((err) => {
        console.error(`[ExecutionReporter] Failed to register artifact:`, err.message);
      });
  }

  // ── Heartbeat ─────────────────────────────────────────────────────────────

  /**
   * POST /api/sdk/heartbeat
   * Called periodically by the SDK process to keep the Environment status live.
   *
   * @param {string} environmentId
   * @param {'AVAILABLE'|'BUSY'} status
   */
  heartbeat(environmentId, status) {
    this._http
      .post('/api/sdk/heartbeat', { environmentId, status })
      .catch((err) => {
        console.warn('[ExecutionReporter] Heartbeat failed:', err.message);
      });
  }

  // ── Internal ──────────────────────────────────────────────────────────────

  /**
   * Fire-and-forget POST of an ExecutionEvent.
   */
  _postEvent(runId, type, data = {}, stepIndex = null, durationMs = null) {
    const body = {
      type,
      stepIndex,
      durationMs,
      data,
      timestamp: new Date().toISOString(),
    };

    this._http
      .post(`/api/sdk/runs/${runId}/events`, body)
      .catch((err) => {
        console.warn(`[ExecutionReporter] Failed to post event ${type} for run ${runId}:`, err.message);
      });
  }
}

module.exports = new ExecutionReporter();
