'use strict';

const { waitForSelector } = require('./WaitEngine');

/**
 * Locator.js — Resolves a CSS selector to a visible DOM element, with wait.
 *
 * ── Why a Locator? ────────────────────────────────────────────────────────────
 *
 * Raw `CDP querySelector` returns 0 (not found) immediately if the element is
 * not yet in the DOM.  In real test scenarios, elements appear asynchronously
 * (after navigation, after an AJAX call, after a CSS transition).
 *
 * Locator wraps `WaitEngine.waitForSelector` so that every step that needs
 * a DOM element automatically waits for it to be present before proceeding.
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   Locator.resolve(adapter, selector, timeout?)
 *     — Waits for the element then returns its nodeId.
 *     — Throws a descriptive error if not found within timeout.
 *
 *   Locator.resolveWithCenter(adapter, selector, timeout?)
 *     — Waits for the element, computes its center (x, y) for clicking.
 *     — Returns { nodeId, x, y }.
 *
 *   Locator.isPresent(adapter, selector)
 *     — Synchronous-ish check: returns true if the element is in the DOM RIGHT NOW.
 *     — Does NOT wait. Used by assertVisible.
 */

class Locator {
  /**
   * Wait for the element and return its nodeId.
   *
   * @param {import('../browser/CDPAdapter')} adapter
   * @param {string} selector
   * @param {number} [timeoutMs]
   * @returns {Promise<number>} nodeId
   */
  static async resolve(adapter, selector, timeoutMs) {
    return waitForSelector(adapter, selector, timeoutMs);
  }

  /**
   * Wait for the element, then compute its center point for click dispatch.
   *
   * @param {import('../browser/CDPAdapter')} adapter
   * @param {string} selector
   * @param {number} [timeoutMs]
   * @returns {Promise<{nodeId: number, x: number, y: number}>}
   */
  static async resolveWithCenter(adapter, selector, timeoutMs) {
    const nodeId = await waitForSelector(adapter, selector, timeoutMs);

    let center;
    try {
      center = await adapter.getElementCenter(nodeId);
    } catch (err) {
      throw new Error(
        `[Locator] Element found but not interactable (no box model): "${selector}" — ${err.message}`
      );
    }

    return { nodeId, ...center };
  }

  /**
   * Check if an element matching `selector` is present in the DOM right now.
   * Does NOT wait — returns false immediately if not found.
   *
   * @param {import('../browser/CDPAdapter')} adapter
   * @param {string} selector
   * @returns {Promise<boolean>}
   */
  static async isPresent(adapter, selector) {
    try {
      const nodeId = await adapter.querySelector(selector);
      return nodeId !== 0;
    } catch (_) {
      return false;
    }
  }

  /**
   * Check if an element is both present in the DOM AND has a visible box model.
   *
   * @param {import('../browser/CDPAdapter')} adapter
   * @param {string} selector
   * @returns {Promise<boolean>}
   */
  static async isVisible(adapter, selector) {
    try {
      const nodeId = await adapter.querySelector(selector);
      if (!nodeId) return false;

      const box = await adapter.getBoxModel(nodeId);
      return box && box.width > 0 && box.height > 0;
    } catch (_) {
      return false;
    }
  }
}

module.exports = Locator;
