'use strict';

const browserManager = require('../browser/BrowserManager');
const reporter = require('../reporter/ExecutionReporter');

/**
 * Runner.js — Executes a TestCase's steps inside a BrowserSession.
 *
 * ── Position in the architecture ─────────────────────────────────────────────
 *
 *   POST /execute
 *       │
 *   Runner.execute(job)
 *       │
 *       ├── BrowserManager.openSession(runId)   → BrowserSession
 *       │         └── ChromeLauncher + CDPAdapter
 *       │
 *       ├── ExecutionReporter.runStarted(runId)
 *       │
 *       ├── for each step:
 *       │     ├── ExecutionReporter.stepStarted(...)
 *       │     ├── executeStep(step, adapter)     ← calls CDPAdapter methods
 *       │     └── ExecutionReporter.stepPassed/stepFailed(...)
 *       │
 *       ├── ExecutionReporter.complete(runId, status)
 *       └── BrowserManager.closeSession(runId)
 *
 * ── Step Execution (M4 scope) ─────────────────────────────────────────────────
 *
 *  In M4 we wire the full execution pipeline.  The step handlers themselves
 *  are stubs — they will be filled in fully in M5 (goto), M6 (click/fill/type),
 *  and M7 (assertions/screenshots).  This gives us a working end-to-end flow
 *  from the backend dispatch through the browser and back.
 *
 * ── Abort / Stop ─────────────────────────────────────────────────────────────
 *
 *  abort(runId) can be called externally (by POST /stop) to set the
 *  _abortSet flag.  The step loop checks this flag between steps.
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   execute(job)     → runs a TestCase job end-to-end (async, non-blocking)
 *   abort(runId)     → signals the active run to stop
 *   isRunning(runId) → true if a run is currently executing
 */

// M4: step handlers (stubs, replaced in M5-M7)
const STEP_HANDLERS = {
  goto:          require('./steps/goto'),
  click:         require('./steps/click'),
  fill:          require('./steps/fill'),
  type:          require('./steps/type'),
  assertVisible: require('./steps/assertVisible'),
  assertText:    require('./steps/assertText'),
  assertUrl:     require('./steps/assertUrl'),
  screenshot:    require('./steps/screenshot'),
};

class Runner {
  constructor() {
    /** @type {Set<string>} runIds that have been signalled to stop */
    this._abortSet = new Set();
    /** @type {Set<string>} runIds currently being executed */
    this._activeRuns = new Set();
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  /**
   * Execute a job received from the backend dispatcher.
   *
   * This method returns immediately — execution happens asynchronously.
   * Results are reported back to the backend via ExecutionReporter.
   *
   * @param {{
   *   runId:      string,
   *   backendUrl: string,
   *   testCase:   { targetUrl: string, steps: Array },
   *   timeoutMs:  number
   * }} job
   */
  execute(job) {
    // Start async execution without blocking the HTTP response
    this._run(job).catch((err) => {
      console.error(`[Runner] Unhandled error in run ${job.runId}:`, err.message);
    });
  }

  /**
   * Signal an active run to abort after the current step finishes.
   *
   * @param {string} runId
   */
  abort(runId) {
    if (this._activeRuns.has(runId)) {
      this._abortSet.add(runId);
      console.log(`[Runner] Abort signalled for run ${runId}`);
      return true; // was running
    }
    return false; // not found
  }

  /**
   * Returns true if a run is currently executing.
   * @param {string} runId
   */
  isRunning(runId) {
    return this._activeRuns.has(runId);
  }

  // ── Core execution loop ────────────────────────────────────────────────────

  async _run(job) {
    const { runId, testCase, timeoutMs } = job;
    const { steps } = testCase;

    this._activeRuns.add(runId);
    console.log(`[Runner] Starting run ${runId} (${steps.length} steps)`);

    let session = null;
    let finalStatus = 'PASSED';
    let finalError = null;

    // ── Outer timeout ────────────────────────────────────────────────────────
    const timeoutHandle = setTimeout(async () => {
      console.warn(`[Runner] Run ${runId} exceeded timeout (${timeoutMs} ms)`);
      this._abortSet.add(runId);
    }, timeoutMs).unref();

    try {
      // ── 1. Open browser session ──────────────────────────────────────────
      session = await browserManager.openSession(runId);

      // ── 2. Signal run started ────────────────────────────────────────────
      reporter.runStarted(runId);

      // ── 3. Execute steps ─────────────────────────────────────────────────
      for (let i = 0; i < steps.length; i++) {
        // Check for abort signal between steps
        if (this._abortSet.has(runId)) {
          finalStatus = 'STOPPED';
          finalError = 'Run was stopped by user or timeout';
          break;
        }

        const step = steps[i];
        const stepStart = Date.now();

        reporter.stepStarted(runId, i);
        console.log(`[Runner] Step ${i}: ${step.action} ${step.selector || step.value || ''}`);

        try {
          const handler = STEP_HANDLERS[step.action];
          if (!handler) {
            throw new Error(`Unknown step action: "${step.action}"`);
          }

          await handler(step, session.adapter, runId, i);

          const durationMs = Date.now() - stepStart;
          reporter.stepPassed(runId, i, durationMs);
          console.log(`[Runner] Step ${i} PASSED (${durationMs} ms)`);

        } catch (stepErr) {
          const durationMs = Date.now() - stepStart;
          reporter.stepFailed(runId, i, stepErr, durationMs);
          console.error(`[Runner] Step ${i} FAILED: ${stepErr.message}`);
          finalStatus = 'FAILED';
          finalError = stepErr.message;
          break; // bail on first failure in V1
        }
      }

    } catch (err) {
      // Session open failed or unhandled runner error
      console.error(`[Runner] Run ${runId} encountered a fatal error:`, err.message);
      reporter.error(runId, err.message, err.stack);
      finalStatus = 'FAILED';
      finalError = err.message;

    } finally {
      clearTimeout(timeoutHandle);
      this._activeRuns.delete(runId);
      this._abortSet.delete(runId);

      // ── 4. Close browser session ─────────────────────────────────────────
      if (session) {
        await browserManager.closeSession(runId);
      }

      // ── 5. Report completion to backend ──────────────────────────────────
      await reporter.complete(runId, finalStatus, finalError);

      console.log(`[Runner] Run ${runId} finished → ${finalStatus}`);
    }
  }
}

// Process-level singleton — routes share the same Runner instance
module.exports = new Runner();
