'use strict';

/**
 * WaitEngine.js — Polling-based wait strategies for the SDK runner.
 *
 * ── Why polling? ──────────────────────────────────────────────────────────────
 *
 * CDP does not have a built-in "wait for element" command. The standard approach
 * (used by Puppeteer, Playwright, etc.) is to poll the DOM at a short interval
 * until the condition is true OR the timeout is exceeded.
 *
 * WaitEngine wraps this pattern cleanly so step handlers never contain raw
 * polling loops.
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   waitForSelector(adapter, selector, timeout?)
 *     — Polls until querySelector returns a non-zero nodeId.
 *     — Returns the nodeId when found.
 *     — Throws if timeout expires.
 *
 *   waitForTimeout(ms)
 *     — Resolves after a fixed delay (explicit pause).
 *
 *   waitForUrl(adapter, urlSubstring, timeout?)
 *     — Polls until window.location.href contains urlSubstring.
 *
 *   waitForText(adapter, selector, text, timeout?)
 *     — Polls until the element's innerText contains the expected text.
 *
 * ── Configuration ─────────────────────────────────────────────────────────────
 *
 *   POLL_INTERVAL_MS  — how often to poll (default 100 ms)
 *   Default timeout   — 30 000 ms (matches per-step timeout default)
 */

const POLL_INTERVAL_MS = 100;
const DEFAULT_TIMEOUT_MS = 30_000;

/**
 * Wait until a DOM element matching `selector` is present and visible.
 *
 * @param {import('../browser/CDPAdapter')} adapter
 * @param {string} selector
 * @param {number} [timeoutMs]
 * @returns {Promise<number>} nodeId of the found element
 */
async function waitForSelector(adapter, selector, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    try {
      const nodeId = await adapter.querySelector(selector);
      if (nodeId) return nodeId;
    } catch (_) {
      // querySelector may throw if the DOM is not ready — keep polling
    }
    await waitForTimeout(POLL_INTERVAL_MS);
  }

  throw new Error(
    `[WaitEngine] waitForSelector timed out after ${timeoutMs} ms — selector: "${selector}"`
  );
}

/**
 * Wait until the current page URL contains `urlSubstring`.
 *
 * @param {import('../browser/CDPAdapter')} adapter
 * @param {string} urlSubstring
 * @param {number} [timeoutMs]
 * @returns {Promise<string>} the actual URL when the condition is met
 */
async function waitForUrl(adapter, urlSubstring, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    try {
      const currentUrl = await adapter.getCurrentUrl();
      if (currentUrl.includes(urlSubstring)) return currentUrl;
    } catch (_) {
      // page may still be loading
    }
    await waitForTimeout(POLL_INTERVAL_MS);
  }

  const finalUrl = await adapter.getCurrentUrl().catch(() => '(unknown)');
  throw new Error(
    `[WaitEngine] waitForUrl timed out after ${timeoutMs} ms\n` +
    `  Expected URL to contain: "${urlSubstring}"\n` +
    `  Actual URL: "${finalUrl}"`
  );
}

/**
 * Wait until an element's trimmed innerText contains `text`.
 *
 * @param {import('../browser/CDPAdapter')} adapter
 * @param {string} selector
 * @param {string} text
 * @param {number} [timeoutMs]
 * @returns {Promise<string>} the actual innerText when condition is met
 */
async function waitForText(adapter, selector, text, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    try {
      const result = await adapter.evaluate(
        `(document.querySelector(${JSON.stringify(selector)}) || { innerText: null }).innerText`
      );
      const actual = result.value != null ? String(result.value).trim() : null;
      if (actual && actual.includes(text)) return actual;
    } catch (_) {
      // DOM not ready yet
    }
    await waitForTimeout(POLL_INTERVAL_MS);
  }

  throw new Error(
    `[WaitEngine] waitForText timed out after ${timeoutMs} ms\n` +
    `  Selector: "${selector}"\n` +
    `  Expected text to contain: "${text}"`
  );
}

/**
 * Explicit fixed-duration pause.
 *
 * @param {number} ms
 * @returns {Promise<void>}
 */
function waitForTimeout(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { waitForSelector, waitForUrl, waitForText, waitForTimeout };
