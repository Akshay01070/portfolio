'use strict';

const { waitForText } = require('../WaitEngine');

/**
 * steps/assertText.js — Assert an element's inner text equals or contains a value.
 *
 * Step schema:
 *   { action: 'assertText', selector: 'h1', value: 'Welcome', timeout?: number }
 *
 * Uses WaitEngine.waitForText() which polls until the element's innerText
 * contains the expected value (or times out).  This correctly handles:
 *   - Elements that are not yet in the DOM
 *   - Text that changes asynchronously (e.g. after an API response)
 *
 * @param {object} step
 * @param {import('../../browser/CDPAdapter')} adapter
 */
async function assertText(step, adapter) {
  if (!step.selector) throw new Error('assertText step requires a selector');
  if (step.value === null || step.value === undefined) {
    throw new Error('assertText step requires a value (expected text)');
  }

  // waitForText throws a descriptive error if the condition never becomes true
  await waitForText(adapter, step.selector, String(step.value), step.timeout);
}

module.exports = assertText;
