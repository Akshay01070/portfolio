'use strict';

const { waitForUrl } = require('../WaitEngine');

/**
 * steps/assertUrl.js — Assert the current page URL matches an expected value.
 *
 * Step schema:
 *   { action: 'assertUrl', value: 'https://example.com/dashboard', timeout?: number }
 *
 * Uses WaitEngine.waitForUrl() which polls until window.location.href contains
 * the expected substring (or times out).  This correctly handles:
 *   - Redirects that happen after navigation completes
 *   - SPAs that update the URL via pushState without a full page load
 *
 * @param {object} step
 * @param {import('../../browser/CDPAdapter')} adapter
 */
async function assertUrl(step, adapter) {
  if (step.value === null || step.value === undefined) {
    throw new Error('assertUrl step requires a value (expected URL substring)');
  }

  // waitForUrl throws a descriptive error if the URL never matches
  await waitForUrl(adapter, String(step.value), step.timeout);
}

module.exports = assertUrl;
