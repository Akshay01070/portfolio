'use strict';

const Locator = require('../Locator');

/**
 * steps/assertVisible.js — Assert a DOM element is visible on the page.
 *
 * Step schema:
 *   { action: 'assertVisible', selector: '#success-banner', timeout?: number }
 *
 * Uses Locator.resolve() to wait for the element to appear, then checks
 * that it has a non-zero bounding box (is rendered, not hidden by CSS).
 *
 * @param {object} step
 * @param {import('../../browser/CDPAdapter')} adapter
 */
async function assertVisible(step, adapter) {
  if (!step.selector) throw new Error('assertVisible step requires a selector');

  // Wait for the element to appear in the DOM
  const nodeId = await Locator.resolve(adapter, step.selector, step.timeout);

  // Verify it actually has a visible bounding box
  let box;
  try {
    box = await adapter.getBoxModel(nodeId);
  } catch (err) {
    throw new Error(
      `assertVisible: element "${step.selector}" is in DOM but has no box model — it may be hidden`
    );
  }

  if (!box || box.width === 0 || box.height === 0) {
    throw new Error(
      `assertVisible: element "${step.selector}" has zero dimensions — it is not visible`
    );
  }
}

module.exports = assertVisible;
