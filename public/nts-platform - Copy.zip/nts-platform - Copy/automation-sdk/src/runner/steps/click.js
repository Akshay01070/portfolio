'use strict';

const Locator = require('../Locator');

/**
 * steps/click.js — Click a DOM element identified by a CSS selector.
 *
 * Step schema:
 *   { action: 'click', selector: '#submit-btn', timeout?: number }
 *
 * Uses Locator.resolveWithCenter() to:
 *   1. Wait for the element to appear in the DOM (up to step.timeout)
 *   2. Get its bounding box center (x, y) for click dispatch
 *
 * @param {object} step
 * @param {import('../../browser/CDPAdapter')} adapter
 */
async function click(step, adapter) {
  if (!step.selector) {
    throw new Error('click step requires a selector');
  }

  const { x, y } = await Locator.resolveWithCenter(adapter, step.selector, step.timeout);
  await adapter.click(x, y);
}

module.exports = click;
