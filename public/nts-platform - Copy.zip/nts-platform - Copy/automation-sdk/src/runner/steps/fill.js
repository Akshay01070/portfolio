'use strict';

const Locator = require('../Locator');

/**
 * steps/fill.js — Clear an input field and type a new value.
 *
 * Step schema:
 *   { action: 'fill', selector: '#email', value: 'user@example.com', timeout?: number }
 *
 * Uses Locator.resolveWithCenter() to wait for the element, clicks to focus it,
 * then uses CDPAdapter.clearAndType() to replace the existing value.
 *
 * @param {object} step
 * @param {import('../../browser/CDPAdapter')} adapter
 */
async function fill(step, adapter) {
  if (!step.selector) throw new Error('fill step requires a selector');
  if (step.value === null || step.value === undefined) {
    throw new Error('fill step requires a value');
  }

  // Wait for the element, then click to focus it
  const { x, y } = await Locator.resolveWithCenter(adapter, step.selector, step.timeout);
  await adapter.click(x, y);

  // Clear existing content and type the new value
  await adapter.clearAndType(String(step.value));
}

module.exports = fill;
