'use strict';

/**
 * steps/goto.js — Navigate to a URL.
 *
 * Step schema:
 *   { action: 'goto', value: 'https://example.com', timeout?: number }
 *
 * Implementation: M5
 *   Uses CDPAdapter.navigate(url, timeout) which fires Page.navigate and
 *   waits for Page.loadEventFired before resolving.
 *
 * @param {object} step      — the step definition from TestCase.steps
 * @param {import('../browser/CDPAdapter')} adapter — the CDPAdapter for this session
 * @param {string} _runId    — TestRun ObjectId (for logging)
 * @param {number} _index    — 0-based step index (for logging)
 */
async function goto(step, adapter, _runId, _index) {
  if (!step.value) {
    throw new Error('goto step requires a value (the URL to navigate to)');
  }
  await adapter.navigate(step.value, step.timeout);
}

module.exports = goto;
