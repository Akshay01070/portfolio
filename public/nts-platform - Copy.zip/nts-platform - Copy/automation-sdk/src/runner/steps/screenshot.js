'use strict';

const path = require('path');
const fs = require('fs');

/**
 * steps/screenshot.js — Capture a PNG screenshot of the current page.
 *
 * Step schema:
 *   { action: 'screenshot', timeout?: number }
 *   (selector is unused — screenshots capture the full viewport)
 *
 * Implementation: M7
 *   Delegates to adapter.captureScreenshot() (CDPAdapter typed wrapper) to
 *   get a base64-encoded PNG, then saves it to disk and registers the artifact
 *   via ExecutionReporter.
 *
 * @param {object} step
 * @param {import('../../browser/CDPAdapter')} adapter
 * @param {string} runId
 * @param {number} index
 */
async function screenshot(step, adapter, runId, index) {
  // Capture the screenshot via the CDPAdapter typed wrapper (no rawClient access).
  const data = await adapter.captureScreenshot('png', 90);

  // Build output path: <cwd>/screenshots/<runId>/step-<index>.png
  const screenshotsDir = path.join(process.cwd(), 'screenshots', runId);
  fs.mkdirSync(screenshotsDir, { recursive: true });

  const filename = `step-${index}-screenshot.png`;
  const filePath = path.join(screenshotsDir, filename);

  fs.writeFileSync(filePath, Buffer.from(data, 'base64'));
  console.log(`[screenshot] Saved: ${filePath}`);

  // Report the artifact to the backend (fire-and-forget)
  const reporter = require('../../reporter/ExecutionReporter');
  reporter.screenshot(runId, index, {
    path: filePath,
    sizeBytes: fs.statSync(filePath).size,
  });
  reporter.artifact(runId, {
    type: 'screenshot',
    filename,
    storagePath: filePath,
    mimeType: 'image/png',
    sizeBytes: fs.statSync(filePath).size,
    stepIndex: index,
  });
}

module.exports = screenshot;
