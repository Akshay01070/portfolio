'use strict';

/**
 * steps/type.js — Type text into the currently focused element (appends).
 *
 * Step schema:
 *   { action: 'type', value: 'hello world', timeout?: number }
 *
 * Unlike `fill`, `type` does NOT clear existing content first — it appends
 * to whatever is already in the focused element (or the active element).
 *
 * Implementation: M6
 *   Uses CDPAdapter.typeText(text) which dispatches keyDown+keyUp per char.
 *
 * @param {object} step
 * @param {import('../../browser/CDPAdapter')} adapter
 */
async function type(step, adapter, _runId, _index) {
  if (step.value === null || step.value === undefined) {
    throw new Error('type step requires a value');
  }
  await adapter.typeText(String(step.value));
}

module.exports = type;
