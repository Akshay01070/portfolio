'use strict';

const express = require('express');
const cors = require('cors');
const routes = require('./routes');

/**
 * src/server/app.js — SDK Express application.
 *
 * Exports the configured Express app (no listen).
 */

const app = express();

// ── Core middleware ───────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Per-request logging ───────────────────────────────────────────────────────
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const status = res.statusCode;
    const level = status >= 500 ? 'ERROR' : status >= 400 ? 'WARN' : 'INFO';
    console.log(`[sdk][${level}] ${req.method} ${req.originalUrl} ${status} ${duration}ms`);
  });
  next();
});

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/', routes);

// ── 404 handler ───────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    error: {
      status: 404,
      message: `Route not found: ${req.method} ${req.originalUrl}`,
    },
  });
});

// ── Global error handler ──────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  console.error(`[sdk][errorHandler] ${req.method} ${req.path} → ${status}: ${message}`);
  res.status(status).json({ error: { status, message } });
});

module.exports = app;
