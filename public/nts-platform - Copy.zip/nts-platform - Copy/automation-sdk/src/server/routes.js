'use strict';

const express = require('express');
const runner = require('../runner/Runner');
const browserManager = require('../browser/BrowserManager');

const router = express.Router();

/**
 * src/server/routes.js — SDK HTTP API routes.
 *
 * Endpoints exposed to the Backend:
 *
 *   GET  /health    — liveness check
 *   GET  /status    — current runner state (sessions, Chrome alive)
 *   POST /execute   — dispatch a TestRun (M4)
 *   POST /stop      — abort an active run (M4)
 */

// ── Async handler wrapper ─────────────────────────────────────────────────────
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

// ── GET /health ───────────────────────────────────────────────────────────────
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'automation-sdk',
    timestamp: new Date().toISOString(),
  });
});

// ── GET /status ───────────────────────────────────────────────────────────────
/**
 * Returns the current SDK state:
 *   - chromeAlive: whether Chrome is running
 *   - sessionCount: number of active browser sessions
 *   - sessions: array of { runId, state, createdAt }
 */
router.get('/status', (req, res) => {
  res.json({
    ...browserManager.status(),
    timestamp: new Date().toISOString(),
  });
});

// ── POST /execute ─────────────────────────────────────────────────────────────
/**
 * Received from the backend dispatcher (M3) when a QUEUED run is dispatched.
 *
 * Body (validated):
 *   {
 *     runId:       string   — TestRun ObjectId
 *     backendUrl:  string   — backend base URL for callbacks
 *     testCase: {
 *       targetUrl: string
 *       steps:     Array<Step>
 *     },
 *     timeoutMs:   number   — execution budget in ms
 *   }
 *
 * Response: 202 Accepted immediately.
 *   Execution happens asynchronously; results are POSTed back to the backend
 *   via /api/sdk/runs/:runId/events + /complete.
 *
 * Errors:
 *   400 — missing required fields
 *   503 — SDK is busy (MAX_SESSIONS reached) or shutting down
 *   409 — a run with the same runId is already executing
 */
router.post(
  '/execute',
  asyncHandler(async (req, res) => {
    const { runId, backendUrl, testCase, timeoutMs } = req.body;

    // ── Validate ──────────────────────────────────────────────────────────────
    if (!runId) {
      return res.status(400).json({ error: { status: 400, message: 'runId is required' } });
    }
    if (!testCase || !testCase.targetUrl || !Array.isArray(testCase.steps)) {
      return res.status(400).json({
        error: { status: 400, message: 'testCase.targetUrl and testCase.steps[] are required' },
      });
    }

    // ── Check concurrency ─────────────────────────────────────────────────────
    if (runner.isRunning(runId)) {
      return res.status(409).json({
        error: { status: 409, message: `Run ${runId} is already executing` },
      });
    }

    if (browserManager.hasActiveSession()) {
      return res.status(503).json({
        error: {
          status: 503,
          message: 'SDK is busy — another run is executing. Re-queue this run.',
          retryable: true,
        },
      });
    }

    // ── Accept the job ────────────────────────────────────────────────────────
    // Respond immediately with 202; execution is fully async.
    res.status(202).json({
      accepted: true,
      runId,
      message: 'Run accepted for execution',
    });

    // ── Kick off execution ────────────────────────────────────────────────────
    runner.execute({
      runId,
      backendUrl: backendUrl || process.env.BACKEND_URL,
      testCase,
      timeoutMs: timeoutMs || parseInt(process.env.SDK_EXECUTION_TIMEOUT_MS || '120000', 10),
    });
  })
);

// ── POST /stop ────────────────────────────────────────────────────────────────
/**
 * Abort an active test run.
 *
 * Body:
 *   { runId: string }
 *
 * Response:
 *   200 { stopped: true, runId }    — abort signal sent
 *   404 { error }                   — no run with this runId is executing
 */
router.post(
  '/stop',
  asyncHandler(async (req, res) => {
    const { runId } = req.body;

    if (!runId) {
      return res.status(400).json({ error: { status: 400, message: 'runId is required' } });
    }

    const wasRunning = runner.abort(runId);

    if (!wasRunning) {
      return res.status(404).json({
        error: { status: 404, message: `No active run found for runId: ${runId}` },
      });
    }

    res.json({ stopped: true, runId, message: 'Abort signal sent — run will stop after current step' });
  })
);

module.exports = router;
