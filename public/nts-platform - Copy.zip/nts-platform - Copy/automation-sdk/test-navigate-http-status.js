﻿'use strict';

/**
 * test-navigate-http-status.js
 *
 * Standalone verification script for CDPAdapter.navigate() HTTP status validation.
 *
 * This script:
 *   1. Launches Chrome in headless mode with CDP enabled (port 9222)
 *   2. Starts a local HTTP server on port 19999
 *   3. Runs 4 navigate() test cases via CDPAdapter directly
 *   4. Prints results and exits
 *
 * Usage:
 *   cd d:\sony\nts-platform\automation-sdk
 *   node test-navigate-http-status.js
 */

const http          = require('http');
const { spawn }     = require('child_process');
const path          = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const CDPAdapter    = require('./src/browser/CDPAdapter');
const env           = require('./src/config/env');

const TEST_PORT     = 19999;
const BASE_URL      = 'http://localhost:' + TEST_PORT;

const GREEN  = '\x1b[32m';
const RED    = '\x1b[31m';
const YELLOW = '\x1b[33m';
const RESET  = '\x1b[0m';
const BOLD   = '\x1b[1m';

// ---------------------------------------------------------------------------
// Chrome launcher (minimal, test-only)
// ---------------------------------------------------------------------------

let chromeProcess = null;

async function launchChrome() {
  return new Promise((resolve, reject) => {
    const args = [
      '--remote-debugging-port=' + env.CHROME_DEBUGGING_PORT,
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-extensions',
    ];

    console.log('[chrome] Launching: ' + env.CHROME_PATH);
    chromeProcess = spawn(env.CHROME_PATH, args, { stdio: 'pipe' });

    chromeProcess.on('error', (err) => {
      reject(new Error('[chrome] spawn failed: ' + err.message));
    });

    // Poll /json/version until CDP is ready
    const deadline = Date.now() + 15000;
    const poll = () => {
      if (Date.now() > deadline) {
        killChrome();
        return reject(new Error('[chrome] Did not start within 15s'));
      }
      const req = http.get('http://localhost:' + env.CHROME_DEBUGGING_PORT + '/json/version', (res) => {
        if (res.statusCode === 200) {
          console.log('[chrome] Ready on port ' + env.CHROME_DEBUGGING_PORT);
          resolve();
        } else {
          setTimeout(poll, 250);
        }
      });
      req.on('error', () => setTimeout(poll, 250));
      req.end();
    };
    setTimeout(poll, 500);
  });
}

function killChrome() {
  if (chromeProcess) {
    try { chromeProcess.kill('SIGTERM'); } catch (_) {}
    chromeProcess = null;
    console.log('[chrome] Killed.');
  }
}

// ---------------------------------------------------------------------------
// Local test HTTP server
// ---------------------------------------------------------------------------

function startTestServer() {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      const url = req.url;
      console.log('  [server] ' + req.method + ' ' + url);

      if (url === '/ok') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>200 OK</h1></body></html>');

      } else if (url === '/not-found') {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>404 Not Found</h1></body></html>');

      } else if (url === '/redirect-ok') {
        // 302 -> /ok  (final response 200 — should PASS)
        res.writeHead(302, { Location: BASE_URL + '/ok' });
        res.end();

      } else if (url === '/redirect-err') {
        // 302 -> /not-found  (final response 404 — should FAIL)
        res.writeHead(302, { Location: BASE_URL + '/not-found' });
        res.end();

      } else {
        res.writeHead(500, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>500 Unexpected: ' + url + '</h1></body></html>');
      }
    });

    server.listen(TEST_PORT, '127.0.0.1', () => {
      console.log('[server] Listening on ' + BASE_URL);
      resolve(server);
    });
    server.on('error', reject);
  });
}

function stopTestServer(server) {
  return new Promise((resolve) => server.close(resolve));
}

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

let passed = 0;
let failed = 0;

async function expectPass(adapter, url, label) {
  process.stdout.write(BOLD + '[' + label + ']' + RESET + ' navigate to ' + url + ' ... ');
  try {
    await adapter.navigate(url, 12000);
    console.log(GREEN + 'PASSED \u2713' + RESET);
    passed++;
  } catch (err) {
    console.log(RED + 'FAILED \u2717' + RESET);
    console.log('  Expected: resolve');
    console.log('  Got:      ' + err.message);
    failed++;
  }
}

async function expectFail(adapter, url, expectedSubstring, label) {
  process.stdout.write(BOLD + '[' + label + ']' + RESET + ' navigate to ' + url + ' ... ');
  try {
    await adapter.navigate(url, 12000);
    console.log(RED + 'FAILED \u2717' + RESET);
    console.log('  Expected: throw containing "' + expectedSubstring + '"');
    console.log('  Got:      resolved (no error thrown — false positive!)');
    failed++;
  } catch (err) {
    if (err.message.includes(expectedSubstring)) {
      console.log(GREEN + 'PASSED \u2713' + RESET + ' (correctly rejected: ' + err.message.trim() + ')');
      passed++;
    } else {
      console.log(RED + 'FAILED \u2717' + RESET);
      console.log('  Expected error containing: "' + expectedSubstring + '"');
      console.log('  Got:                       "' + err.message + '"');
      failed++;
    }
  }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  console.log('');
  console.log(BOLD + '====================================================' + RESET);
  console.log(BOLD + ' CDPAdapter.navigate() HTTP Status Validation Tests ' + RESET);
  console.log(BOLD + '====================================================' + RESET);
  console.log('');

  let server  = null;
  let adapter = null;

  try {
    // 1. Launch Chrome
    console.log(YELLOW + 'Launching Chrome...' + RESET);
    await launchChrome();
    console.log('');

    // 2. Start local test HTTP server
    console.log(YELLOW + 'Starting local HTTP server on port ' + TEST_PORT + '...' + RESET);
    server = await startTestServer();
    console.log('');

    // 3. Connect CDPAdapter
    console.log(YELLOW + 'Connecting CDPAdapter...' + RESET);
    adapter = new CDPAdapter();
    await adapter.connect();
    console.log('[CDPAdapter] Connected.');

    // IMPORTANT: enableDomains() must be called BEFORE any navigation so that
    // the Network domain is active and Network.responseReceived events fire.
    await adapter.enableDomains();
    console.log('[CDPAdapter] Domains enabled (Page, Runtime, DOM, Network).');
    console.log('');

    // 4. Run test cases
    console.log(YELLOW + 'Running test cases...' + RESET);
    console.log('');

    // Test 1: 200 OK -> must RESOLVE (PASS)
    await expectPass(adapter, BASE_URL + '/ok', 'Test 1');

    // Test 2: 404 -> must THROW "HTTP 404" (PASS if correctly rejected)
    await expectFail(adapter, BASE_URL + '/not-found', 'HTTP 404', 'Test 2');

    // Test 3: 302 -> 200 redirect chain -> must RESOLVE (PASS)
    await expectPass(adapter, BASE_URL + '/redirect-ok', 'Test 3');

    // Test 4: 302 -> 404 redirect chain -> must THROW "HTTP 404" (PASS if correctly rejected)
    await expectFail(adapter, BASE_URL + '/redirect-err', 'HTTP 404', 'Test 4');

    // 5. Summary
    console.log('');
    console.log(BOLD + '------------------------------------' + RESET);
    if (failed === 0) {
      console.log(GREEN + BOLD + 'All ' + passed + ' tests passed. \u2713' + RESET);
    } else {
      console.log(RED + BOLD + failed + ' test(s) FAILED. ' + passed + ' passed.' + RESET);
    }
    console.log(BOLD + '------------------------------------' + RESET);
    console.log('');

  } finally {
    if (adapter) {
      try { await adapter.disconnect(); console.log('[CDPAdapter] Disconnected.'); }
      catch (e) { console.warn('[CDPAdapter] disconnect error:', e.message); }
    }
    if (server) {
      await stopTestServer(server);
      console.log('[server] Stopped.');
    }
    killChrome();
    process.exit(failed > 0 ? 1 : 0);
  }
}

main().catch((err) => {
  console.error(RED + BOLD + '[FATAL]' + RESET + ' Unexpected error:', err.message);
  console.error(err.stack);
  killChrome();
  process.exit(1);
});