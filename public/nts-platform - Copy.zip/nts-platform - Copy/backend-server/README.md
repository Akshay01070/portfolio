# Backend Server

NTS Platform REST API — Node.js + Express + MongoDB.

## Responsibilities
- Test Case CRUD
- Test Run lifecycle & state machine (CREATED → QUEUED → RUNNING → PASSED/FAILED/STOPPED/TIMEOUT)
- In-memory Execution Queue
- Environment management
- Execution event storage
- Report generation
- SDK dispatch and completion callback handling

## Setup

```bash
cp .env.example .env   # configure MongoDB URI and other vars
npm install
npm run dev            # starts on PORT 3000 (default)
```

## Health Check

```bash
curl http://localhost:3000/api/health
# → { "status": "ok", "timestamp": "..." }
```

## Directory Structure

```
src/
├── config/
│   ├── env.js            # validates + exports env vars
│   └── db.js             # mongoose connect/disconnect
├── middleware/
│   ├── errorHandler.js   # global Express error handler
│   └── requestLogger.js  # per-request logging
├── routes/               # Express routers (M2+)
├── controllers/          # Route handlers (M2+)
├── services/             # Business logic (M2+)
├── models/               # Mongoose models (M2+)
├── execution/            # Queue + QueueProcessor (M3+)
├── sdk/                  # SDK HTTP client (M3+)
├── environments/         # Environment service (M2+)
├── reports/              # Report service (M8+)
├── utils/                # Shared helpers
├── app.js                # Express app (no listen)
└── server.js             # HTTP server entry point
```
