'use strict';

const express = require('express');
const cors = require('cors');
const requestLogger = require('./middleware/requestLogger');
const errorHandler = require('./middleware/errorHandler');

/**
 * app.js — Express application factory.
 *
 * Exports the configured Express app.
 * Does NOT call listen() — that is server.js's responsibility.
 * This separation makes the app testable without binding a port.
 */

const app = express();

// ── Core middleware ──────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(requestLogger);

// ── Health check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'backend-server',
    timestamp: new Date().toISOString(),
  });
});

// ── Routes ───────────────────────────────────────────────────────────────────
// M2: TestCase CRUD + run trigger
app.use('/api/tests', require('./routes/tests'));
// M2: Environment CRUD
app.use('/api/environments', require('./routes/environments'));
// M2: TestRun read-only (creation via POST /api/tests/:id/run)
app.use('/api/runs', require('./routes/runs'));
// M3: SDK → Backend callbacks (events, artifacts, completion, heartbeat)
app.use('/api/sdk', require('./routes/sdk'));
// M8: Report + ExecutionEvent + Artifact read routes
app.use('/api/reports', require('./routes/reports'));

// ── 404 handler ──────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    error: {
      status: 404,
      message: `Route not found: ${req.method} ${req.originalUrl}`,
    },
  });
});

// ── Global error handler (must be last) ──────────────────────────────────────
app.use(errorHandler);

module.exports = app;
