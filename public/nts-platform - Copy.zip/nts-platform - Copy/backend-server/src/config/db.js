'use strict';

const mongoose = require('mongoose');
const env = require('./env');

/**
 * db.js — Mongoose connection lifecycle.
 *
 * connect() tries the configured MONGODB_URI first.
 * If that fails, it automatically falls back to an in-memory MongoDB
 * instance (mongodb-memory-server) so development works offline
 * or when Atlas credentials are unavailable.
 *
 * disconnect() is called on graceful shutdown.
 */

let _memoryServer = null;

async function connect() {
  mongoose.set('strictQuery', true);

  mongoose.connection.on('error', (err) => {
    console.error('[db] MongoDB connection error:', err.message);
  });

  mongoose.connection.on('disconnected', () => {
    console.warn('[db] MongoDB disconnected');
  });

  // ── Try primary URI (Atlas or local mongod) ──────────────────────────────
  try {
    await mongoose.connect(env.MONGODB_URI, {
      serverSelectionTimeoutMS: 5000,
    });
    console.log(`[db] MongoDB connected: ${env.MONGODB_URI}`);
    return;
  } catch (err) {
    console.warn(`[db] Primary connection failed (${err.message}). Falling back to in-memory MongoDB…`);
  }

  // ── Fallback: in-memory MongoDB ───────────────────────────────────────────
  try {
    const { MongoMemoryServer } = require('mongodb-memory-server');
    _memoryServer = await MongoMemoryServer.create();
    const uri = _memoryServer.getUri();
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log(`[db] ⚠️  Using IN-MEMORY MongoDB at ${uri}`);
    console.log('[db] ⚠️  Data will NOT persist between restarts.');
  } catch (fallbackErr) {
    throw new Error(`[db] Both primary and in-memory MongoDB failed: ${fallbackErr.message}`);
  }
}

async function disconnect() {
  await mongoose.disconnect();
  if (_memoryServer) {
    await _memoryServer.stop();
    console.log('[db] In-memory MongoDB stopped');
  }
  console.log('[db] MongoDB disconnected gracefully');
}

module.exports = { connect, disconnect };
