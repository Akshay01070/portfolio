'use strict';

require('dotenv').config();

/**
 * env.js — Validates and exports all environment variables.
 *
 * All other modules must import from here — never access process.env directly.
 * This ensures a fast fail at startup if required config is missing.
 */

function required(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`[env] Missing required environment variable: ${name}`);
  }
  return value;
}

function optional(name, defaultValue) {
  return process.env[name] || defaultValue;
}

const env = {
  // Server
  PORT: parseInt(optional('PORT', '3000'), 10),
  NODE_ENV: optional('NODE_ENV', 'development'),

  // MongoDB
  MONGODB_URI: required('MONGODB_URI'),

  // SDK
  SDK_URL: optional('SDK_URL', 'http://localhost:8080'),
  SDK_EXECUTION_TIMEOUT_MS: parseInt(optional('SDK_EXECUTION_TIMEOUT_MS', '120000'), 10),
};

module.exports = env;
