'use strict';

/**
 * errorHandler.js — Global Express error handler middleware.
 *
 * Must be registered LAST in app.js (after all routes).
 * Catches any error passed via next(err) or thrown in async route handlers.
 */

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  // Log the full error in non-production
  if (process.env.NODE_ENV !== 'production') {
    console.error(`[errorHandler] ${req.method} ${req.path} → ${status}: ${message}`);
    if (err.stack) {
      console.error(err.stack);
    }
  }

  res.status(status).json({
    error: {
      status,
      message,
    },
  });
}

module.exports = errorHandler;
