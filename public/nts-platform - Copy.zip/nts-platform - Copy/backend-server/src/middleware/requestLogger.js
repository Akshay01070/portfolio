'use strict';

/**
 * requestLogger.js — Lightweight per-request logging middleware.
 *
 * Logs: METHOD PATH STATUS duration_ms  on response finish.
 * Used in place of morgan in development for full control.
 * In production morgan (combined format) is preferred — swap in app.js if needed.
 */

function requestLogger(req, res, next) {
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;
    const status = res.statusCode;
    const level = status >= 500 ? 'ERROR' : status >= 400 ? 'WARN' : 'INFO';
    console.log(`[${level}] ${req.method} ${req.originalUrl} ${status} ${duration}ms`);
  });

  next();
}

module.exports = requestLogger;
