'use strict';

const mongoose = require('mongoose');

/**
 * Artifact.js — Mongoose model for files produced during a TestRun.
 *
 * An Artifact is any binary or text file the automation-sdk saves to disk
 * while executing a TestCase: screenshots, video recordings, HAR traces,
 * console logs, or arbitrary attachments.
 *
 * ── Relationship ─────────────────────────────────────────────────────────────
 *
 *   TestRun  1 ──► N  Artifacts
 *
 * Artifacts are append-only.  They are never mutated after creation.
 *
 * ── Artifact types ───────────────────────────────────────────────────────────
 *
 *  screenshot   — PNG/JPEG screenshot captured at a step or on failure
 *  video        — WebM/MP4 recording of the full browser session
 *  har          — HTTP Archive (HAR) trace of all network requests
 *  log          — plain-text console log exported from the browser
 *  other        — any other attachment
 *
 * ── Storage ──────────────────────────────────────────────────────────────────
 *
 * In V1 the SDK saves files to the local filesystem and POSTs the
 * metadata (path, size, mime-type) to the backend.  The frontend fetches
 * files via GET /api/runs/:id/artifacts/:artifactId/download (M10).
 *
 * Cloud storage (S3, GCS) is a future enhancement and will not change
 * the schema — only the `storagePath` interpretation.
 *
 * ── Fields ───────────────────────────────────────────────────────────────────
 *
 *  run          — ref to TestRun (required, indexed)
 *  type         — artifact type enum
 *  filename     — original filename (e.g. "step-3-screenshot.png")
 *  storagePath  — absolute filesystem path on the SDK machine
 *  mimeType     — MIME type (e.g. "image/png")
 *  sizeBytes    — file size in bytes
 *  stepIndex    — step that produced this artifact (null = run-level)
 *  capturedAt   — when the file was written (provided by SDK)
 */

const artifactSchema = new mongoose.Schema(
  {
    run: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TestRun',
      required: [true, 'run reference is required'],
      index: true,
    },

    type: {
      type: String,
      required: [true, 'artifact type is required'],
      enum: ['screenshot', 'video', 'har', 'log', 'other'],
    },

    /**
     * Original filename as saved by the SDK.
     * Example: "step-2-click-submit.png", "session-recording.webm"
     */
    filename: {
      type: String,
      required: [true, 'filename is required'],
      trim: true,
    },

    /**
     * Absolute path on the SDK machine's filesystem.
     * Used by the backend to serve the file in M10.
     * Example: "/var/nts/artifacts/run-abc123/step-2.png"
     */
    storagePath: {
      type: String,
      required: [true, 'storagePath is required'],
      trim: true,
    },

    /**
     * MIME type of the file.
     * Examples: "image/png", "image/jpeg", "video/webm", "application/json"
     */
    mimeType: {
      type: String,
      default: 'application/octet-stream',
      trim: true,
    },

    /**
     * File size in bytes.
     * Populated by the SDK when reporting the artifact.
     */
    sizeBytes: {
      type: Number,
      default: null,
    },

    /**
     * 0-based index into TestCase.steps.
     * null for run-level artifacts (e.g. video, HAR, run log).
     */
    stepIndex: {
      type: Number,
      default: null,
    },

    /**
     * When the SDK captured / wrote this file.
     * Defaults to server ingest time if the SDK does not supply it.
     */
    capturedAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: false, // capturedAt replaces createdAt for ordering
    versionKey: false,
  }
);

// ── Indexes ──────────────────────────────────────────────────────────────────
artifactSchema.index({ run: 1, type: 1 });
artifactSchema.index({ run: 1, stepIndex: 1 });

module.exports = mongoose.model('Artifact', artifactSchema);
