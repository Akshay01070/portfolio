'use strict';

const mongoose = require('mongoose');

/**
 * Environment.js — Mongoose model for an execution environment.
 *
 * An Environment describes WHERE a TestCase runs:
 *   - sdkUrl:    the URL of the automation-sdk instance on this machine
 *   - browser:   browser type the SDK should launch
 *   - os:        informational — the host operating system
 *   - status:    availability state (controlled by SDK heartbeat in later milestones)
 *   - isDefault: if true, POST /api/tests/:id/run may select this environment
 *                automatically when no environmentId is provided
 *
 * Relationship in V1:
 *   TestCase  = WHAT    (targetUrl, steps)
 *   TestRun   = THIS execution of WHAT on WHERE
 *   Environment = WHERE  (sdkUrl, browser, os)
 */

const environmentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Environment name is required'],
      unique: true,
      trim: true,
      maxlength: [100, 'Environment name may not exceed 100 characters'],
    },

    /**
     * Browser the SDK should launch on this environment.
     * Kept as a string enum to allow future expansion (firefox, webkit, etc.)
     * without a schema migration.
     */
    browser: {
      type: String,
      required: [true, 'browser is required'],
      enum: ['chrome', 'firefox', 'webkit'],
      default: 'chrome',
    },

    /**
     * Host operating system — informational, used by the dashboard and reports.
     * The SDK does not use this value; it already knows its own OS.
     */
    os: {
      type: String,
      required: [true, 'os is required'],
      enum: ['windows', 'macos', 'linux'],
    },

    /**
     * Base URL of the automation-sdk process running on this machine.
     * The backend calls this URL when dispatching a TestRun (M3).
     * Example: "http://192.168.1.42:8080"
     */
    sdkUrl: {
      type: String,
      required: [true, 'sdkUrl is required'],
      trim: true,
    },

    /**
     * Availability status.
     *  AVAILABLE — SDK is healthy and ready to accept a run
     *  BUSY      — SDK is currently executing a run
     *  OFFLINE   — SDK has not sent a heartbeat within the expected interval
     *
     * Updated by SDK heartbeat in M3+.  Starts as AVAILABLE at creation.
     */
    status: {
      type: String,
      enum: ['AVAILABLE', 'BUSY', 'OFFLINE'],
      default: 'AVAILABLE',
    },

    /**
     * When true, this environment is selected automatically for
     * POST /api/tests/:id/run when the caller omits environmentId.
     * Only one environment should be isDefault=true at a time.
     * That constraint is enforced in the service layer, not the schema.
     */
    isDefault: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

// ── Indexes ──────────────────────────────────────────────────────────────────
environmentSchema.index({ status: 1 });
environmentSchema.index({ isDefault: 1 });

module.exports = mongoose.model('Environment', environmentSchema);
