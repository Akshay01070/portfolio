'use strict';

const mongoose = require('mongoose');

/**
 * ExecutionEvent.js — Mongoose model for a granular event emitted during a TestRun.
 *
 * ExecutionEvents are the real-time stream produced by the automation-sdk as it
 * executes a TestCase.  Each event captures exactly ONE thing that happened:
 *   - a step started / passed / failed
 *   - a screenshot was captured
 *   - a log line was emitted
 *   - the run itself started or finished
 *
 * ── Relationship ─────────────────────────────────────────────────────────────
 *
 *   TestRun  1 ──► N  ExecutionEvents
 *
 * Events are append-only.  They are never mutated after creation.
 *
 * ── Event types ──────────────────────────────────────────────────────────────
 *
 *  RUN_STARTED      — SDK began executing the test
 *  RUN_FINISHED     — SDK finished (terminal state already set on TestRun)
 *  STEP_STARTED     — Individual step execution began
 *  STEP_PASSED      — Step succeeded
 *  STEP_FAILED      — Step failed (assertion error or browser error)
 *  STEP_SKIPPED     — Step was skipped (e.g. after prior failure with bail=false)
 *  SCREENSHOT       — Screenshot captured; artifact path stored in `data.path`
 *  LOG              — Generic log line; level + message in `data`
 *  ERROR            — Unhandled SDK-level error
 *
 * ── Fields ───────────────────────────────────────────────────────────────────
 *
 *  run         — ref to TestRun (required, indexed)
 *  type        — event type enum
 *  stepIndex   — 0-based index into TestCase.steps (null for run-level events)
 *  durationMs  — duration of the step in ms (STEP_PASSED / STEP_FAILED only)
 *  data        — arbitrary extra payload (screenshot path, log message, error, etc.)
 *  timestamp   — when this event occurred (set by SDK, not server)
 */

const executionEventSchema = new mongoose.Schema(
  {
    run: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TestRun',
      required: [true, 'run reference is required'],
      index: true,
    },

    type: {
      type: String,
      required: [true, 'event type is required'],
      enum: [
        'RUN_STARTED',
        'RUN_FINISHED',
        'STEP_STARTED',
        'STEP_PASSED',
        'STEP_FAILED',
        'STEP_SKIPPED',
        'SCREENSHOT',
        'LOG',
        'ERROR',
      ],
    },

    /**
     * 0-based index into TestCase.steps.
     * null for run-level events (RUN_STARTED, RUN_FINISHED, ERROR, LOG).
     */
    stepIndex: {
      type: Number,
      default: null,
    },

    /**
     * Elapsed time for this step (ms).
     * Set for STEP_PASSED and STEP_FAILED.
     */
    durationMs: {
      type: Number,
      default: null,
    },

    /**
     * Flexible payload.  Examples:
     *   SCREENSHOT  → { path: '/screenshots/run-abc/step-2.png', sizeBytes: 45321 }
     *   STEP_FAILED → { error: 'Element not found: #submit-btn', selector: '#submit-btn' }
     *   LOG         → { level: 'info', message: 'Navigating to https://...' }
     *   ERROR       → { message: 'Chrome crashed', stack: '...' }
     */
    data: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },

    /**
     * When the event occurred on the SDK machine.
     * Provided by the SDK in the POST body; defaults to now.
     */
    timestamp: {
      type: Date,
      default: Date.now,
    },
  },
  {
    /**
     * No Mongoose timestamps here — we use our own `timestamp` field supplied
     * by the SDK so the ordering reflects execution time, not ingest time.
     */
    timestamps: false,
    versionKey: false,
  }
);

// ── Indexes ──────────────────────────────────────────────────────────────────
// The most common query: "give me all events for run X, ordered by time"
executionEventSchema.index({ run: 1, timestamp: 1 });
executionEventSchema.index({ run: 1, type: 1 });

module.exports = mongoose.model('ExecutionEvent', executionEventSchema);
