'use strict';

const mongoose = require('mongoose');

/**
 * TestCase.js — Mongoose model for a test case definition.
 *
 * A TestCase describes WHAT to test:
 *   - targetUrl:  the URL of the website under test
 *   - steps:      ordered list of browser actions the SDK will execute
 *   - tags:       free-form labels for filtering in the dashboard
 *
 * A TestCase is immutable while a TestRun that references it is RUNNING.
 * That enforcement is handled at the service layer (M3+).
 */

// ── Step sub-schema ──────────────────────────────────────────────────────────
const stepSchema = new mongoose.Schema(
  {
    /**
     * The browser action to perform.
     * Kept minimal for V1; extended in later milestones as SDK capabilities grow.
     *
     *  goto          — navigate to a URL
     *  click         — click a DOM element
     *  fill          — clear an input and type a value (works for <input>, <textarea>)
     *  type          — type into a focused element (appends, does not clear)
     *  assertVisible — assert a selector is visible in the DOM
     *  assertText    — assert element's inner text equals/contains a value
     *  assertUrl     — assert the current page URL matches a value
     *  screenshot    — capture a screenshot (saved by SDK)
     */
    action: {
      type: String,
      required: true,
      enum: [
        'goto',
        'click',
        'fill',
        'type',
        'assertVisible',
        'assertText',
        'assertUrl',
        'screenshot',
      ],
    },

    /** CSS selector or XPath.  Not required for `goto` and `screenshot`. */
    selector: {
      type: String,
      default: null,
    },

    /**
     * Action value:
     *  goto        → URL string
     *  fill/type   → text to enter
     *  assertText  → expected text
     *  assertUrl   → expected URL (or substring)
     *  click/assertVisible/screenshot → unused
     */
    value: {
      type: String,
      default: null,
    },

    /** Per-step timeout in milliseconds.  SDK respects this; defaults to 30 s. */
    timeout: {
      type: Number,
      default: 30000,
      min: 500,
    },
  },
  { _id: false } // steps are embedded; no independent ObjectId needed
);

// ── TestCase schema ──────────────────────────────────────────────────────────
const testCaseSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'TestCase name is required'],
      trim: true,
      maxlength: [200, 'TestCase name may not exceed 200 characters'],
    },

    description: {
      type: String,
      trim: true,
      default: '',
    },

    /**
     * The root URL of the website under test.
     * Individual `goto` steps may navigate elsewhere; this field anchors the
     * test and is used by the dashboard for display purposes.
     */
    targetUrl: {
      type: String,
      required: [true, 'targetUrl is required'],
      trim: true,
    },

    /**
     * Ordered list of browser steps.  The SDK executes them in array order.
     * An empty steps array is allowed (useful for draft test cases).
     */
    steps: {
      type: [stepSchema],
      default: [],
    },

    /** Free-form labels.  Used for dashboard filtering. */
    tags: {
      type: [String],
      default: [],
    },
  },
  {
    timestamps: true, // adds createdAt + updatedAt automatically
    versionKey: false,
  }
);

// ── Indexes ──────────────────────────────────────────────────────────────────
testCaseSchema.index({ name: 1 });
testCaseSchema.index({ tags: 1 });

module.exports = mongoose.model('TestCase', testCaseSchema);
