'use strict';

const mongoose = require('mongoose');

/**
 * TestRun.js — Mongoose model for a single test execution instance.
 *
 * A TestRun represents THIS execution of a TestCase on an Environment.
 *
 *   TestCase    = WHAT  (the test definition)
 *   Environment = WHERE (the SDK host)
 *   TestRun     = THIS execution of WHAT on WHERE
 *
 * ── Status FSM ───────────────────────────────────────────────────────────────
 *
 *   CREATED
 *      ↓  (immediately on POST /api/tests/:id/run)
 *   QUEUED
 *      ↓  (when M3 dispatcher picks up the run)
 *   RUNNING
 *     ├──→ PASSED   (all steps completed successfully)
 *     ├──→ FAILED   (a step assertion failed or the SDK reported failure)
 *     ├──→ STOPPED  (user triggered /stop; or SDK received SIGTERM)
 *     └──→ TIMEOUT  (SDK execution exceeded the configured timeout)
 *
 * Terminal states: PASSED, FAILED, STOPPED, TIMEOUT
 * Only the runService (src/services/runService.js) may mutate status.
 *
 * ── Fields ───────────────────────────────────────────────────────────────────
 *
 *  testCase      — ref to TestCase  (required)
 *  environment   — ref to Environment (optional; null → default environment)
 *  status        — current FSM state
 *  startedAt     — set when RUNNING
 *  completedAt   — set when terminal
 *  durationMs    — completedAt - startedAt in ms
 *  error         — top-level error message if FAILED/TIMEOUT/STOPPED
 *
 * stepResults are deferred to M7/M8 when the actual runner + reporting layer exists.
 */

// ── Allowed transitions (referenced by runService) ───────────────────────────
const TRANSITIONS = {
  CREATED: ['QUEUED'],
  QUEUED:  ['RUNNING'],
  RUNNING: ['PASSED', 'FAILED', 'STOPPED', 'TIMEOUT'],
  PASSED:  [],
  FAILED:  [],
  STOPPED: [],
  TIMEOUT: [],
};

const TERMINAL_STATES = new Set(['PASSED', 'FAILED', 'STOPPED', 'TIMEOUT']);

// ── Schema ───────────────────────────────────────────────────────────────────
const testRunSchema = new mongoose.Schema(
  {
    testCase: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TestCase',
      required: [true, 'testCase reference is required'],
    },

    /**
     * Optional — if null, the backend service resolves the default environment
     * (isDefault: true) at dispatch time (M3).
     */
    environment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Environment',
      default: null,
    },

    status: {
      type: String,
      enum: Object.keys(TRANSITIONS),
      default: 'CREATED',
    },

    /** Set by runService when status transitions to RUNNING. */
    startedAt: {
      type: Date,
      default: null,
    },

    /** Set by runService when status transitions to a terminal state. */
    completedAt: {
      type: Date,
      default: null,
    },

    /**
     * Computed by runService on completion: completedAt - startedAt.
     * Null if the run never reached RUNNING.
     */
    durationMs: {
      type: Number,
      default: null,
    },

    /**
     * Top-level error message.  Populated when:
     *   - status → FAILED   (step assertion failure or SDK error)
     *   - status → TIMEOUT  (execution exceeded SDK_EXECUTION_TIMEOUT_MS)
     *   - status → STOPPED  (user-initiated stop)
     */
    error: {
      type: String,
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

// ── Indexes ──────────────────────────────────────────────────────────────────
testRunSchema.index({ testCase: 1, createdAt: -1 });
testRunSchema.index({ status: 1 });
testRunSchema.index({ environment: 1 });

// ── Statics (exported for use by runService) ─────────────────────────────────
testRunSchema.statics.TRANSITIONS = TRANSITIONS;
testRunSchema.statics.TERMINAL_STATES = TERMINAL_STATES;

module.exports = mongoose.model('TestRun', testRunSchema);
