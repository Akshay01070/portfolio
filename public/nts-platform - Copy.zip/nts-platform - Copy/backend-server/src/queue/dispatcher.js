'use strict';

const axios = require('axios');
const env = require('../config/env');
const queue = require('./queue');
const runService = require('../services/runService');
const TestRun = require('../models/TestRun');
const Environment = require('../models/Environment');

/**
 * dispatcher.js — Drains the execution queue and dispatches runs to the SDK.
 *
 * ── Responsibilities ─────────────────────────────────────────────────────────
 *
 *   1. Poll the in-process queue at a fixed interval.
 *   2. For each queued run, look up the target Environment (sdkUrl).
 *   3. POST the run payload to the SDK's /execute endpoint.
 *   4. On success: transition run → RUNNING.
 *   5. On SDK HTTP error / network failure: transition run → FAILED with error.
 *
 * ── State machine involvement ─────────────────────────────────────────────────
 *
 *   QUEUED ──(dispatcher)──► RUNNING
 *   QUEUED ──(dispatch error)──► FAILED
 *
 * ── SDK contract (M3 POST /execute) ─────────────────────────────────────────
 *
 *   Request body sent to the SDK:
 *   {
 *     runId:       string   — TestRun ObjectId
 *     backendUrl:  string   — Backend base URL for SDK callbacks (events, artifacts)
 *     testCase: {
 *       targetUrl: string
 *       steps:     Array<Step>
 *     },
 *     timeoutMs:   number   — SDK_EXECUTION_TIMEOUT_MS from env
 *   }
 *
 *   The SDK is expected to respond with 202 Accepted immediately and then POST
 *   execution events back to the backend via /api/sdk/* routes (wired in M4+).
 *
 * ── Startup reconciliation ────────────────────────────────────────────────────
 *
 *   On server start, any runs stuck in QUEUED state (from a prior crash)
 *   are re-enqueued so they are not silently abandoned.
 *
 * ── Configuration ────────────────────────────────────────────────────────────
 *
 *   DISPATCH_INTERVAL_MS  — how often the dispatcher polls (default 2000 ms)
 *   SDK_EXECUTION_TIMEOUT_MS — passed to the SDK as the run's timeout budget
 */

const DISPATCH_INTERVAL_MS = parseInt(process.env.DISPATCH_INTERVAL_MS || '2000', 10);

// Backend base URL passed to the SDK so it knows where to POST callbacks.
// Defaults to localhost in development.
const BACKEND_CALLBACK_URL =
  process.env.BACKEND_URL || `http://localhost:${env.PORT}`;

let _timer = null;
let _running = false; // prevent re-entrant dispatch loop

// ── Internal helpers ─────────────────────────────────────────────────────────

/**
 * Resolve the SDK URL for a given run.
 *
 * Resolution order:
 *  1. run.environment → Environment.sdkUrl
 *  2. env.SDK_URL (global fallback from .env)
 *
 * @param {import('../models/TestRun')} run — populated TestRun document
 * @returns {Promise<string>} SDK base URL
 */
async function resolveSdkUrl(run) {
  if (run.environment) {
    const envDoc = await Environment.findById(run.environment);
    if (envDoc && envDoc.sdkUrl) return envDoc.sdkUrl;
  }
  return env.SDK_URL;
}

/**
 * Dispatch a single TestRun to the SDK.
 *
 * @param {string} runId
 */
async function dispatchOne(runId) {
  let run;
  try {
    run = await TestRun.findById(runId).populate('testCase').populate('environment');
  } catch (err) {
    console.error(`[dispatcher] Failed to load TestRun ${runId}:`, err.message);
    return;
  }

  if (!run) {
    console.warn(`[dispatcher] TestRun ${runId} not found in DB — discarding`);
    return;
  }

  // Guard: only dispatch QUEUED runs (race-condition safety)
  if (run.status !== 'QUEUED') {
    console.warn(`[dispatcher] TestRun ${runId} is in state ${run.status} — skipping`);
    return;
  }

  const sdkUrl = await resolveSdkUrl(run);

  // Build the payload for the SDK
  const payload = {
    runId:       run._id.toString(),
    backendUrl:  BACKEND_CALLBACK_URL,
    testCase: {
      targetUrl: run.testCase.targetUrl,
      steps:     run.testCase.steps,
    },
    timeoutMs: env.SDK_EXECUTION_TIMEOUT_MS,
  };

  try {
    await axios.post(`${sdkUrl}/execute`, payload, {
      timeout: 10_000, // HTTP handshake timeout (not execution timeout)
    });

    // SDK accepted the job — transition to RUNNING
    await runService.transition(runId, 'RUNNING');
    console.log(`[dispatcher] Run ${runId} → RUNNING (SDK: ${sdkUrl})`);
  } catch (err) {
    const message = err.response
      ? `SDK responded ${err.response.status}: ${JSON.stringify(err.response.data)}`
      : err.message;

    console.error(`[dispatcher] Dispatch failed for run ${runId}: ${message}`);

    // Fail the run so it is not stuck in QUEUED forever
    try {
      await runService.transition(runId, 'FAILED', { error: `Dispatch error: ${message}` });
    } catch (transitionErr) {
      console.error(`[dispatcher] Could not transition run ${runId} to FAILED:`, transitionErr.message);
    }
  }
}

// ── Core poll loop ───────────────────────────────────────────────────────────

async function poll() {
  if (_running) return; // previous tick still processing
  _running = true;

  try {
    let runId;
    // Drain the queue one item per tick to keep each dispatch atomic.
    // (Increase throughput in M5+ by processing N items per tick.)
    // eslint-disable-next-line no-cond-assign
    while ((runId = queue.dequeue()) !== null) {
      await dispatchOne(runId);
    }
  } finally {
    _running = false;
  }
}

// ── Public API ───────────────────────────────────────────────────────────────

/**
 * start — Begins the polling loop and reconciles any QUEUED runs from before
 * the server started (crash recovery).
 *
 * Must be called once after the database connection is established.
 */
async function start() {
  if (_timer) {
    console.warn('[dispatcher] Already started');
    return;
  }

  // Reconcile runs that were QUEUED before the server last shut down
  await reconcileQueuedRuns();

  _timer = setInterval(poll, DISPATCH_INTERVAL_MS);
  console.log(`[dispatcher] Started (interval: ${DISPATCH_INTERVAL_MS} ms)`);
}

/**
 * stop — Stops the polling loop.  Used in graceful shutdown and tests.
 */
function stop() {
  if (_timer) {
    clearInterval(_timer);
    _timer = null;
    console.log('[dispatcher] Stopped');
  }
}

/**
 * reconcileQueuedRuns — On startup, re-enqueue any runs left in QUEUED state.
 *
 * This handles the case where the server crashed after a run was queued but
 * before it was dispatched.  Without reconciliation those runs would be stuck
 * in QUEUED indefinitely.
 */
async function reconcileQueuedRuns() {
  try {
    const stuckRuns = await TestRun.find({ status: 'QUEUED' }).select('_id').lean();
    if (stuckRuns.length === 0) return;

    console.log(`[dispatcher] Reconciling ${stuckRuns.length} stuck QUEUED run(s)…`);
    for (const { _id } of stuckRuns) {
      queue.enqueue(_id.toString());
    }
  } catch (err) {
    console.error('[dispatcher] Reconciliation failed:', err.message);
  }
}

module.exports = { start, stop, reconcileQueuedRuns };
