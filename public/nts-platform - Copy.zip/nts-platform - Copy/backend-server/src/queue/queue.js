'use strict';

/**
 * queue.js — In-process execution queue for TestRun dispatch (M3).
 *
 * ── Design ───────────────────────────────────────────────────────────────────
 *
 * V1 uses a simple in-process FIFO queue backed by an Array.
 * The queue is populated by runService.createRun() and drained by the
 * dispatcher (dispatcher.js) which polls periodically and sends jobs to the
 * automation-sdk over HTTP.
 *
 * Why not Bull/BullMQ/Redis in V1?
 *   - Zero external dependencies beyond MongoDB and Node.js
 *   - Single-process deployment is sufficient for V1 throughput
 *   - The interface is intentionally simple so we can swap the backing store
 *     (Redis, MongoDB change-streams, etc.) in a later milestone without
 *     touching any callers
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   enqueue(runId)         — push a runId onto the back of the queue
 *   dequeue()              — pop from the front; returns null if empty
 *   peek()                 — inspect front without removing; returns null if empty
 *   size()                 — number of items currently waiting
 *   drain()                — remove all items (used in tests and on startup reset)
 *
 * Thread-safety note:
 *   Node.js is single-threaded, so no mutex is needed.
 *   Async I/O (the dispatcher's HTTP calls) does not interleave queue mutations
 *   because enqueue/dequeue are synchronous.
 */

const _queue = [];

/**
 * Enqueue a TestRun ID for dispatch.
 *
 * Called by runService immediately after the run status is set to QUEUED.
 *
 * @param {string} runId — Mongoose ObjectId string of the TestRun
 */
function enqueue(runId) {
  if (!runId) throw new TypeError('queue.enqueue: runId is required');
  _queue.push(String(runId));
}

/**
 * Dequeue the next run ID for dispatch.
 *
 * @returns {string|null} runId, or null if the queue is empty
 */
function dequeue() {
  return _queue.length > 0 ? _queue.shift() : null;
}

/**
 * Peek at the next run ID without removing it.
 *
 * @returns {string|null}
 */
function peek() {
  return _queue.length > 0 ? _queue[0] : null;
}

/**
 * Current number of runs waiting for dispatch.
 *
 * @returns {number}
 */
function size() {
  return _queue.length;
}

/**
 * Remove all items from the queue.
 * Intended for use in tests and on server startup (to avoid replaying stale
 * in-memory state after a crash — QUEUED runs in MongoDB are reconciled on
 * startup by the dispatcher).
 */
function drain() {
  _queue.length = 0;
}

module.exports = { enqueue, dequeue, peek, size, drain };
