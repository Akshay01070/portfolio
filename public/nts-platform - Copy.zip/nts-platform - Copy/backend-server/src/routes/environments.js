'use strict';

const express = require('express');
const Environment = require('../models/Environment');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

/**
 * environments.js — Routes for Environment CRUD.
 *
 * Mounted at: /api/environments
 *
 * Routes:
 *   GET    /api/environments        — list all environments
 *   POST   /api/environments        — create an environment
 *   GET    /api/environments/:id    — get one environment
 *   PUT    /api/environments/:id    — full replace
 *   PATCH  /api/environments/:id   — partial update
 *   DELETE /api/environments/:id   — delete
 *
 * Note on isDefault:
 *   When a client sets isDefault=true on a POST or PUT/PATCH,
 *   we clear isDefault on all other documents first to ensure
 *   only one default exists at a time.
 */

// ── Helper: enforce single default ───────────────────────────────────────────
async function enforceUniqueDefault(excludeId) {
  await Environment.updateMany(
    { _id: { $ne: excludeId }, isDefault: true },
    { $set: { isDefault: false } }
  );
}

// ── GET /api/environments ─────────────────────────────────────────────────────
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const envs = await Environment.find().sort({ isDefault: -1, name: 1 });
    res.json(envs);
  })
);

// ── POST /api/environments ────────────────────────────────────────────────────
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const env = await Environment.create(req.body);
    if (env.isDefault) {
      await enforceUniqueDefault(env._id);
    }
    res.status(201).json(env);
  })
);

// ── GET /api/environments/:id ─────────────────────────────────────────────────
router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const env = await Environment.findById(req.params.id);
    if (!env) {
      return res.status(404).json({ error: { status: 404, message: 'Environment not found' } });
    }
    res.json(env);
  })
);

// ── PUT /api/environments/:id ─────────────────────────────────────────────────
router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const env = await Environment.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true, overwrite: true }
    );
    if (!env) {
      return res.status(404).json({ error: { status: 404, message: 'Environment not found' } });
    }
    if (env.isDefault) {
      await enforceUniqueDefault(env._id);
    }
    res.json(env);
  })
);

// ── PATCH /api/environments/:id ───────────────────────────────────────────────
router.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const env = await Environment.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true, runValidators: true }
    );
    if (!env) {
      return res.status(404).json({ error: { status: 404, message: 'Environment not found' } });
    }
    if (env.isDefault) {
      await enforceUniqueDefault(env._id);
    }
    res.json(env);
  })
);

// ── DELETE /api/environments/:id ──────────────────────────────────────────────
router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const env = await Environment.findByIdAndDelete(req.params.id);
    if (!env) {
      return res.status(404).json({ error: { status: 404, message: 'Environment not found' } });
    }
    res.status(204).send();
  })
);

module.exports = router;
