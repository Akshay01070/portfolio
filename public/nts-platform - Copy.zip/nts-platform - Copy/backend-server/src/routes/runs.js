'use strict';

const fs = require('fs');
const path = require('path');
const express = require('express');
const TestRun = require('../models/TestRun');
const ExecutionEvent = require('../models/ExecutionEvent');
const Artifact = require('../models/Artifact');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

/**
 * runs.js — Read-only routes for TestRun in M2.
 *
 * Mounted at: /api/runs
 *
 * Routes:
 *   GET /api/runs                                           — list runs (filterable, paginated)
 *   GET /api/runs/:id                                       — get one run (populated)
 *   GET /api/runs/:id/events                                — list events for a run
 *   GET /api/runs/:id/artifacts                             — list artifact metadata
 *   GET /api/runs/:runId/artifacts/:artifactId/download     — stream artifact file (M10)
 *
 * Run creation:   POST /api/tests/:id/run  (src/routes/tests.js)
 * State changes:  owned exclusively by src/services/runService.js
 *
 * No POST /api/runs       — runs are not created directly
 * No PATCH /api/runs/:id  — status is not exposed as arbitrary CRUD
 * No DELETE /api/runs/:id — MVP; runs are permanent records
 */

// ── GET /api/runs ─────────────────────────────────────────────────────────────
/**
 * Query parameters:
 *   testCaseId  — filter by TestCase ObjectId
 *   status      — filter by status (e.g. ?status=QUEUED)
 *   limit       — max results (default 50, max 200)
 */
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const filter = {};

    if (req.query.testCaseId) filter.testCase = req.query.testCaseId;
    if (req.query.status)     filter.status   = req.query.status;

    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);

    const runs = await TestRun.find(filter)
      .sort({ createdAt: -1 })
      .limit(limit)
      .populate('testCase', 'name targetUrl')
      .populate('environment', 'name browser os sdkUrl');

    res.json(runs);
  })
);

// ── GET /api/runs/:id ─────────────────────────────────────────────────────────
router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const run = await TestRun.findById(req.params.id)
      .populate('testCase')
      .populate('environment');

    if (!run) {
      return res.status(404).json({ error: { status: 404, message: 'TestRun not found' } });
    }
    res.json(run);
  })
);

// ── GET /api/runs/:id/events ──────────────────────────────────────────────────
/**
 * List all ExecutionEvents for a run, ordered by timestamp.
 *
 * Query params:
 *   type      — filter by event type (e.g. ?type=STEP_FAILED)
 *   stepIndex — filter by step index (e.g. ?stepIndex=2)
 *
 * Added in M9 to give the frontend a run-centric URL for event logs,
 * consistent with GET /api/runs/:id ownership model.
 */
router.get(
  '/:id/events',
  asyncHandler(async (req, res) => {
    const filter = { run: req.params.id };
    if (req.query.type)                       filter.type      = req.query.type;
    if (req.query.stepIndex !== undefined)    filter.stepIndex = parseInt(req.query.stepIndex, 10);

    const events = await ExecutionEvent.find(filter).sort({ timestamp: 1 });
    res.json(events);
  })
);

// ── GET /api/runs/:id/artifacts ───────────────────────────────────────────────
/**
 * List all Artifacts for a run, ordered by capturedAt.
 *
 * Query params:
 *   type      — filter by artifact type (e.g. ?type=screenshot)
 *   stepIndex — filter by step index
 *
 * Added in M9 to give the frontend a run-centric URL for artifacts,
 * consistent with GET /api/runs/:id ownership model.
 */
router.get(
  '/:id/artifacts',
  asyncHandler(async (req, res) => {
    const filter = { run: req.params.id };
    if (req.query.type)                       filter.type      = req.query.type;
    if (req.query.stepIndex !== undefined)    filter.stepIndex = parseInt(req.query.stepIndex, 10);

    const artifacts = await Artifact.find(filter).sort({ capturedAt: 1 });
    res.json(artifacts);
  })
);

// ── GET /api/runs/:runId/artifacts/:artifactId/download ───────────────────────
/**
 * Stream an artifact file to the browser.
 *
 * Security:
 *   - Artifact is looked up by BOTH artifactId AND runId so a client cannot
 *     request an artifact that belongs to a different run.
 *   - The filesystem path is never echoed back to the client.
 *   - No directory traversal is possible because the path comes from the DB,
 *     not from user input.
 *
 * Responses:
 *   200  — file streamed with correct Content-Type and Content-Disposition
 *   404  — artifact document not found, or the file is missing on disk
 *
 * Added in M10.
 */
router.get(
  '/:runId/artifacts/:artifactId/download',
  asyncHandler(async (req, res) => {
    const { runId, artifactId } = req.params;

    // Find the artifact and confirm it belongs to the requested run
    const artifact = await Artifact.findOne({ _id: artifactId, run: runId });

    if (!artifact) {
      return res.status(404).json({
        error: { status: 404, message: 'Artifact not found for this run' },
      });
    }

    const storagePath = artifact.storagePath;

    // Confirm the file actually exists on disk before streaming
    if (!fs.existsSync(storagePath)) {
      return res.status(404).json({
        error: {
          status: 404,
          message: `Artifact file not found on disk: ${path.basename(storagePath)}`,
        },
      });
    }

    // Set headers: content type from stored mime, disposition for download support
    res.setHeader('Content-Type', artifact.mimeType || 'application/octet-stream');
    res.setHeader(
      'Content-Disposition',
      `inline; filename="${artifact.filename}"`
    );

    // Stream the file — avoids reading the entire file into memory
    const fileStream = fs.createReadStream(storagePath);
    fileStream.on('error', (err) => {
      console.error('[runs] Error streaming artifact:', err.message);
      if (!res.headersSent) {
        res.status(500).json({ error: { status: 500, message: 'Failed to stream artifact' } });
      }
    });
    fileStream.pipe(res);
  })
);

module.exports = router;

