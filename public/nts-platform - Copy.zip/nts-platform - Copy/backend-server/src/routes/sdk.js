'use strict';

const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const runService = require('../services/runService');
const ExecutionEvent = require('../models/ExecutionEvent');
const Artifact = require('../models/Artifact');
const TestRun = require('../models/TestRun');

const router = express.Router();

/**
 * sdk.js — Routes for SDK → Backend callbacks.
 *
 * Mounted at: /api/sdk
 *
 * These routes are called by the automation-sdk during and after execution.
 * They are NOT for human clients; there is no auth in V1 (internal network).
 *
 * ── Routes ───────────────────────────────────────────────────────────────────
 *
 *   POST /api/sdk/runs/:runId/events
 *     — SDK streams one ExecutionEvent at a time (step started/passed/failed,
 *       screenshots, logs).
 *
 *   POST /api/sdk/runs/:runId/complete
 *     — SDK signals completion (PASSED | FAILED | STOPPED | TIMEOUT).
 *       Transitions the TestRun to the terminal state.
 *
 *   POST /api/sdk/runs/:runId/artifacts
 *     — SDK registers a saved file (screenshot, video, HAR, log).
 *
 *   POST /api/sdk/heartbeat
 *     — SDK sends a periodic alive signal.  Updates Environment.status.
 *       (Used from M4+ with full environment-awareness.)
 */

// ── POST /api/sdk/runs/:runId/events ─────────────────────────────────────────
/**
 * Body:
 *   {
 *     type:       string    — ExecutionEvent type enum
 *     stepIndex:  number?   — 0-based step index (null for run-level events)
 *     durationMs: number?   — step duration in ms
 *     data:       object?   — arbitrary extra payload
 *     timestamp:  string?   — ISO8601 timestamp (defaults to now)
 *   }
 *
 * Response: 201 + saved event document
 */
router.post(
  '/runs/:runId/events',
  asyncHandler(async (req, res) => {
    const { runId } = req.params;
    const { type, stepIndex, durationMs, data, timestamp } = req.body;

    const event = await ExecutionEvent.create({
      run:       runId,
      type,
      stepIndex: stepIndex ?? null,
      durationMs: durationMs ?? null,
      data:      data ?? {},
      timestamp: timestamp ? new Date(timestamp) : new Date(),
    });

    res.status(201).json(event);
  })
);

// ── POST /api/sdk/runs/:runId/complete ────────────────────────────────────────
/**
 * Body:
 *   {
 *     status:  'PASSED' | 'FAILED' | 'STOPPED' | 'TIMEOUT'   (required)
 *     error:   string?    — top-level error message (for FAILED/TIMEOUT/STOPPED)
 *   }
 *
 * Response: 200 + updated TestRun document
 */
router.post(
  '/runs/:runId/complete',
  asyncHandler(async (req, res) => {
    const { runId } = req.params;
    const { status, error } = req.body;

    if (!['PASSED', 'FAILED', 'STOPPED', 'TIMEOUT'].includes(status)) {
      return res.status(400).json({
        error: { status: 400, message: `Invalid terminal status: ${status}` },
      });
    }

    const patch = error ? { error } : {};
    const updatedRun = await runService.transition(runId, status, patch);

    res.json(updatedRun);
  })
);

// ── POST /api/sdk/runs/:runId/artifacts ───────────────────────────────────────
/**
 * Body:
 *   {
 *     type:        'screenshot' | 'video' | 'har' | 'log' | 'other'
 *     filename:    string        — original filename
 *     storagePath: string        — absolute path on the SDK machine
 *     mimeType:    string?       — MIME type
 *     sizeBytes:   number?
 *     stepIndex:   number?       — which step produced this (null = run-level)
 *     capturedAt:  string?       — ISO8601 timestamp
 *   }
 *
 * Response: 201 + saved artifact document
 */
router.post(
  '/runs/:runId/artifacts',
  asyncHandler(async (req, res) => {
    const { runId } = req.params;
    const { type, filename, storagePath, mimeType, sizeBytes, stepIndex, capturedAt } = req.body;

    const artifact = await Artifact.create({
      run:         runId,
      type,
      filename,
      storagePath,
      mimeType:    mimeType ?? 'application/octet-stream',
      sizeBytes:   sizeBytes ?? null,
      stepIndex:   stepIndex ?? null,
      capturedAt:  capturedAt ? new Date(capturedAt) : new Date(),
    });

    res.status(201).json(artifact);
  })
);

// ── POST /api/sdk/heartbeat ──────────────────────────────────────────────────
/**
 * Keeps the Environment record alive.
 *
 * Body:
 *   {
 *     environmentId: string   — ObjectId of this SDK's Environment document
 *     status:        'AVAILABLE' | 'BUSY'
 *   }
 *
 * Response: 200 { ok: true }
 *
 * If environmentId is unknown, we log a warning and return 200 (not 404) to
 * avoid crashing the SDK on a misconfiguration.
 */
router.post(
  '/heartbeat',
  asyncHandler(async (req, res) => {
    const { environmentId, status } = req.body;

    if (environmentId && ['AVAILABLE', 'BUSY'].includes(status)) {
      const Environment = require('../models/Environment');
      const updated = await Environment.findByIdAndUpdate(
        environmentId,
        { $set: { status } },
        { new: true }
      );
      if (!updated) {
        console.warn(`[sdk heartbeat] Unknown environmentId: ${environmentId}`);
      }
    }

    res.json({ ok: true, receivedAt: new Date().toISOString() });
  })
);

module.exports = router;
