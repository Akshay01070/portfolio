'use strict';

const express = require('express');
const TestCase = require('../models/TestCase');
const runService = require('../services/runService');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

/**
 * tests.js — Routes for TestCase CRUD + run trigger.
 *
 * Mounted at: /api/tests
 *
 * Routes:
 *   GET    /api/tests           — list all test cases
 *   POST   /api/tests           — create a test case
 *   GET    /api/tests/:id       — get one test case
 *   PUT    /api/tests/:id       — full replace
 *   PATCH  /api/tests/:id       — partial update
 *   DELETE /api/tests/:id       — delete
 *   POST   /api/tests/:id/run   — create and queue a TestRun for this test case
 */

// ── GET /api/tests ────────────────────────────────────────────────────────────
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const filter = {};

    // ?tags=login,smoke  (comma-separated)
    if (req.query.tags) {
      const tags = req.query.tags.split(',').map((t) => t.trim()).filter(Boolean);
      if (tags.length) filter.tags = { $in: tags };
    }

    const tests = await TestCase.find(filter).sort({ createdAt: -1 });
    res.json(tests);
  })
);

// ── POST /api/tests ───────────────────────────────────────────────────────────
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const test = await TestCase.create(req.body);
    res.status(201).json(test);
  })
);

// ── GET /api/tests/:id ────────────────────────────────────────────────────────
router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const test = await TestCase.findById(req.params.id);
    if (!test) {
      return res.status(404).json({ error: { status: 404, message: 'TestCase not found' } });
    }
    res.json(test);
  })
);

// ── PUT /api/tests/:id (full replace) ─────────────────────────────────────────
router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const test = await TestCase.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true, overwrite: true }
    );
    if (!test) {
      return res.status(404).json({ error: { status: 404, message: 'TestCase not found' } });
    }
    res.json(test);
  })
);

// ── PATCH /api/tests/:id (partial update) ─────────────────────────────────────
router.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const test = await TestCase.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true, runValidators: true }
    );
    if (!test) {
      return res.status(404).json({ error: { status: 404, message: 'TestCase not found' } });
    }
    res.json(test);
  })
);

// ── DELETE /api/tests/:id ─────────────────────────────────────────────────────
router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const test = await TestCase.findByIdAndDelete(req.params.id);
    if (!test) {
      return res.status(404).json({ error: { status: 404, message: 'TestCase not found' } });
    }
    res.status(204).send();
  })
);

// ── POST /api/tests/:id/run ───────────────────────────────────────────────────
/**
 * Triggers a new TestRun for this TestCase.
 *
 * Body (all optional):
 *   environmentId — ObjectId of the environment to run on.
 *                   Omit to use the default environment (isDefault: true).
 *
 * Response: 201 with the created TestRun at status QUEUED.
 *
 * The run is created and queued synchronously.  The actual dispatch to the SDK
 * happens in M3 (Execution Queue + Dispatcher).
 */
router.post(
  '/:id/run',
  asyncHandler(async (req, res) => {
    const { environmentId } = req.body;
    const run = await runService.createRun(req.params.id, environmentId);
    res.status(201).json(run);
  })
);

module.exports = router;
