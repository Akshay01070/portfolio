'use strict';

const http = require('http');
const app = require('./app');
const env = require('./config/env');
const db = require('./config/db');
const dispatcher = require('./queue/dispatcher');

/**
 * server.js — HTTP server entry point.
 *
 * Responsibilities:
 *  1. Connect to MongoDB
 *  2. Start the HTTP server
 *  3. Start the M3 execution dispatcher
 *  4. Handle graceful shutdown (SIGTERM / SIGINT)
 */

const server = http.createServer(app);

async function start() {
  try {
    // 1. Connect to MongoDB
    await db.connect();

    // 2. Start HTTP server
    server.listen(env.PORT, () => {
      console.log(`[server] Backend running on http://localhost:${env.PORT}`);
      console.log(`[server] Environment: ${env.NODE_ENV}`);
      console.log(`[server] Health: http://localhost:${env.PORT}/api/health`);
    });

    // 3. Start the execution dispatcher (M3)
    await dispatcher.start();
  } catch (err) {
    console.error('[server] Failed to start:', err.message);
    process.exit(1);
  }
}

// ── Graceful shutdown ─────────────────────────────────────────────────────────
async function shutdown(signal) {
  console.log(`\n[server] Received ${signal}. Shutting down gracefully…`);

  server.close(async () => {
    console.log('[server] HTTP server closed');
    dispatcher.stop();
    await db.disconnect();
    process.exit(0);
  });

  // Force exit after 10 seconds if graceful shutdown hangs
  setTimeout(() => {
    console.error('[server] Forced exit after timeout');
    process.exit(1);
  }, 10_000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ── Unhandled rejections + exceptions ────────────────────────────────────────
process.on('unhandledRejection', (reason) => {
  console.error('[server] Unhandled rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('[server] Uncaught exception:', err.message);
  process.exit(1);
});

start();
