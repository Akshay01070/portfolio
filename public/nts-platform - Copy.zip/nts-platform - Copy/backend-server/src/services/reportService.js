'use strict';

const TestRun = require('../models/TestRun');
const ExecutionEvent = require('../models/ExecutionEvent');
const Report = require('../models/Report');

/**
 * reportService.js — Generates a Report document after a TestRun completes.
 *
 * ── When is this called? ──────────────────────────────────────────────────────
 *
 * runService.transition() calls generateReport() whenever a TestRun transitions
 * to a terminal state (PASSED, FAILED, STOPPED, TIMEOUT).
 *
 * ── What does it produce? ─────────────────────────────────────────────────────
 *
 * A single Report document that aggregates:
 *   - run reference + testCase + environment references
 *   - terminal status
 *   - summary: { total, passed, failed, skipped } step counts
 *   - stepResults: ordered array of per-step outcomes derived from ExecutionEvents
 *   - durationMs, startedAt, completedAt
 *   - top-level error message (if FAILED / TIMEOUT / STOPPED)
 *
 * ── Error handling ────────────────────────────────────────────────────────────
 *
 * generateReport() never throws — report generation is a best-effort operation.
 * If it fails (DB error, missing events, etc.) the TestRun status is already
 * correctly set.  A warning is logged and the run carries on.
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   generateReport(runId)  → Report | null
 */

/**
 * Generate and persist a Report for the given TestRun.
 *
 * @param {string} runId — ObjectId string of the completed TestRun
 * @returns {Promise<Report|null>}
 */
async function generateReport(runId) {
  try {
    // ── Load the run (populated) ─────────────────────────────────────────────
    const run = await TestRun.findById(runId).populate('testCase').lean();
    if (!run) {
      console.warn(`[reportService] TestRun ${runId} not found — skipping report`);
      return null;
    }

    // Guard: only generate for terminal states
    const TERMINAL = new Set(['PASSED', 'FAILED', 'STOPPED', 'TIMEOUT']);
    if (!TERMINAL.has(run.status)) {
      console.warn(`[reportService] Run ${runId} is not terminal (${run.status}) — skipping`);
      return null;
    }

    // Guard: don't duplicate if a report already exists for this run
    const existing = await Report.findOne({ run: runId });
    if (existing) {
      console.warn(`[reportService] Report already exists for run ${runId} — skipping`);
      return existing;
    }

    // ── Load step-level execution events ─────────────────────────────────────
    const stepEvents = await ExecutionEvent.find({
      run:  runId,
      type: { $in: ['STEP_PASSED', 'STEP_FAILED', 'STEP_SKIPPED'] },
    })
      .sort({ timestamp: 1 })
      .lean();

    // ── Build stepResults ─────────────────────────────────────────────────────
    // Index events by stepIndex; last event per step wins (handles retries).
    const byStep = new Map();
    for (const evt of stepEvents) {
      byStep.set(evt.stepIndex, evt);
    }

    const totalSteps = run.testCase?.steps?.length ?? 0;
    const stepResults = [];
    let passedCount = 0;
    let failedCount = 0;
    let skippedCount = 0;

    for (let i = 0; i < totalSteps; i++) {
      const step = run.testCase.steps[i];
      const evt = byStep.get(i);

      if (!evt) {
        // Step never executed (run was stopped/timed-out before reaching it)
        skippedCount++;
        stepResults.push({
          index:         i,
          action:        step?.action ?? 'unknown',
          status:        'SKIPPED',
          durationMs:    null,
          error:         null,
          screenshotPath: null,
        });
        continue;
      }

      const status = evt.type === 'STEP_PASSED'  ? 'PASSED'
                   : evt.type === 'STEP_FAILED'  ? 'FAILED'
                   : 'SKIPPED';

      if (status === 'PASSED')  passedCount++;
      if (status === 'FAILED')  failedCount++;
      if (status === 'SKIPPED') skippedCount++;

      // Look for a screenshot artifact associated with this step
      const screenshotEvt = await ExecutionEvent.findOne({
        run:       runId,
        type:      'SCREENSHOT',
        stepIndex: i,
      }).lean();

      stepResults.push({
        index:          i,
        action:         step?.action ?? 'unknown',
        status,
        durationMs:     evt.durationMs ?? null,
        error:          evt.data?.error ?? null,
        screenshotPath: screenshotEvt?.data?.path ?? null,
      });
    }

    // ── Build and persist the Report ─────────────────────────────────────────
    const report = await Report.create({
      run:         run._id,
      testCase:    run.testCase?._id,
      environment: run.environment ?? null,
      status:      run.status,
      summary: {
        total:   totalSteps,
        passed:  passedCount,
        failed:  failedCount,
        skipped: skippedCount,
      },
      stepResults,
      durationMs:   run.durationMs ?? null,
      startedAt:    run.startedAt ?? null,
      completedAt:  run.completedAt ?? null,
      error:        run.error ?? null,
      generatedAt:  new Date(),
    });

    console.log(
      `[reportService] Report generated for run ${runId} — ` +
      `${passedCount}/${totalSteps} steps passed`
    );

    return report;
  } catch (err) {
    // Never crash the caller — report generation is best-effort
    console.error(`[reportService] Failed to generate report for run ${runId}:`, err.message);
    return null;
  }
}

module.exports = { generateReport };
