'use strict';

const TestRun = require('../models/TestRun');
const TestCase = require('../models/TestCase');
const Environment = require('../models/Environment');
const queue = require('../queue/queue');
const { generateReport } = require('./reportService');

/**
 * runService.js — Owns the TestRun state machine.
 *
 * This is the ONLY place in the codebase that may:
 *   1. Create a TestRun document
 *   2. Transition a TestRun's status
 *
 * Route handlers and the SDK dispatcher must call these functions.
 * Direct `TestRun.findByIdAndUpdate({ status })` elsewhere is prohibited.
 *
 * ── State machine ─────────────────────────────────────────────────────────────
 *
 *   CREATED → QUEUED → RUNNING → PASSED | FAILED | STOPPED | TIMEOUT
 *
 * ── Public API ────────────────────────────────────────────────────────────────
 *
 *   createRun(testCaseId, environmentId?)  → TestRun (status=QUEUED)
 *   transition(runId, toStatus, patch?)    → TestRun (updated)
 */

const { TRANSITIONS, TERMINAL_STATES } = TestRun;

// ── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Resolves the Environment to use for a new run.
 *
 * Resolution order:
 *   1. Caller-supplied environmentId
 *   2. Environment with isDefault=true
 *   3. null (M3 dispatcher will handle or fail gracefully)
 */
async function resolveEnvironment(environmentId) {
  if (environmentId) {
    const env = await Environment.findById(environmentId);
    if (!env) {
      const err = new Error(`Environment not found: ${environmentId}`);
      err.status = 404;
      throw err;
    }
    return env._id;
  }

  // Fall back to default environment
  const defaultEnv = await Environment.findOne({ isDefault: true });
  return defaultEnv ? defaultEnv._id : null;
}

// ── Exported service functions ────────────────────────────────────────────────

/**
 * createRun — Creates a new TestRun for the given TestCase.
 *
 * The run is created at status CREATED and immediately transitioned to QUEUED.
 * (CREATED is a transient state used to validate references before queuing.)
 *
 * @param {string} testCaseId   - ObjectId of the TestCase to run
 * @param {string} [environmentId] - ObjectId of the Environment; resolved automatically if omitted
 * @returns {Promise<TestRun>}  - Saved TestRun document at status QUEUED
 */
async function createRun(testCaseId, environmentId) {
  // Validate TestCase exists
  const testCase = await TestCase.findById(testCaseId);
  if (!testCase) {
    const err = new Error(`TestCase not found: ${testCaseId}`);
    err.status = 404;
    throw err;
  }

  const resolvedEnvironmentId = await resolveEnvironment(environmentId);

  // Create at CREATED
  const run = await TestRun.create({
    testCase: testCaseId,
    environment: resolvedEnvironmentId,
    status: 'CREATED',
  });

  // Immediately transition to QUEUED (M3 dispatcher will pick it up)
  const queuedRun = await transition(run._id, 'QUEUED');

  // Push to the in-process dispatcher queue (M3)
  queue.enqueue(queuedRun._id.toString());

  return queuedRun;
}

/**
 * transition — Moves a TestRun from its current status to a new status.
 *
 * Enforces the locked FSM.  Throws 409 if the transition is not allowed.
 *
 * @param {string} runId      - ObjectId of the TestRun
 * @param {string} toStatus   - Target status
 * @param {object} [patch]    - Additional fields to set (e.g. { error })
 * @returns {Promise<TestRun>} - Updated TestRun document
 */
async function transition(runId, toStatus, patch = {}) {
  const run = await TestRun.findById(runId);
  if (!run) {
    const err = new Error(`TestRun not found: ${runId}`);
    err.status = 404;
    throw err;
  }

  const allowed = TRANSITIONS[run.status] || [];
  if (!allowed.includes(toStatus)) {
    const err = new Error(
      `Invalid status transition: ${run.status} → ${toStatus}. ` +
      `Allowed from ${run.status}: [${allowed.join(', ') || 'none (terminal)'}]`
    );
    err.status = 409;
    throw err;
  }

  // Build the update payload
  const update = { status: toStatus, ...patch };

  if (toStatus === 'RUNNING') {
    update.startedAt = new Date();
  }

  if (TERMINAL_STATES.has(toStatus)) {
    update.completedAt = new Date();
    if (run.startedAt) {
      update.durationMs = update.completedAt - run.startedAt;
    }
  }

  Object.assign(run, update);
  await run.save();

  // Auto-generate a Report when the run reaches a terminal state (M8)
  if (TERMINAL_STATES.has(toStatus)) {
    // Fire-and-forget: report generation must not block the state transition
    setImmediate(() => {
      generateReport(runId.toString()).catch((err) => {
        console.error(`[runService] generateReport failed for run ${runId}:`, err.message);
      });
    });
  }

  return run;
}

module.exports = { createRun, transition };
