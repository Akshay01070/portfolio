'use strict';

/**
 * asyncHandler.js — Wraps an async route handler so that any rejected
 * promise is automatically forwarded to Express's next(err).
 *
 * Usage:
 *   router.get('/:id', asyncHandler(async (req, res) => {
 *     const doc = await Model.findById(req.params.id);
 *     res.json(doc);
 *   }));
 */

const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

module.exports = asyncHandler;
