# NTS Frontend Dashboard

React + Vite dashboard for the NTS Test Automation Platform.

## Stack

- **React 18** + **react-router-dom v6**
- **Vite** (dev server + build)
- **Vanilla CSS** — no component library dependencies

## Quick Start

```bash
cd frontend-dashboard
cp .env.example .env   # edit if backend is not on localhost:3000
npm install
npm run dev            # → http://localhost:5173
```

Ensure the backend server is running on the URL specified in `VITE_API_URL` (default: `http://localhost:3000`).

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `VITE_API_URL` | `http://localhost:3000` | Base URL of the backend REST API. The Vite dev server proxies `/api` → this URL. |

## Pages

| Route | Page | Description |
|---|---|---|
| `/` | Dashboard | Stat overview: total tests, runs, pass rate, active envs |
| `/tests` | TestList | Browse, filter, run, edit, delete test cases |
| `/tests/new` | TestForm | Create a new test case with step builder |
| `/tests/:id/edit` | TestForm | Edit an existing test case |
| `/runs` | RunHistory | Filterable run history table |
| `/runs/:id` | RunDetail | Live polling while running; report + events + artifacts when complete |
| `/environments` | Environments | Manage SDK execution environments |

## Architecture

```
src/
├── api/
│   ├── client.js        ← Pure HTTP client (no React)
│   ├── tests.js
│   ├── runs.js
│   ├── reports.js
│   └── environments.js
├── components/
│   ├── Sidebar.jsx
│   ├── StatusBadge.jsx
│   ├── StepBuilder.jsx
│   └── Modal.jsx
├── hooks/
│   └── usePoll.js       ← Polls until terminal state; stops on unmount
├── pages/               ← One file per route
└── index.css            ← Design system (CSS vars, layout, components)
```
