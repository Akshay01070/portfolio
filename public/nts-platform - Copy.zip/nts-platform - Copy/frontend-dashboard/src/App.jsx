import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './pages/Dashboard.jsx';
import TestList from './pages/TestList.jsx';
import TestForm from './pages/TestForm.jsx';
import RunHistory from './pages/RunHistory.jsx';
import RunDetail from './pages/RunDetail.jsx';
import Environments from './pages/Environments.jsx';

export default function App() {
  return (
    <div className="layout">
      <Sidebar />
      <main className="main">
        <Routes>
          <Route path="/"                element={<Dashboard />} />
          <Route path="/tests"           element={<TestList />} />
          <Route path="/tests/new"       element={<TestForm mode="create" />} />
          <Route path="/tests/:id/edit"  element={<TestForm mode="edit" />} />
          <Route path="/runs"            element={<RunHistory />} />
          <Route path="/runs/:id"        element={<RunDetail />} />
          <Route path="/environments"    element={<Environments />} />
        </Routes>
      </main>
    </div>
  );
}
