/**
 * client.js — Pure HTTP client.
 *
 * No React dependency. All API modules import from here.
 * Base URL is read from the VITE_API_URL env var (injected by Vite at build time).
 * In development the Vite proxy forwards /api → backend, so BASE can be empty.
 */

const BASE = import.meta.env.VITE_API_URL ?? '';

/** Exported for callers that need to build a plain URL (e.g. <img src>, <a href download>). */
export const API_BASE = BASE;


/**
 * Throws on non-ok HTTP responses, attaching the parsed error body if available.
 */
async function handleResponse(res) {
  if (res.status === 204) return null;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message =
      body?.error?.message ?? body?.message ?? `HTTP ${res.status}`;
    throw new Error(message);
  }
  return body;
}

export const api = {
  get(path) {
    return fetch(BASE + path).then(handleResponse);
  },

  post(path, body) {
    return fetch(BASE + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(handleResponse);
  },

  put(path, body) {
    return fetch(BASE + path, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(handleResponse);
  },

  patch(path, body) {
    return fetch(BASE + path, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(handleResponse);
  },

  delete(path) {
    return fetch(BASE + path, { method: 'DELETE' }).then(handleResponse);
  },
};
