/**
 * environments.js — API functions for Environment resources.
 */

import { api } from './client.js';

export const listEnvironments = () => api.get('/api/environments');

export const getEnvironment = (id) => api.get(`/api/environments/${id}`);

export const createEnvironment = (body) => api.post('/api/environments', body);

/**
 * Partial update — used primarily to set isDefault=true.
 * Backend enforces single-default via enforceUniqueDefault().
 */
export const patchEnvironment = (id, body) =>
  api.patch(`/api/environments/${id}`, body);

export const deleteEnvironment = (id) => api.delete(`/api/environments/${id}`);
