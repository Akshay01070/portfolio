/**
 * reports.js — API functions for Report resources.
 *
 * Reports are read-only. Generated asynchronously by the backend after a
 * TestRun reaches a terminal state. May return 404 if generation is pending.
 */

import { api } from './client.js';

export const getReport = (runId) => api.get(`/api/reports/${runId}`);
