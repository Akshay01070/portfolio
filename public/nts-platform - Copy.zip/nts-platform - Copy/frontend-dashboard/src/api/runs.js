/**
 * runs.js — API functions for TestRun resources.
 */

import { api, API_BASE } from './client.js';

/**
 * @param {{ testCaseId?: string, status?: string, limit?: number }} filter
 */
export const listRuns = (filter = {}) => {
  const params = new URLSearchParams();
  if (filter.testCaseId) params.set('testCaseId', filter.testCaseId);
  if (filter.status)     params.set('status', filter.status);
  if (filter.limit)      params.set('limit', filter.limit);
  const qs = params.toString() ? `?${params}` : '';
  return api.get(`/api/runs${qs}`);
};

export const getRun = (id) => api.get(`/api/runs/${id}`);

/**
 * @param {string} id - TestRun ObjectId
 * @param {{ type?: string, stepIndex?: number }} filter
 */
export const getRunEvents = (id, filter = {}) => {
  const params = new URLSearchParams();
  if (filter.type !== undefined)      params.set('type', filter.type);
  if (filter.stepIndex !== undefined) params.set('stepIndex', filter.stepIndex);
  const qs = params.toString() ? `?${params}` : '';
  return api.get(`/api/runs/${id}/events${qs}`);
};

/**
 * @param {string} id - TestRun ObjectId
 * @param {{ type?: string, stepIndex?: number }} filter
 */
export const getRunArtifacts = (id, filter = {}) => {
  const params = new URLSearchParams();
  if (filter.type !== undefined)      params.set('type', filter.type);
  if (filter.stepIndex !== undefined) params.set('stepIndex', filter.stepIndex);
  const qs = params.toString() ? `?${params}` : '';
  return api.get(`/api/runs/${id}/artifacts${qs}`);
};

/**
 * Returns the URL for streaming/downloading an artifact file.
 *
 * This returns a plain URL string (not a fetch promise) so that callers can
 * use it directly as:
 *   <img src={getArtifactDownloadUrl(runId, artifactId)} />
 *   <a href={getArtifactDownloadUrl(runId, artifactId)} download>
 *   window.open(getArtifactDownloadUrl(runId, artifactId))
 *
 * @param {string} runId       - TestRun ObjectId
 * @param {string} artifactId  - Artifact ObjectId
 * @returns {string}
 */
export const getArtifactDownloadUrl = (runId, artifactId) =>
  `${API_BASE}/api/runs/${runId}/artifacts/${artifactId}/download`;

