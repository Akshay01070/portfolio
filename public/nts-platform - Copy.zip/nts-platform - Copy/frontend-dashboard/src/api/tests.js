/**
 * tests.js — API functions for TestCase resources.
 */

import { api } from './client.js';

export const listTests = (tags) => {
  const qs = tags ? `?tags=${encodeURIComponent(tags)}` : '';
  return api.get(`/api/tests${qs}`);
};

export const getTest = (id) => api.get(`/api/tests/${id}`);

export const createTest = (body) => api.post('/api/tests', body);

export const updateTest = (id, body) => api.put(`/api/tests/${id}`, body);

export const deleteTest = (id) => api.delete(`/api/tests/${id}`);

/**
 * Trigger a new TestRun for this TestCase.
 * @param {string} id - TestCase ObjectId
 * @param {string|null} environmentId - optional Environment ObjectId; backend uses default if omitted
 */
export const runTest = (id, environmentId) =>
  api.post(`/api/tests/${id}/run`, environmentId ? { environmentId } : {});
