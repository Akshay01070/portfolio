/**
 * Modal — backdrop overlay with centered content panel.
 * Closes on backdrop click or when isOpen becomes false.
 */
export default function Modal({ isOpen, onClose, title, children }) {
  if (!isOpen) return null;

  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal" role="dialog" aria-modal="true">
        {title && <div className="modal-title">{title}</div>}
        {children}
      </div>
    </div>
  );
}
