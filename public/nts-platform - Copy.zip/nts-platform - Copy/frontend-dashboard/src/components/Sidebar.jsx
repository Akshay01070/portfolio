import { NavLink } from 'react-router-dom';

/**
 * Sidebar — fixed left navigation.
 * Uses react-router-dom NavLink so the active class is applied automatically.
 */

const NAV = [
  { to: '/',            label: 'Dashboard',    icon: '▤' },
  { to: '/tests',       label: 'Tests',        icon: '⚙' },
  { to: '/runs',        label: 'Runs',         icon: '▶' },
  { to: '/environments',label: 'Environments', icon: '⬡' },
];

export default function Sidebar() {
  return (
    <nav className="sidebar">
      <div className="sidebar-logo">
        NTS
        <span>Test Automation Platform</span>
      </div>
      {NAV.map(({ to, label, icon }) => (
        <NavLink
          key={to}
          to={to}
          end={to === '/'}
          className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
        >
          <span style={{ fontSize: '1rem', lineHeight: 1 }}>{icon}</span>
          {label}
        </NavLink>
      ))}
    </nav>
  );
}
