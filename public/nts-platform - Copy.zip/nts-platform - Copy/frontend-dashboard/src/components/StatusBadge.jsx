/**
 * StatusBadge — colour-coded pill badge for run/environment statuses.
 *
 * Supported statuses:
 *   Run:         PASSED | FAILED | RUNNING | QUEUED | STOPPED | TIMEOUT | CREATED
 *   Environment: AVAILABLE | BUSY | OFFLINE
 */
export default function StatusBadge({ status }) {
  if (!status) return null;
  const cls = `badge badge-${status.toLowerCase()}`;
  return <span className={cls}>{status}</span>;
}
