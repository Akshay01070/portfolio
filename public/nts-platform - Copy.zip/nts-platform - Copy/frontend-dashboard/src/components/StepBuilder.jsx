/**
 * StepBuilder — ordered list of test steps with add / remove / reorder.
 *
 * Props:
 *   steps    — array of step objects (action, selector, value, timeout)
 *   onChange — called with the updated steps array on any change
 */

const ACTIONS = [
  'goto',
  'click',
  'fill',
  'type',
  'assertVisible',
  'assertText',
  'assertUrl',
  'screenshot',
];

const EMPTY_STEP = { action: 'goto', selector: '', value: '', timeout: 30000 };

export default function StepBuilder({ steps = [], onChange }) {
  function update(index, field, value) {
    const next = steps.map((s, i) => (i === index ? { ...s, [field]: value } : s));
    onChange(next);
  }

  function add() {
    onChange([...steps, { ...EMPTY_STEP }]);
  }

  function remove(index) {
    onChange(steps.filter((_, i) => i !== index));
  }

  function move(index, dir) {
    const next = [...steps];
    const swapWith = index + dir;
    if (swapWith < 0 || swapWith >= next.length) return;
    [next[index], next[swapWith]] = [next[swapWith], next[index]];
    onChange(next);
  }

  return (
    <div>
      <div className="step-list">
        {steps.map((step, i) => (
          <div className="step-row" key={i}>
            <span className="step-index">{i + 1}</span>

            <select
              value={step.action}
              onChange={(e) => update(i, 'action', e.target.value)}
              title="Action"
              id={`step-action-${i}`}
            >
              {ACTIONS.map((a) => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>

            <input
              type="text"
              placeholder="selector"
              value={step.selector || ''}
              onChange={(e) => update(i, 'selector', e.target.value)}
              title="CSS selector"
              id={`step-selector-${i}`}
            />

            <input
              type="text"
              placeholder="value"
              value={step.value || ''}
              onChange={(e) => update(i, 'value', e.target.value)}
              title="Value (URL for goto, text for fill/assertText…)"
              id={`step-value-${i}`}
            />

            <input
              type="number"
              placeholder="30000"
              value={step.timeout || 30000}
              onChange={(e) => update(i, 'timeout', parseInt(e.target.value, 10))}
              title="Timeout (ms)"
              min={500}
              id={`step-timeout-${i}`}
            />

            <div className="step-actions-col">
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                onClick={() => move(i, -1)}
                disabled={i === 0}
                title="Move up"
              >↑</button>
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                onClick={() => move(i, 1)}
                disabled={i === steps.length - 1}
                title="Move down"
              >↓</button>
              <button
                type="button"
                className="btn btn-danger btn-sm"
                onClick={() => remove(i)}
                title="Remove step"
              >✕</button>
            </div>
          </div>
        ))}
      </div>

      {steps.length === 0 && (
        <p className="text-muted" style={{ fontSize: '0.8125rem', marginBottom: '0.75rem' }}>
          No steps yet. Add the first step below.
        </p>
      )}

      <button type="button" className="btn btn-secondary btn-sm" onClick={add} id="add-step-btn">
        + Add Step
      </button>
    </div>
  );
}
