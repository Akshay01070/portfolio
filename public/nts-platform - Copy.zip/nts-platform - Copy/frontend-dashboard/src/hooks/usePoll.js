import { useState, useEffect, useRef, useCallback } from 'react';

/**
 * usePoll — polls fetchFn every intervalMs.
 *
 * Automatically stops when:
 *   1. shouldStop(data) returns true (terminal run state reached)
 *   2. The component unmounts
 *
 * @param {() => Promise<any>} fetchFn - async function to call on each tick
 * @param {number} intervalMs - polling interval in milliseconds
 * @param {(data: any) => boolean} shouldStop - predicate; return true to halt polling
 * @returns {{ data: any, error: Error|null, loading: boolean }}
 */
export function usePoll(fetchFn, intervalMs, shouldStop) {
  const [data, setData]     = useState(null);
  const [error, setError]   = useState(null);
  const [loading, setLoading] = useState(true);
  const timerRef = useRef(null);
  const stoppedRef = useRef(false);

  const tick = useCallback(async () => {
    try {
      const result = await fetchFn();
      setData(result);
      setError(null);
      if (shouldStop && shouldStop(result)) {
        stoppedRef.current = true;
        return; // do not schedule next tick
      }
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }

    if (!stoppedRef.current) {
      timerRef.current = setTimeout(tick, intervalMs);
    }
  }, [fetchFn, intervalMs, shouldStop]);

  useEffect(() => {
    stoppedRef.current = false;
    tick();
    return () => {
      stoppedRef.current = true;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [tick]);

  return { data, error, loading };
}

/** Terminal run states — polling stops when any of these is reached. */
export const TERMINAL_STATES = new Set(['PASSED', 'FAILED', 'STOPPED', 'TIMEOUT']);

export const isTerminal = (run) => run && TERMINAL_STATES.has(run.status);
