import { useEffect, useState } from 'react';
import { listTests } from '../api/tests.js';
import { listRuns } from '../api/runs.js';
import { listEnvironments } from '../api/environments.js';

/**
 * Dashboard — overview page.
 * Four stat tiles: Total Tests, Total Runs, Pass Rate (7 days), Active Environments.
 */
export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        const [tests, runs, envs] = await Promise.all([
          listTests(),
          listRuns({ limit: 200 }),
          listEnvironments(),
        ]);

        // Pass rate: PASSED / terminal runs in last 7 days
        const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
        const terminal = ['PASSED', 'FAILED', 'STOPPED', 'TIMEOUT'];
        const recentTerminal = runs.filter(
          (r) => terminal.includes(r.status) && new Date(r.createdAt) >= sevenDaysAgo
        );
        const recentPassed = recentTerminal.filter((r) => r.status === 'PASSED');
        const passRate =
          recentTerminal.length > 0
            ? Math.round((recentPassed.length / recentTerminal.length) * 100)
            : null;

        const activeEnvs = envs.filter((e) => e.status !== 'OFFLINE').length;

        setStats({
          totalTests: tests.length,
          totalRuns: runs.length,
          passRate,
          activeEnvs,
        });
      } catch (err) {
        setError(err.message);
      }
    }
    load();
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">NTS Test Automation Platform overview</p>
        </div>
      </div>

      {error && <div className="error-msg">{error}</div>}

      {!stats && !error && (
        <div className="flex-center text-muted">
          <span className="spinner" /> Loading…
        </div>
      )}

      {stats && (
        <div className="card-grid">
          <div className="stat-card">
            <div className="stat-label">Total Tests</div>
            <div className="stat-value">{stats.totalTests}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Total Runs</div>
            <div className="stat-value">{stats.totalRuns}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Pass Rate (7 days)</div>
            <div className="stat-value">
              {stats.passRate !== null ? `${stats.passRate}%` : '—'}
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Active Environments</div>
            <div className="stat-value">{stats.activeEnvs}</div>
          </div>
        </div>
      )}
    </div>
  );
}
