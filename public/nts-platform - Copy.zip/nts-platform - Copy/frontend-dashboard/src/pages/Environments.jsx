import { useEffect, useState } from 'react';
import {
  listEnvironments,
  createEnvironment,
  patchEnvironment,
  deleteEnvironment,
} from '../api/environments.js';
import StatusBadge from '../components/StatusBadge.jsx';
import Modal from '../components/Modal.jsx';

/**
 * Environments — card list with create / set-default / delete actions.
 *
 * "Set as Default" sends PATCH /api/environments/:id { isDefault: true }.
 * Backend enforces single-default via enforceUniqueDefault().
 */

const BROWSERS = ['chrome', 'firefox', 'webkit'];
const OSS      = ['windows', 'macos', 'linux'];

const EMPTY_FORM = {
  name: '',
  browser: 'chrome',
  os: 'windows',
  sdkUrl: '',
  isDefault: false,
};

export default function Environments() {
  const [envs, setEnvs]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  const [showModal, setShowModal] = useState(false);
  const [form, setForm]           = useState({ ...EMPTY_FORM });
  const [saving, setSaving]       = useState(false);
  const [formErr, setFormErr]     = useState(null);

  async function load() {
    setLoading(true);
    try {
      const data = await listEnvironments();
      setEnvs(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  function openCreate() {
    setForm({ ...EMPTY_FORM });
    setFormErr(null);
    setShowModal(true);
  }

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setFormErr(null);
    try {
      await createEnvironment({
        ...form,
        sdkUrl: form.sdkUrl.trim(),
        name: form.name.trim(),
      });
      setShowModal(false);
      await load();
    } catch (err) {
      setFormErr(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleSetDefault(id) {
    try {
      await patchEnvironment(id, { isDefault: true });
      await load();
    } catch (err) {
      alert(`Failed to set default: ${err.message}`);
    }
  }

  async function handleDelete(id, name) {
    if (!window.confirm(`Delete environment "${name}"?`)) return;
    try {
      await deleteEnvironment(id);
      setEnvs((prev) => prev.filter((e) => e._id !== id));
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Environments</h1>
          <p className="page-subtitle">{envs.length} environment{envs.length !== 1 ? 's' : ''}</p>
        </div>
        <button className="btn btn-primary" onClick={openCreate} id="new-env-btn">
          + New Environment
        </button>
      </div>

      {error && <div className="error-msg">{error}</div>}

      {loading && (
        <div className="flex-center text-muted">
          <span className="spinner" /> Loading…
        </div>
      )}

      {!loading && envs.length === 0 && (
        <div className="empty">No environments configured. Create one to start running tests.</div>
      )}

      {!loading && (
        <div className="env-grid">
          {envs.map((env) => (
            <div className="env-card" key={env._id}>
              <div className="env-card-header">
                <div className="env-card-name">{env.name}</div>
                <div className="flex-center gap-sm">
                  {env.isDefault && (
                    <span className="badge badge-passed" style={{ fontSize: '0.65rem' }}>default</span>
                  )}
                  <StatusBadge status={env.status} />
                </div>
              </div>
              <div className="env-card-body">
                <div>Browser: <strong style={{ color: 'var(--text)' }}>{env.browser}</strong></div>
                <div>OS: <strong style={{ color: 'var(--text)' }}>{env.os}</strong></div>
                <div className="text-mono" style={{ wordBreak: 'break-all', fontSize: '0.775rem' }}>
                  {env.sdkUrl}
                </div>
              </div>
              <div className="env-card-actions">
                {!env.isDefault && (
                  <button
                    className="btn btn-secondary btn-sm"
                    onClick={() => handleSetDefault(env._id)}
                    id={`set-default-${env._id}`}
                  >
                    Set Default
                  </button>
                )}
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => handleDelete(env._id, env.name)}
                  id={`delete-env-${env._id}`}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create environment modal */}
      <Modal isOpen={showModal} onClose={() => setShowModal(false)} title="New Environment">
        <form onSubmit={handleCreate}>
          <div className="form-group">
            <label htmlFor="env-name">Name *</label>
            <input
              id="env-name"
              type="text"
              required
              placeholder="Local Chrome"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="env-browser">Browser *</label>
              <select
                id="env-browser"
                value={form.browser}
                onChange={(e) => setForm((f) => ({ ...f, browser: e.target.value }))}
              >
                {BROWSERS.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="env-os">OS *</label>
              <select
                id="env-os"
                value={form.os}
                onChange={(e) => setForm((f) => ({ ...f, os: e.target.value }))}
              >
                {OSS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="env-sdk-url">SDK URL *</label>
            <input
              id="env-sdk-url"
              type="url"
              required
              placeholder="http://localhost:8080"
              value={form.sdkUrl}
              onChange={(e) => setForm((f) => ({ ...f, sdkUrl: e.target.value }))}
            />
          </div>

          <div className="form-group">
            <label style={{ flexDirection: 'row', display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <input
                id="env-is-default"
                type="checkbox"
                style={{ width: 'auto' }}
                checked={form.isDefault}
                onChange={(e) => setForm((f) => ({ ...f, isDefault: e.target.checked }))}
              />
              Set as default environment
            </label>
          </div>

          {formErr && <div className="error-msg">{formErr}</div>}

          <div className="modal-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowModal(false)}
              id="env-cancel-btn"
            >Cancel</button>
            <button
              type="submit"
              className="btn btn-primary"
              disabled={saving}
              id="env-create-btn"
            >
              {saving ? <><span className="spinner" /> Creating…</> : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
