import { useEffect, useState, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getRun, getRunEvents, getRunArtifacts, getArtifactDownloadUrl } from '../api/runs.js';
import { getReport } from '../api/reports.js';
import { usePoll, isTerminal } from '../hooks/usePoll.js';
import StatusBadge from '../components/StatusBadge.jsx';

/**
 * RunDetail — live polling while active; report view when terminal.
 *
 * Polling uses usePoll with isTerminal() as the stop condition.
 * On terminal state: loads the report, events, and artifacts.
 */

function fmt(ms) {
  if (ms == null) return '—';
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleString();
}

export default function RunDetail() {
  const { id } = useParams();

  const fetchRun = useCallback(() => getRun(id), [id]);
  const { data: run, error: pollError } = usePoll(fetchRun, 2000, isTerminal);

  const [report, setReport]     = useState(null);
  const [events, setEvents]     = useState([]);
  const [artifacts, setArtifacts] = useState([]);
  const [reportErr, setReportErr] = useState(null);
  const [reportLoaded, setReportLoaded] = useState(false);

  // Load report + events + artifacts once the run reaches a terminal state
  useEffect(() => {
    if (!run || !isTerminal(run) || reportLoaded) return;
    setReportLoaded(true);

    Promise.allSettled([
      getReport(id),
      getRunEvents(id),
      getRunArtifacts(id),
    ]).then(([repRes, evRes, artRes]) => {
      if (repRes.status === 'fulfilled') setReport(repRes.value);
      else setReportErr(repRes.reason?.message ?? 'Report not yet available');
      if (evRes.status === 'fulfilled')  setEvents(evRes.value);
      if (artRes.status === 'fulfilled') setArtifacts(artRes.value);
    });
  }, [run, id, reportLoaded]);

  if (!run && !pollError) {
    return (
      <div className="flex-center text-muted">
        <span className="spinner" /> Loading run…
      </div>
    );
  }

  if (pollError) {
    return <div className="error-msg">Failed to load run: {pollError.message}</div>;
  }

  const testCase = run.testCase;
  const env      = run.environment;
  const terminal = isTerminal(run);

  return (
    <div style={{ maxWidth: 900 }}>
      {/* Header */}
      <div className="page-header">
        <div>
          <div className="flex-center gap-sm" style={{ marginBottom: 4 }}>
            <h1 className="page-title" style={{ fontSize: '1.125rem' }}>
              {testCase?.name ?? 'Run Detail'}
            </h1>
            <StatusBadge status={run.status} />
            {!terminal && <span className="spinner" />}
          </div>
          <p className="page-subtitle">
            Run ID: <span className="text-mono">{run._id}</span>
          </p>
        </div>
        <Link to="/runs" className="btn btn-secondary btn-sm">← Back to Runs</Link>
      </div>

      {/* Meta */}
      <div className="card" style={{ marginBottom: '1.25rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '1rem' }}>
          <div>
            <div className="stat-label">Status</div>
            <StatusBadge status={run.status} />
          </div>
          <div>
            <div className="stat-label">Duration</div>
            <div>{fmt(run.durationMs)}</div>
          </div>
          <div>
            <div className="stat-label">Started</div>
            <div style={{ fontSize: '0.8125rem' }}>{fmtDate(run.startedAt)}</div>
          </div>
          <div>
            <div className="stat-label">Completed</div>
            <div style={{ fontSize: '0.8125rem' }}>{fmtDate(run.completedAt)}</div>
          </div>
          <div>
            <div className="stat-label">Environment</div>
            <div style={{ fontSize: '0.8125rem' }}>{env?.name ?? '—'}</div>
          </div>
          <div>
            <div className="stat-label">Target URL</div>
            <div className="text-mono text-muted" style={{ fontSize: '0.75rem', wordBreak: 'break-all' }}>
              {testCase?.targetUrl ?? '—'}
            </div>
          </div>
        </div>
        {run.error && (
          <div className="error-msg" style={{ marginTop: '1rem', marginBottom: 0 }}>
            {run.error}
          </div>
        )}
      </div>

      {/* Live: waiting for terminal */}
      {!terminal && (
        <div className="info-msg flex-center gap-sm">
          <span className="spinner" />
          Run is {run.status} — polling every 2 s…
        </div>
      )}

      {/* Report */}
      {terminal && (
        <>
          {reportErr && !report && (
            <div className="info-msg">{reportErr}</div>
          )}

          {report && (
            <div className="card" style={{ marginBottom: '1.25rem' }}>
              <div style={{ fontWeight: 600, marginBottom: '0.75rem' }}>Step Results</div>

              <div className="report-summary">
                <div className="report-stat">Total: <strong>{report.summary?.total ?? '—'}</strong></div>
                <div className="report-stat">Passed: <strong style={{ color: 'var(--status-passed)' }}>{report.summary?.passed ?? 0}</strong></div>
                <div className="report-stat">Failed: <strong style={{ color: 'var(--status-failed)' }}>{report.summary?.failed ?? 0}</strong></div>
                <div className="report-stat">Skipped: <strong>{report.summary?.skipped ?? 0}</strong></div>
              </div>

              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Action</th>
                      <th>Status</th>
                      <th>Duration</th>
                      <th>Error</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(report.stepResults ?? []).map((s) => (
                      <tr key={s.index}>
                        <td className="text-muted">{s.index + 1}</td>
                        <td><code className="text-mono">{s.action}</code></td>
                        <td><StatusBadge status={s.status} /></td>
                        <td className="text-muted">{fmt(s.durationMs)}</td>
                        <td>
                          {s.error && (
                            <span className="step-result-error">{s.error}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                    {(report.stepResults ?? []).length === 0 && (
                      <tr>
                        <td colSpan={5} className="empty">No step results recorded.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Artifacts */}
          {artifacts.length > 0 && (
            <div className="card" style={{ marginBottom: '1.25rem' }}>
              <div style={{ fontWeight: 600, marginBottom: '0.75rem' }}>
                Artifacts ({artifacts.length})
              </div>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Preview</th>
                      <th>Type</th>
                      <th>Filename</th>
                      <th>Step</th>
                      <th>Size</th>
                      <th>Captured</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {artifacts.map((a) => {
                      const downloadUrl = getArtifactDownloadUrl(id, a._id);
                      const isScreenshot = a.type === 'screenshot';
                      return (
                        <tr key={a._id}>
                          {/* Thumbnail — only rendered for screenshots */}
                          <td style={{ width: 80 }}>
                            {isScreenshot ? (
                              <a href={downloadUrl} target="_blank" rel="noreferrer">
                                <img
                                  src={downloadUrl}
                                  alt={a.filename}
                                  style={{
                                    width: 72,
                                    height: 48,
                                    objectFit: 'cover',
                                    borderRadius: 4,
                                    border: '1px solid var(--border)',
                                    display: 'block',
                                    cursor: 'pointer',
                                  }}
                                />
                              </a>
                            ) : (
                              <span className="text-muted" style={{ fontSize: '1.25rem' }}>📄</span>
                            )}
                          </td>
                          <td className="text-mono" style={{ fontSize: '0.8rem' }}>{a.type}</td>
                          <td className="text-mono text-muted" style={{ fontSize: '0.75rem', wordBreak: 'break-all' }}>
                            {a.filename}
                          </td>
                          <td className="text-muted">{a.stepIndex ?? '—'}</td>
                          <td className="text-muted" style={{ fontSize: '0.8rem', whiteSpace: 'nowrap' }}>
                            {a.sizeBytes != null ? `${(a.sizeBytes / 1024).toFixed(1)} KB` : '—'}
                          </td>
                          <td className="text-muted" style={{ fontSize: '0.8125rem', whiteSpace: 'nowrap' }}>
                            {fmtDate(a.capturedAt)}
                          </td>
                          <td style={{ whiteSpace: 'nowrap' }}>
                            {/* View: opens in browser tab using inline Content-Disposition */}
                            <a
                              href={downloadUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="btn btn-secondary btn-sm"
                              style={{ marginRight: 6 }}
                            >
                              View
                            </a>
                            {/* Download: browser prompts Save As */}
                            <a
                              href={downloadUrl}
                              download={a.filename}
                              className="btn btn-secondary btn-sm"
                            >
                              Download
                            </a>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}


          {/* Event log */}
          {events.length > 0 && (
            <details className="card">
              <summary>Event Log ({events.length} events)</summary>
              <div style={{ marginTop: '0.75rem' }}>
                <div className="table-wrap">
                  <table>
                    <thead>
                      <tr>
                        <th>Time</th>
                        <th>Type</th>
                        <th>Step</th>
                        <th>Message</th>
                      </tr>
                    </thead>
                    <tbody>
                      {events.map((ev, i) => (
                        <tr key={i}>
                          <td className="text-mono text-muted" style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                            {new Date(ev.timestamp).toLocaleTimeString()}
                          </td>
                          <td className="text-mono" style={{ fontSize: '0.75rem' }}>{ev.type}</td>
                          <td className="text-muted">{ev.stepIndex ?? '—'}</td>
                          <td style={{ fontSize: '0.8rem' }}>{ev.message ?? ev.data?.message ?? '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </details>
          )}
        </>
      )}
    </div>
  );
}
