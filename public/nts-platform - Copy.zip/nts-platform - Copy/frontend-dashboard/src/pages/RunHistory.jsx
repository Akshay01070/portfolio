import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { listRuns } from '../api/runs.js';
import StatusBadge from '../components/StatusBadge.jsx';

/**
 * RunHistory — paginated table of all test runs.
 * Filter by status. Click row → /runs/:id.
 */

const STATUSES = ['', 'QUEUED', 'RUNNING', 'PASSED', 'FAILED', 'STOPPED', 'TIMEOUT'];

function fmt(ms) {
  if (ms == null) return '—';
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleString();
}

export default function RunHistory() {
  const navigate = useNavigate();
  const [runs, setRuns]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);
  const [statusFilter, setStatusFilter] = useState('');

  async function load(status) {
    setLoading(true);
    try {
      const data = await listRuns({ status: status || undefined, limit: 100 });
      setRuns(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(statusFilter); }, [statusFilter]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Run History</h1>
          <p className="page-subtitle">{runs.length} run{runs.length !== 1 ? 's' : ''} loaded</p>
        </div>
        <div className="flex-center gap-sm">
          <select
            id="status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ width: 160 }}
          >
            {STATUSES.map((s) => (
              <option key={s} value={s}>{s || 'All statuses'}</option>
            ))}
          </select>
        </div>
      </div>

      {error && <div className="error-msg">{error}</div>}

      {loading && (
        <div className="flex-center text-muted">
          <span className="spinner" /> Loading…
        </div>
      )}

      {!loading && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Test Name</th>
                <th>Status</th>
                <th>Duration</th>
                <th>Environment</th>
                <th>Started</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {runs.length === 0 && (
                <tr>
                  <td colSpan={6} className="empty">No runs found.</td>
                </tr>
              )}
              {runs.map((run) => (
                <tr
                  key={run._id}
                  style={{ cursor: 'pointer' }}
                  onClick={() => navigate(`/runs/${run._id}`)}
                >
                  <td>
                    <strong>{run.testCase?.name ?? '—'}</strong>
                    <div className="text-mono text-muted" style={{ fontSize: '0.75rem' }}>
                      {run.testCase?.targetUrl ?? ''}
                    </div>
                  </td>
                  <td><StatusBadge status={run.status} /></td>
                  <td className="text-muted">{fmt(run.durationMs)}</td>
                  <td className="text-muted">{run.environment?.name ?? '—'}</td>
                  <td className="text-muted" style={{ fontSize: '0.8125rem' }}>
                    {fmtDate(run.startedAt ?? run.createdAt)}
                  </td>
                  <td>
                    <button
                      className="btn btn-ghost btn-sm"
                      onClick={(e) => { e.stopPropagation(); navigate(`/runs/${run._id}`); }}
                      id={`view-run-${run._id}`}
                    >View →</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
