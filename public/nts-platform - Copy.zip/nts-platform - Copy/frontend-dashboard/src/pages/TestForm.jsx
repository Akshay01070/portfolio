import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getTest, createTest, updateTest } from '../api/tests.js';
import StepBuilder from '../components/StepBuilder.jsx';

/**
 * TestForm — create or edit a test case.
 *
 * Props:
 *   mode — 'create' | 'edit'
 */
export default function TestForm({ mode }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    description: '',
    targetUrl: '',
    tags: '',
    steps: [],
  });
  const [loading, setLoading] = useState(mode === 'edit');
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState(null);

  useEffect(() => {
    if (mode !== 'edit' || !id) return;
    getTest(id)
      .then((test) => {
        setForm({
          name: test.name ?? '',
          description: test.description ?? '',
          targetUrl: test.targetUrl ?? '',
          tags: (test.tags ?? []).join(', '),
          steps: test.steps ?? [],
        });
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [mode, id]);

  function field(name) {
    return {
      id: `field-${name}`,
      value: form[name],
      onChange: (e) => setForm((f) => ({ ...f, [name]: e.target.value })),
    };
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = {
      name: form.name.trim(),
      description: form.description.trim(),
      targetUrl: form.targetUrl.trim(),
      tags: form.tags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
      steps: form.steps,
    };

    try {
      if (mode === 'create') {
        await createTest(payload);
      } else {
        await updateTest(id, payload);
      }
      navigate('/tests');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex-center text-muted">
        <span className="spinner" /> Loading…
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 760 }}>
      <div className="page-header">
        <h1 className="page-title">
          {mode === 'create' ? 'New Test Case' : 'Edit Test Case'}
        </h1>
      </div>

      {error && <div className="error-msg">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="card" style={{ marginBottom: '1.25rem' }}>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="field-name">Name *</label>
              <input type="text" required placeholder="Login flow" {...field('name')} />
            </div>
            <div className="form-group">
              <label htmlFor="field-targetUrl">Target URL *</label>
              <input type="url" required placeholder="https://example.com" {...field('targetUrl')} />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="field-description">Description</label>
            <textarea placeholder="What does this test verify?" {...field('description')} />
          </div>

          <div className="form-group">
            <label htmlFor="field-tags">Tags (comma-separated)</label>
            <input type="text" placeholder="smoke, login, regression" {...field('tags')} />
          </div>
        </div>

        <div className="card" style={{ marginBottom: '1.25rem' }}>
          <div style={{ marginBottom: '0.75rem', fontWeight: 600, fontSize: '0.9rem' }}>
            Steps
          </div>
          <StepBuilder
            steps={form.steps}
            onChange={(steps) => setForm((f) => ({ ...f, steps }))}
          />
        </div>

        <div className="form-actions">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => navigate('/tests')}
            id="cancel-btn"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn btn-primary"
            disabled={saving}
            id="save-btn"
          >
            {saving ? <><span className="spinner" /> Saving…</> : mode === 'create' ? 'Create Test' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
}
