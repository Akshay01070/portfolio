import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { listTests, deleteTest, runTest } from '../api/tests.js';
import { listEnvironments } from '../api/environments.js';
import StatusBadge from '../components/StatusBadge.jsx';
import Modal from '../components/Modal.jsx';

/**
 * TestList — table of all test cases.
 * Run ▶ opens an environment-select modal before dispatching.
 */
export default function TestList() {
  const navigate = useNavigate();
  const [tests, setTests]   = useState([]);
  const [envs, setEnvs]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState(null);
  const [tagFilter, setTagFilter] = useState('');

  // Run modal state
  const [runModal, setRunModal] = useState(null); // { testId, testName }
  const [selectedEnv, setSelectedEnv] = useState('');
  const [running, setRunning] = useState(false);
  const [runError, setRunError] = useState(null);

  async function load() {
    try {
      setLoading(true);
      const [t, e] = await Promise.all([listTests(), listEnvironments()]);
      setTests(t);
      setEnvs(e);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleDelete(id, name) {
    if (!window.confirm(`Delete test "${name}"?`)) return;
    try {
      await deleteTest(id);
      setTests((prev) => prev.filter((t) => t._id !== id));
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
    }
  }

  function openRunModal(test) {
    const defaultEnv = envs.find((e) => e.isDefault);
    setSelectedEnv(defaultEnv?._id ?? envs[0]?._id ?? '');
    setRunModal({ testId: test._id, testName: test.name });
    setRunError(null);
  }

  async function handleRun() {
    if (!runModal) return;
    setRunning(true);
    setRunError(null);
    try {
      const newRun = await runTest(runModal.testId, selectedEnv || undefined);
      setRunModal(null);
      navigate(`/runs/${newRun._id}`);
    } catch (err) {
      setRunError(err.message);
    } finally {
      setRunning(false);
    }
  }

  const visible = tagFilter
    ? tests.filter((t) =>
        t.tags?.some((tag) => tag.toLowerCase().includes(tagFilter.toLowerCase())) ||
        t.name.toLowerCase().includes(tagFilter.toLowerCase())
      )
    : tests;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Tests</h1>
          <p className="page-subtitle">{tests.length} test case{tests.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex-center gap-sm">
          <input
            type="text"
            placeholder="Filter by name or tag…"
            value={tagFilter}
            onChange={(e) => setTagFilter(e.target.value)}
            style={{ width: 220 }}
            id="test-filter"
          />
          <button
            className="btn btn-primary"
            onClick={() => navigate('/tests/new')}
            id="new-test-btn"
          >
            + New Test
          </button>
        </div>
      </div>

      {error && <div className="error-msg">{error}</div>}

      {loading && (
        <div className="flex-center text-muted">
          <span className="spinner" /> Loading…
        </div>
      )}

      {!loading && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Target URL</th>
                <th>Tags</th>
                <th>Steps</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.length === 0 && (
                <tr>
                  <td colSpan={5} className="empty">
                    {tagFilter ? 'No tests match the filter.' : 'No test cases yet. Create one to get started.'}
                  </td>
                </tr>
              )}
              {visible.map((test) => (
                <tr key={test._id}>
                  <td>
                    <strong>{test.name}</strong>
                    {test.description && (
                      <div className="text-muted" style={{ fontSize: '0.775rem' }}>
                        {test.description}
                      </div>
                    )}
                  </td>
                  <td className="text-mono text-muted">{test.targetUrl}</td>
                  <td>
                    {test.tags?.map((tag) => (
                      <span key={tag} className="tag">{tag}</span>
                    ))}
                  </td>
                  <td className="text-muted">{test.steps?.length ?? 0}</td>
                  <td>
                    <div className="flex-center gap-sm">
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => openRunModal(test)}
                        id={`run-btn-${test._id}`}
                        title="Run test"
                      >▶ Run</button>
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={() => navigate(`/tests/${test._id}/edit`)}
                        id={`edit-btn-${test._id}`}
                        title="Edit test"
                      >✏ Edit</button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(test._id, test.name)}
                        id={`delete-btn-${test._id}`}
                        title="Delete test"
                      >🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Environment select modal */}
      <Modal
        isOpen={!!runModal}
        onClose={() => setRunModal(null)}
        title={`Run "${runModal?.testName}"`}
      >
        <div className="form-group">
          <label htmlFor="env-select">Select Environment</label>
          {envs.length === 0 ? (
            <div className="info-msg">No environments configured. Create one first.</div>
          ) : (
            <select
              id="env-select"
              value={selectedEnv}
              onChange={(e) => setSelectedEnv(e.target.value)}
            >
              {envs.map((env) => (
                <option key={env._id} value={env._id}>
                  {env.name} — {env.browser} / {env.os}
                  {env.isDefault ? ' (default)' : ''}
                  {env.status !== 'AVAILABLE' ? ` [${env.status}]` : ''}
                </option>
              ))}
            </select>
          )}
        </div>

        {runError && <div className="error-msg">{runError}</div>}

        <div className="modal-actions">
          <button
            className="btn btn-secondary"
            onClick={() => setRunModal(null)}
            id="run-cancel-btn"
          >Cancel</button>
          <button
            className="btn btn-primary"
            onClick={handleRun}
            disabled={running || envs.length === 0}
            id="run-confirm-btn"
          >
            {running ? <><span className="spinner" /> Running…</> : '▶ Run Test'}
          </button>
        </div>
      </Modal>
    </div>
  );
}
