import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// vite.config.js — NTS Frontend Dashboard
//
// Proxies all /api requests to the backend server so the dev server
// never hits CORS. The target is read from VITE_API_URL (falls back
// to http://localhost:3000).

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiTarget = env.VITE_API_URL || 'http://localhost:3000';

  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        '/api': {
          target: apiTarget,
          changeOrigin: true,
        },
      },
    },
  };
});
